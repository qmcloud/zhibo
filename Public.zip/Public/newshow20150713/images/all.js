﻿//swfobject
var swfobject=function(){var D="undefined",r="object",S="Shockwave Flash",W="ShockwaveFlash.ShockwaveFlash",q="application/x-shockwave-flash",R="SWFObjectExprInst",x="onreadystatechange",O=window,j=document,t=navigator,T=false,U=[h],o=[],N=[],I=[],l,Q,E,B,J=false,a=false,n,G,m=true,M=function(){var aa=typeof j.getElementById!=D&&typeof j.getElementsByTagName!=D&&typeof j.createElement!=D,ah=t.userAgent.toLowerCase(),Y=t.platform.toLowerCase(),ae=Y?/win/.test(Y):/win/.test(ah),ac=Y?/mac/.test(Y):/mac/.test(ah),af=/webkit/.test(ah)?parseFloat(ah.replace(/^.*webkit\/(\d+(\.\d+)?).*$/,"$1")):false,X=!+"\v1",ag=[0,0,0],ab=null;if(typeof t.plugins!=D&&typeof t.plugins[S]==r){ab=t.plugins[S].description;if(ab&&!(typeof t.mimeTypes!=D&&t.mimeTypes[q]&&!t.mimeTypes[q].enabledPlugin)){T=true;X=false;ab=ab.replace(/^.*\s+(\S+\s+\S+$)/,"$1");ag[0]=parseInt(ab.replace(/^(.*)\..*$/,"$1"),10);ag[1]=parseInt(ab.replace(/^.*\.(.*)\s.*$/,"$1"),10);ag[2]=/[a-zA-Z]/.test(ab)?parseInt(ab.replace(/^.*[a-zA-Z]+(.*)$/,"$1"),10):0}}else{if(typeof O.ActiveXObject!=D){try{var ad=new ActiveXObject(W);if(ad){ab=ad.GetVariable("$version");if(ab){X=true;ab=ab.split(" ")[1].split(",");ag=[parseInt(ab[0],10),parseInt(ab[1],10),parseInt(ab[2],10)]}}}catch(Z){}}}return{w3:aa,pv:ag,wk:af,ie:X,win:ae,mac:ac}}(),k=function(){if(!M.w3){return}if((typeof j.readyState!=D&&j.readyState=="complete")||(typeof j.readyState==D&&(j.getElementsByTagName("body")[0]||j.body))){f()}if(!J){if(typeof j.addEventListener!=D){j.addEventListener("DOMContentLoaded",f,false)}if(M.ie&&M.win){j.attachEvent(x,function(){if(j.readyState=="complete"){j.detachEvent(x,arguments.callee);f()}});if(O==top){(function(){if(J){return}try{j.documentElement.doScroll("left")}catch(X){setTimeout(arguments.callee,0);return}f()})()}}if(M.wk){(function(){if(J){return}if(!/loaded|complete/.test(j.readyState)){setTimeout(arguments.callee,0);return}f()})()}s(f)}}();function f(){if(J){return}try{var Z=j.getElementsByTagName("body")[0].appendChild(C("span"));Z.parentNode.removeChild(Z)}catch(aa){return}J=true;var X=U.length;for(var Y=0;Y<X;Y++){U[Y]()}}function K(X){if(J){X()}else{U[U.length]=X}}function s(Y){if(typeof O.addEventListener!=D){O.addEventListener("load",Y,false)}else{if(typeof j.addEventListener!=D){j.addEventListener("load",Y,false)}else{if(typeof O.attachEvent!=D){i(O,"onload",Y)}else{if(typeof O.onload=="function"){var X=O.onload;O.onload=function(){X();Y()}}else{O.onload=Y}}}}}function h(){if(T){V()}else{H()}}function V(){var X=j.getElementsByTagName("body")[0];var aa=C(r);aa.setAttribute("type",q);var Z=X.appendChild(aa);if(Z){var Y=0;(function(){if(typeof Z.GetVariable!=D){var ab=Z.GetVariable("$version");if(ab){ab=ab.split(" ")[1].split(",");M.pv=[parseInt(ab[0],10),parseInt(ab[1],10),parseInt(ab[2],10)]}}else{if(Y<10){Y++;setTimeout(arguments.callee,10);return}}X.removeChild(aa);Z=null;H()})()}else{H()}}function H(){var ag=o.length;if(ag>0){for(var af=0;af<ag;af++){var Y=o[af].id;var ab=o[af].callbackFn;var aa={success:false,id:Y};if(M.pv[0]>0){var ae=c(Y);if(ae){if(F(o[af].swfVersion)&&!(M.wk&&M.wk<312)){w(Y,true);if(ab){aa.success=true;aa.ref=z(Y);ab(aa)}}else{if(o[af].expressInstall&&A()){var ai={};ai.data=o[af].expressInstall;ai.width=ae.getAttribute("width")||"0";ai.height=ae.getAttribute("height")||"0";if(ae.getAttribute("class")){ai.styleclass=ae.getAttribute("class")}if(ae.getAttribute("align")){ai.align=ae.getAttribute("align")}var ah={};var X=ae.getElementsByTagName("param");var ac=X.length;for(var ad=0;ad<ac;ad++){if(X[ad].getAttribute("name").toLowerCase()!="movie"){ah[X[ad].getAttribute("name")]=X[ad].getAttribute("value")}}P(ai,ah,Y,ab)}else{p(ae);if(ab){ab(aa)}}}}}else{w(Y,true);if(ab){var Z=z(Y);if(Z&&typeof Z.SetVariable!=D){aa.success=true;aa.ref=Z}ab(aa)}}}}}function z(aa){var X=null;var Y=c(aa);if(Y&&Y.nodeName=="OBJECT"){if(typeof Y.SetVariable!=D){X=Y}else{var Z=Y.getElementsByTagName(r)[0];if(Z){X=Z}}}return X}function A(){return !a&&F("6.0.65")&&(M.win||M.mac)&&!(M.wk&&M.wk<312)}function P(aa,ab,X,Z){a=true;E=Z||null;B={success:false,id:X};var ae=c(X);if(ae){if(ae.nodeName=="OBJECT"){l=g(ae);Q=null}else{l=ae;Q=X}aa.id=R;if(typeof aa.width==D||(!/%$/.test(aa.width)&&parseInt(aa.width,10)<310)){aa.width="310"}if(typeof aa.height==D||(!/%$/.test(aa.height)&&parseInt(aa.height,10)<137)){aa.height="137"}j.title=j.title.slice(0,47)+" - Flash Player Installation";var ad=M.ie&&M.win?"ActiveX":"PlugIn",ac="MMredirectURL="+O.location.toString().replace(/&/g,"%26")+"&MMplayerType="+ad+"&MMdoctitle="+j.title;if(typeof ab.flashvars!=D){ab.flashvars+="&"+ac}else{ab.flashvars=ac}if(M.ie&&M.win&&ae.readyState!=4){var Y=C("div");X+="SWFObjectNew";Y.setAttribute("id",X);ae.parentNode.insertBefore(Y,ae);ae.style.display="none";(function(){if(ae.readyState==4){ae.parentNode.removeChild(ae)}else{setTimeout(arguments.callee,10)}})()}u(aa,ab,X)}}function p(Y){if(M.ie&&M.win&&Y.readyState!=4){var X=C("div");Y.parentNode.insertBefore(X,Y);X.parentNode.replaceChild(g(Y),X);Y.style.display="none";(function(){if(Y.readyState==4){Y.parentNode.removeChild(Y)}else{setTimeout(arguments.callee,10)}})()}else{Y.parentNode.replaceChild(g(Y),Y)}}function g(ab){var aa=C("div");if(M.win&&M.ie){aa.innerHTML=ab.innerHTML}else{var Y=ab.getElementsByTagName(r)[0];if(Y){var ad=Y.childNodes;if(ad){var X=ad.length;for(var Z=0;Z<X;Z++){if(!(ad[Z].nodeType==1&&ad[Z].nodeName=="PARAM")&&!(ad[Z].nodeType==8)){aa.appendChild(ad[Z].cloneNode(true))}}}}}return aa}function u(ai,ag,Y){var X,aa=c(Y);if(M.wk&&M.wk<312){return X}if(aa){if(typeof ai.id==D){ai.id=Y}if(M.ie&&M.win){var ah="";for(var ae in ai){if(ai[ae]!=Object.prototype[ae]){if(ae.toLowerCase()=="data"){ag.movie=ai[ae]}else{if(ae.toLowerCase()=="styleclass"){ah+=' class="'+ai[ae]+'"'}else{if(ae.toLowerCase()!="classid"){ah+=" "+ae+'="'+ai[ae]+'"'}}}}}var af="";for(var ad in ag){if(ag[ad]!=Object.prototype[ad]){af+='<param name="'+ad+'" value="'+ag[ad]+'" />'}}aa.outerHTML='<object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000"'+ah+">"+af+"</object>";N[N.length]=ai.id;X=c(ai.id)}else{var Z=C(r);Z.setAttribute("type",q);for(var ac in ai){if(ai[ac]!=Object.prototype[ac]){if(ac.toLowerCase()=="styleclass"){Z.setAttribute("class",ai[ac])}else{if(ac.toLowerCase()!="classid"){Z.setAttribute(ac,ai[ac])}}}}for(var ab in ag){if(ag[ab]!=Object.prototype[ab]&&ab.toLowerCase()!="movie"){e(Z,ab,ag[ab])}}aa.parentNode.replaceChild(Z,aa);X=Z}}return X}function e(Z,X,Y){var aa=C("param");aa.setAttribute("name",X);aa.setAttribute("value",Y);Z.appendChild(aa)}function y(Y){var X=c(Y);if(X&&X.nodeName=="OBJECT"){if(M.ie&&M.win){X.style.display="none";(function(){if(X.readyState==4){b(Y)}else{setTimeout(arguments.callee,10)}})()}else{X.parentNode.removeChild(X)}}}function b(Z){var Y=c(Z);if(Y){for(var X in Y){if(typeof Y[X]=="function"){Y[X]=null}}Y.parentNode.removeChild(Y)}}function c(Z){var X=null;try{X=j.getElementById(Z)}catch(Y){}return X}function C(X){return j.createElement(X)}function i(Z,X,Y){Z.attachEvent(X,Y);I[I.length]=[Z,X,Y]}function F(Z){var Y=M.pv,X=Z.split(".");X[0]=parseInt(X[0],10);X[1]=parseInt(X[1],10)||0;X[2]=parseInt(X[2],10)||0;return(Y[0]>X[0]||(Y[0]==X[0]&&Y[1]>X[1])||(Y[0]==X[0]&&Y[1]==X[1]&&Y[2]>=X[2]))?true:false}function v(ac,Y,ad,ab){if(M.ie&&M.mac){return}var aa=j.getElementsByTagName("head")[0];if(!aa){return}var X=(ad&&typeof ad=="string")?ad:"screen";if(ab){n=null;G=null}if(!n||G!=X){var Z=C("style");Z.setAttribute("type","text/css");Z.setAttribute("media",X);n=aa.appendChild(Z);if(M.ie&&M.win&&typeof j.styleSheets!=D&&j.styleSheets.length>0){n=j.styleSheets[j.styleSheets.length-1]}G=X}if(M.ie&&M.win){if(n&&typeof n.addRule==r){n.addRule(ac,Y)}}else{if(n&&typeof j.createTextNode!=D){n.appendChild(j.createTextNode(ac+" {"+Y+"}"))}}}function w(Z,X){if(!m){return}var Y=X?"visible":"hidden";if(J&&c(Z)){c(Z).style.visibility=Y}else{v("#"+Z,"visibility:"+Y)}}function L(Y){var Z=/[\\\"<>\.;]/;var X=Z.exec(Y)!=null;return X&&typeof encodeURIComponent!=D?encodeURIComponent(Y):Y}var d=function(){if(M.ie&&M.win){window.attachEvent("onunload",function(){var ac=I.length;for(var ab=0;ab<ac;ab++){I[ab][0].detachEvent(I[ab][1],I[ab][2])}var Z=N.length;for(var aa=0;aa<Z;aa++){y(N[aa])}for(var Y in M){M[Y]=null}M=null;for(var X in swfobject){swfobject[X]=null}swfobject=null})}}();return{registerObject:function(ab,X,aa,Z){if(M.w3&&ab&&X){var Y={};Y.id=ab;Y.swfVersion=X;Y.expressInstall=aa;Y.callbackFn=Z;o[o.length]=Y;w(ab,false)}else{if(Z){Z({success:false,id:ab})}}},getObjectById:function(X){if(M.w3){return z(X)}},embedSWF:function(ab,ah,ae,ag,Y,aa,Z,ad,af,ac){var X={success:false,id:ah};if(M.w3&&!(M.wk&&M.wk<312)&&ab&&ah&&ae&&ag&&Y){w(ah,false);K(function(){ae+="";ag+="";var aj={};if(af&&typeof af===r){for(var al in af){aj[al]=af[al]}}aj.data=ab;aj.width=ae;aj.height=ag;var am={};if(ad&&typeof ad===r){for(var ak in ad){am[ak]=ad[ak]}}if(Z&&typeof Z===r){for(var ai in Z){if(typeof am.flashvars!=D){am.flashvars+="&"+ai+"="+Z[ai]}else{am.flashvars=ai+"="+Z[ai]}}}if(F(Y)){var an=u(aj,am,ah);if(aj.id==ah){w(ah,true)}X.success=true;X.ref=an}else{if(aa&&A()){aj.data=aa;P(aj,am,ah,ac);return}else{w(ah,true)}}if(ac){ac(X)}})}else{if(ac){ac(X)}}},switchOffAutoHideShow:function(){m=false},ua:M,getFlashPlayerVersion:function(){return{major:M.pv[0],minor:M.pv[1],release:M.pv[2]}},hasFlashPlayerVersion:F,createSWF:function(Z,Y,X){if(M.w3){return u(Z,Y,X)}else{return undefined}},showExpressInstall:function(Z,aa,X,Y){if(M.w3&&A()){P(Z,aa,X,Y)}},removeSWF:function(X){if(M.w3){y(X)}},createCSS:function(aa,Z,Y,X){if(M.w3){v(aa,Z,Y,X)}},addDomLoadEvent:K,addLoadEvent:s,getQueryParamValue:function(aa){var Z=j.location.search||j.location.hash;if(Z){if(/\?/.test(Z)){Z=Z.split("?")[1]}if(aa==null){return L(Z)}var Y=Z.split("&");for(var X=0;X<Y.length;X++){if(Y[X].substring(0,Y[X].indexOf("="))==aa){return L(Y[X].substring((Y[X].indexOf("=")+1)))}}}return""},expressInstallCallback:function(){if(a){var X=c(R);if(X&&l){X.parentNode.replaceChild(l,X);if(Q){w(Q,true);if(M.ie&&M.win){l.style.display="block"}}if(E){E(B)}}a=false}}}}(); 
//dialog
(function($){jQuery.fn.extend({dialog:function(g){var h=$(window);var j=$(this);var k=j.data("dialogid");var l;getFocus=function(a){var b=NewGuid();var c=a.find(':text:first');if(c.length){c.focus()}else{c=$('<input id="'+b+'" style="width:1px;height:1px;font-size:0;border:none" />').appendTo(a);c.focus().remove()}};eventCall=function(a,b,c){if(!a)return;if($.isFunction(a)){a.call(b,c)}};draggable=function(a,b){if($.fn.draggable){a.find(".popCont h1").mousedown(function(){a.find(":first").draggable({},b)})}};resize=function(a){$("#"+a+" .box_modal").css({width:getWidth(),height:getHeight()})};getZindex=function(){var a=$("div[dialogid]");return 999900000+(a==null?0:a.length)};getWidth=function(){var a=h.width();var b=$(document).width();return a>b?a:b};getHeight=function(){var a=h.height();var b=$(document).height();return a>b?a:b};NewGuid=function(){var a="";for(var i=1;i<=32;i++){var n=Math.floor(Math.random()*16.0).toString(16);a+=n;if((i==8)||(i==12)||(i==16)||(i==20))a+="-"}return a};if(k!=null){l=$("#"+k);switch(g){case"iscreated":return true;break;case"getparent":return l;break;case"open":l.show();return j;break;case"toggle":l.toggle();return j;break;case"close":l.hide();return j;break;case"distory":l.hide();j.removeData("dialogid");j.remove();l.remove();l=j=null;return;break;default:j.appendTo($("body"));l.remove();break}}else{if(typeof g!="object"){return false}}var m={title:'',icon:'',modal:false,draggable:true,width:360,height:185,opacity:0.15,autoOpen:false,hasclose:true,buttons:null,position:null,autoscroll:true,autoresize:true,hasborder:true,background:'',mainpadding:''};var g=$.extend(m,g);var o=$(document.body);var p=NewGuid();if(!g.position){g.position=[0,0];g.position[0]=(h.width()-g.width)/2;g.position[1]=(h.height()-g.height)/2+h.scrollTop()}var q='<div id="'+p+'" dialogid="'+p+'" style="width:100%;display:none;"><div class="dialog clearfix" style="'+(g.background.length==0?"":"background:"+g.background+";")+'width:'+g.width+'px; height:auto;z-index:'+getZindex()+'; left:'+g.position[0]+'px;top:'+g.position[1]+'px;'+(g.hasborder?"":"")+'">';q+='<div class="popBox clearfix" '+(g.background?"style=\"background:"+g.background+"\"":'')+'>';var r=$.trim(g.title).length>0;if(r&&g.hasclose){q+='<a title="\u5173\u95ED" class="dclose" href="#this"></a>'}q+='<div class="bgTop" '+(g.background?"style=\"background:"+g.background+"\"":'')+'><div class="popCont"'+(!r?' style="padding:0;"':'')+'>';if(r){q+='<h1 style="cursor:'+(g.draggable?"move":"default")+'">'+g.title+'</h1>'}q+='<div class="box_main" style="padding:'+(!r?'0':g.mainpadding?g.mainpadding:'')+';'+(g.background?'background:'+g.background:'')+'"></div></div></div></div></div>';if(g.modal){q+='<div class="box_modal" style="width:100%;height:'+getHeight()+'px; z-index:'+(getZindex()-1)+';"></div>';h.resize(function(){resize(p)})}q+='</div>';l=$(q);var s=l.find(".box_main");j.show().appendTo(s);l.appendTo(o);if(g.icon!=''){var t=$('<div class="icons '+g.icon+'"></div>');t.insertBefore(j).next().addClass("text")}if(g.buttons!==null&&typeof g.buttons==='object'){var u=$('<p class="foot"></p>');u.appendTo(s);$.each(g.buttons,function(b,c){var d="W_btn_";if(typeof b=="string"||b=="0"){d+="e"}else{d+="f"}c=$.isFunction(c)?{click:c,text:b}:c;var f=$('<a class="'+d+'" href="#this"><span>'+c.text+'</span></a>').unbind('click').click(function(e){eventCall(c.click,this,e);return false}).appendTo(u);if(d=="W_btn_e"){l.keypress(function(a){if(a.keyCode==13){eventCall(c.click,u[0],a);return false}})}})}var v=l.find(".dialog");if(g.draggable){if($.fn.draggable){draggable(l,function(){g.position=[parseInt(v.css('left')),parseInt(v.css('top'))-h.scrollTop()]})}else{$.getScript("http://sr.9513.com/live/js/weishow.draggable.min.js",function(){draggable(l,function(){g.position=[parseInt(v.css('left')),parseInt(v.css('top'))-h.scrollTop()]})})}}l.find("a.dclose").click(function(e){l.hide();eventCall(g.close,this,e);return false});j.data("dialogid",p);l.find(".box_modal").css({opacity:g.opacity});l.find(".ui-draggable,.box_modal").bgiframe();if(g.autoOpen){l.show()}if(g.autoscroll){h.scroll(function(){if(p){var a=$("#"+p);if(a.length){if(a.is(':visible'))a.find(".dialog").css("top",(h.height()-g.height)/2+h.scrollTop())}else{v=k=a=p=g=h=null}}})}if(g.autoresize){h.resize(function(){if(p){var a=$("#"+p);if(a.length){if(a.is(':visible')){a.find(".dialog").css("left",(h.width()-g.width)/2).css("top",(h.height()-g.height)/2+h.scrollTop())}}else{v=k=a=p=g=h=null}}})}eventCall(g.load,this);return j}});$.fn.bgiframe=($.browser.msie&&/msie 6\.0/i.test(navigator.userAgent)?function(s){s=$.extend({top:'auto',left:'auto',width:'auto',height:'auto',opacity:true,src:'javascript:false;'},s);var a='<iframe class="bgiframe" frameborder="0" tabindex="-1" src="'+s.src+'"'+' style="display:block;position:absolute;z-index:-1;'+(s.opacity!==false?'filter:Alpha(opacity=\'0\');':'')+'top:'+(s.top=='auto'?'expression(((parseInt(this.parentNode.currentStyle.borderTopWidth)||0)*-1)+\'px\')':prop(s.top))+';'+'left:'+(s.left=='auto'?'expression(((parseInt(this.parentNode.currentStyle.borderLeftWidth)||0)*-1)+\'px\')':prop(s.left))+';'+'width:'+(s.width=='auto'?'expression(this.parentNode.offsetWidth+\'px\')':prop(s.width))+';'+'height:'+(s.height=='auto'?'expression(this.parentNode.offsetHeight+\'px\')':prop(s.height))+';'+'"/>';return this.each(function(){if($(this).children('iframe.bgiframe').length===0)this.insertBefore(document.createElement(a),this.firstChild)});function prop(n){return n&&n.constructor===Number?n+'px':n}}:function(){return this});$.fn.bgIframe=$.fn.bgiframe;$.extend({alert:function(a,b,c,d,f){f=(f==null?true:f);if(f){var g=$("div[dialogid]:visible .box_modal");if(g.length)return}var h,_position;if(window.urlQueryString){var i=urlQueryString('from',true);if(i==='xl'){_position=[($(window).width()-400)/2,300]}else{_position=null}}return h=$('<div style="text-align:center;">'+a+'</div>').dialog({title:'\u63D0\u793A',icon:d,modal:f,autoOpen:true,position:_position,buttons:[{text:"\u786E\u5B9A",click:function(e){eventCall(b,this,e);h.dialog("distory");h=null}}],close:function(e){eventCall(c,this,e);h.dialog("distory");h=null}})},confirm:function(a,b,c,d,f){f=(f==null?true:f);if(f){var g=$("div[dialogid]:visible .box_modal");if(g.length)return}var h,_position;if(window.urlQueryString){var i=urlQueryString('from',true);if(i==='xl'){_position=[($(window).width()-400)/2,300]}else{_position=null}}return h=$('<div style="text-align:center;">'+a+'</div>').dialog({title:'\u63D0\u793A',icon:d,modal:f,autoOpen:true,position:_position,buttons:[{text:"\u786E\u5B9A",click:function(e){eventCall(b,this,e);h.dialog("distory");h=null}},{text:"\u53D6\u6D88",click:function(e){eventCall(c,this,e);h.dialog("distory");h=null}}],close:function(e){eventCall(c,this,e);h.dialog("distory");h=null}})},iframe:function(a,b,c,d,e,f,g,h,i){d=(d==null?false:d);e=(e==null?true:e);f=(f==null?'':f);h=h||13;i=i||208;var j=$('#weishow_dialog_iframe');var k=j.find('iframe');var l=j.length>0;if(l){if(a==='close'){j.dialog(j.attr('isdistory')=='1'?'distory':'close');return}else if(a==='distory'){j.dialog('distory');return}}if(l){var m=k.attr('src');if(m===a){j.dialog('open');return}else j.dialog('distory')}else j.dialog('distory');j=$('<div id="weishow_dialog_iframe" '+(d?'isdistory="1"':'')+' style="display: none;"><div></div></div>').appendTo('body');k=$('<iframe frameborder="0" scrolling="no" marginheight="0" marginwidth="0" height="'+c+'" width="100%" src="about:blank" ></iframe>');j.append(k);j.dialog({title:f,autoOpen:true,hasborder:false,width:b,height:c,modal:e,background:''}).hide();var n=$('<img src="'+(g||'http://sr.9513.com/live/css/weishow.dialog/images/loading.gif')+'" />');var o=$('<div style="position:absolute;top:left:"></div>').insertBefore(j);o.append(n);o.css("left",(b-i)/2).css("top",(c-h)/2);k.attr('src',a).load(function(){o.remove();o=null;j.fadeIn()});return j}})})(jQuery);
//live
/*
 *	web聊天室js版 by mjw
 *  identity:1主播、2超管、3管理、4VIP、5榜单用户、6普通用户、7游客、8代理、9副室主、10巡管、11一房多麦主播
 *  vipLevel:1黄P、2紫P、3黑P、4财主、5至尊
 *  userLevel:1-26 v1-v26  100秀场王后、101秀场之王
 */
var playList = {};//当前房间所有用户
var lwRef = false;//当前礼物是否在刷新
var YKIDX = {};//游客IDX记录表
(function(window, undefined) {
    var sr = 'http://sr.9513.com/live/';
    var $ = jQuery;
    var WebChat = (function() {
        var WebChat = {
            //将变量jw的控制权让渡给第一个实现它的那个库。
            noConflict: function(deep) {
                if(window.jw===WebChat) {
                    window.jw = _jw;
                }
                if(deep && window.WebChat===WebChat) {
                    window.WebChat = _WebChat;
                }
                return WebChat;
            },
            //初始化 useridx用户IDX,roomidx房间IDX
            init: function(useridx, roomidx) {
                var from = window.urlQueryString?urlQueryString('from',true):'';
                if(from==='pptv'){
                    WebChat.Config.pay_url='http://show.pptv.com/pay?gid=sinashow';
                }else{
                    if(pagedata.fromsource==1){
                        WebChat.Config.pay_url='/User/Pay.aspx'+(from=='tuli'?'?from=tuli':'');
                    }
                }
                WebChat.Config.error.msg201 = "<a href='" + WebChat.Config.pay_url + "' target='_blank' hidefocus='true'>余额不足！</a>";

                WebChat.Config.data.idx = useridx;
                //设置默认收礼人为主播
                WebChat.Config.data.roomidx = WebChat.Comm.sendGift.data.accpetidx = roomidx;
                //初始化DOM
                WebChat.Doms.init();
                //初始化TAB
                WebChat.Events.init();
                
                //设置默认消息接收人为主播
                WebChat.Events.setMsgTo(roomidx, pagedata.anchorscreename);
                if (useridx <= 0) {
                    //游客进入设置默认消息接收人为所有人
                    WebChat.Events.setMsgTo(0, '所有人');
                }
                return WebChat;
            },
            //公共显示消息
            Message: {
                //公告
                affiche: {
                    //添加公告
                    append: function(msg) {
                        msg = "<li>" + msg;
                        msg += "</li>";

                        WebChat.Doms.Left.affiche.html(msg);
                    },
                    //清空公告
                    clear: function() {
                        WebChat.Doms.Left.affiche.empty();
                    }
                },
                //聊天信息
                chat: {
                    public: { //Message.chat.public.append
                        //添加消息到公共模块
                        append: function(msg) {
                            if(WebChat.Doms.Right.public.children().length >= WebChat.Config.clearnum) {
                                if(WebChat.Events.brushGift.intervalid == null) {
                                    WebChat.Doms.Right.public.find("li:first").remove();
                                } else {
                                    this.clear();
                                }
                            }
                            msg = '<li>' + msg;
                            msg += '</li>';
                            WebChat.Doms.Right.public.append(msg);

                            this.scroll();
                        },
                        //清空公共模块消息
                        clear: function() {
                            WebChat.Doms.Right.public.empty();
                            //IE释放内存
                            if($.browser.msie && CollectGarbage)
                                CollectGarbage();
                        },
                        //公聊滚动条处理
                        scroll: function(dom) {
                            //滚动条处理
                            /*
                            if (WebChat.Config.public_autoscroll && WebChat.Doms.Right.public.scrollTop() != null) {
                                WebChat.Doms.Right.public.parent().parent().append(WebChat.Doms.Right.public);
                                WebChat.Doms.Right.public.scrollTop(WebChat.Doms.Right.public[0].scrollHeight);
                            }*/
                        },
                        //系统消息
                        system: function (msg, time) {//Message.chat.public.system
                            if(WebChat.Doms.Right.public.children().length >= WebChat.Config.clearnum) {
                                if(WebChat.Events.brushGift.intervalid == null) {
                                    WebChat.Doms.Right.public.find("ul:first").remove();
                                } else {
                                    this.clear();
                                }
                            }
                            WebChat.Doms.Right.public.append('<li>' + (time == null ? WebChat.getTime() : time) + '<span class="system">【系统消息】' + msg + '</span></li>');
                            this.scroll();
                        }
                    },
                    private: {
                        //添加消息到私人模块
                        append: function(msg) {
                            if(WebChat.Doms.Right.private.children().length >= WebChat.Config.clearnum) {
                                WebChat.Doms.Right.private.find("li[id!='CC630706-5681-4C97-9F2E-B11F5B9469CE']:first").remove();
                            }
                            msg = '<li>' + msg;
                            msg += '</li>';
                            WebChat.Doms.Right.private.append(msg);

                            this.scroll();
                        },
                        //清空私人模块消息
                        clear: function() {
                            WebChat.Doms.Right.private.find("li[id!='CC630706-5681-4C97-9F2E-B11F5B9469CE']:not(:contains('【系统消息】欢迎您进入房间，请'))").remove();
                            //IE释放内存
                            if($.browser.msie && CollectGarbage)
                                CollectGarbage();
                        },
                        //滚动条处理
                        scroll: function() {
                            //滚动条处理
                            /*
                            if(WebChat.Config.private_autoscroll && WebChat.Doms.Right.private.scrollTop() != null) {
                                WebChat.Doms.Right.private.scrollTop(WebChat.Doms.Right.private[0].scrollHeight);
                            }*/
                        },
                        //系统消息 private.system
                        system: function(msg, time, type, url) {
                            if(WebChat.Doms.Right.private.children().length >= WebChat.Config.clearnum) {
                                WebChat.Doms.Right.private.find("li[id!='CC630706-5681-4C97-9F2E-B11F5B9469CE']:first").remove();
                            }
                            if(type == 0) {
                                var gg = WebChat.Doms.Right.private.find("#CC630706-5681-4C97-9F2E-B11F5B9469CE");
                                var from = urlQueryString('from', true);
                                if(from==="tuli")
                                    msg = '<a href="' +(url == null ? WebChat.Config.pay_url : url) + '" hidefocus="true">【公告】：' + msg + '</a>';                                
                                else 
                                    msg = '<a href="' +(url == null ? WebChat.Config.pay_url : url) + '" target="_blank" hidefocus="true">【公告】：' + msg + '</a>';
                                if(gg.length != 0) {
                                    gg.html(msg);
                                    return;
                                } else {
                                    var first = WebChat.Doms.Right.private.find(":first");
                                    msg = "<li id='CC630706-5681-4C97-9F2E-B11F5B9469CE'>" + (time == null ? WebChat.getTime() : time) + msg + '</li>';
                                    if(first.length == 0) {
                                        WebChat.Doms.Right.private.append(msg);
                                    }
                                    else {
                                        first.before(msg);
                                    }
                                    return;
                                }
                            } else {
                                WebChat.Doms.Right.private.append('<li>' + (time == null ? WebChat.getTime() : time) + '<span class="system">【系统消息】' + msg + '</span></li>');

                                this.scroll();
                            }
                        }
                    },
                    Addlb: {  //Addlb.append
                        append: function(msg,isall,isjump,type) {
                            
                            if(!WebChat.Config.data.hornline){
                                WebChat.Config.data.hornline=setInterval(function(){
                                    var li_hornline_l = WebChat.Doms.Left.lb_list.find('li').length;
                                    if (li_hornline_l > 20 && !lwRef) {
                                        var n = li_hornline_l - 20;
                                        WebChat.Doms.Left.lb_list.find('li:lt(' + n + ')').remove();
                                    } else {
                                        clearInterval(WebChat.Config.data.hornline);
                                        WebChat.Config.data.hornline = null;
                                    }
                                },400); //定时执行,当送礼品展示超出时，则删除掉，保持稳定的个数
                            }
                            var str='';
                            if(isall){
                                str='class="A_ic"';
                            }
                            var noHang = '';//'style="white-space:nowrap;"';//不换行

                            if(type==1)
                                $("#lb_hat").html(msg); //最后一次赠送的礼物

                            var msg = '<li ' + str + ' ' + noHang + '><span class="liMiddle">' + msg;
                            msg += '</span></li>';
                            var li_l = WebChat.Doms.Left.lb_list.find('li').length;
                            if(isjump){
                                if(li_l>=3){
                                    WebChat.Doms.Left.lb_list.find('li').eq(2).after(msg);
                                }
                                else
                                {
                                    WebChat.Doms.Left.lb_list.append(msg);
                                }
                            }
                            else
                            {
                                WebChat.Doms.Left.lb_list.append(msg);
                            }
                            WebChat.Message.chat.Addlb.lblog(msg.replace('style="white-space:nowrap;"'));
                        },
                        //小喇叭具体文字  朱海波  2015-04-23 添加
                        Airing: function (msg) {  //Addlb.Airing

                            //移动盒子, 盒子，步长，移动速度
                            function moveLeft(dom, stepLen, speed) {
                                dom.css({ "position": "relative", "overflow": "hidden" });
                                tempLen = dom.parent().width() - 10;//盒子的宽度（可见区域的长度）
                                //console.log(dom.css("left"))
                                var liLen = 0;//元素总长度
                                var curleft = dom.css("left") == "auto" ? tempLen : dom.offset().left-25;//当前的位置
                                var liLeftWidth = 30;//获取li的间距
                                dom.css({ "width": "1000%"});

                                var siv = setInterval(function () {
                                    //执行滚动
                                    curleft = curleft - stepLen;//当前的left位置
                                    dom.css({ "left": curleft });
                                    var width = 0;
                                    dom.find('li').each(function () {
                                        var tempwidth = parseInt($(this).width());
                                        if (tempwidth>0)
                                            width += tempwidth + liLeftWidth;
                                    });
                                    //console.log(tempLen - width,tempLen, width, curleft)
                                    if (tempLen - width > curleft) {
                                        clearInterval(siv);//取消滑动
                                    }
                                },speed);
                            }

                            /*
                            if (!WebChat.Doms.Right.btnxlb_ScrollList.setInterval) {
                                var stepLen = 1;//滚动的步长，越大滚动越快
                                var speed = 20; //移动速度(毫秒),越大滚动越慢

                                var gg = WebChat.Doms.Right.btnxlb_ScrollList.parent();//喇叭外部盒子
                                gg.css({ "position": "relative", "overflow": "hidden" });
                                var tempLen = gg.width();//盒子的宽度（可见区域的长度）
                                var liLen = 0;//元素总长度
                                var curleft = 0;//当前的位置
                                var liLeftWidth = parseInt(WebChat.Doms.Right.btnxlb_ScrollList.find("li").css("margin-left"));//获取li的间距
                                WebChat.Doms.Right.btnxlb_ScrollList.css({ "position": "relative", "width": "1000%", "left": tempLen })
                                calculate();//计算当前滚动内容的总长度

                                WebChat.Doms.Right.btnxlb_ScrollList.setInterval = setInterval(function () {
                                    //定时执行,当送礼品展示超出时，则删除掉，保持稳定的个数
                                    var li_btnxlb_ScrollList = WebChat.Doms.Right.btnxlb_ScrollList.find('li').length;
                                    if (li_btnxlb_ScrollList > 4) {
                                        var me = WebChat.Doms.Right.btnxlb_ScrollList.find('li').eq(0);
                                        if (me.offset().left + me.width() < 0) {
                                            tempLen = tempLen + me.width();
                                            me.remove();
                                        }
                                    }
                                    //执行滚动
                                    curleft = tempLen - stepLen;//当前的left位置
                                    if (curleft < -liLen)
                                        curleft = gg.width();
                                    tempLen = curleft;
                                    WebChat.Doms.Right.btnxlb_ScrollList.css({ "left": curleft });
                                    calculate();
                                }, speed);


                                //计算元素总长度
                                function calculate() {
                                    var tempLiLen = 0;
                                    WebChat.Doms.Right.btnxlb_ScrollList.find("li").each(function () {
                                        var me = $(this);
                                        tempLiLen += me.width() + liLeftWidth;
                                    });
                                    if (liLen != tempLiLen)
                                        liLen = tempLiLen;
                                    //console.log(liLen);
                                }
                            }
                            */
                            if (WebChat.Config.data.labaNum > 0)
                                WebChat.Config.data.labaNum = WebChat.Config.data.labaNum - 1;
                            msg = '<li>' + msg+'</li>';
                            msg = $(msg);//jquery化
                            WebChat.Doms.Right.btnxlb_ScrollList.append(msg);

                            moveLeft(WebChat.Doms.Right.btnxlb_ScrollList,30,20);//滑动广播

                        },
                        system: function (msg,type) { //  Addlb.system                            
                            //                              if(!WebChat.Config.data.hornline){
                            //                                   WebChat.Config.data.hornline=setInterval(function(){
                            //                                       var li_hornline_l1 = WebChat.Doms.Left.lb_list.find('li').length;
                            //                                       if(li_hornline_l1>3){
                            //                                             WebChat.Doms.Left.lb_list.find('li').eq(0).remove();
                            //                                       } 
                            //                                   },2000);
                            //                              }
                            //                              msg = '<li style="white-space:nowrap;"><em>[系统消息]</em>' + msg;
                            //                              msg += '</li>';

                            var typetxt = "系统消息";
                            switch (type) {
                                case 1:  //中奖消息
                                    typetxt = "中奖消息";
                                    break;
                            }

                            msg = '<span class="liMiddle"><em>[' + typetxt + ']</em>' + msg + "</span>";
                            
                            WebChat.Message.chat.Addlb.append(msg,false,false,type);
                            //WebChat.Message.chat.Addlb.lblog(msg.replace('style="white-space:nowrap;"'));
                        },
                        lblog:function(msg){
                            var _l=$("#horn_loglist").find("li").length;
                            if(_l>=50){
                                $("#horn_loglist").find("li").eq(0).remove();
                            }
                            $("#horn_loglist").append(msg); 
                        }
                    }
                },
                //                //日志
                //                blog: {
                //                    //添加日志
                //                    append: function (msg) {
                //                        msg = '<li>' + msg + '</li>';
                //                        WebChat.Doms.Right.talk_blogs.append(msg);
                //                    },
                //                    //清空日志
                //                    clear: function () {
                //                        WebChat.Doms.Right.talk_blogs.empty();
                //                    }
                //                },
                //                //礼物记录
                //                gift: {
                //                    //添加记录
                //                    append: function (msg) {
                //                        WebChat.Doms.Right.talk_gift_list.append(msg);
                //                    },
                //                    //清空礼物记录
                //                    clear: function () {
                //                        WebChat.Doms.Right.talk_gift_list.empty();
                //                    }
                //                },
                //显示普通消息   Message.alert
                alert: function(msg, ok, cancel, t, width, modal, noclose, buttontext) {
                    var _position = WebChat.Doms.Right.talk_tabs.offset();
                    var _win = $(window);
                    var _height = 185;
                    if(buttontext == null) {
                        buttontext = "确定";
                    }
                    var isnotzb = true;
                    if(isAnchor()) {
                        isnotzb = false;
                        _position = [_position.left + 5, (_win.height() - _height) / 2 + _win.scrollTop()];
                    } else {
                        if (window.urlQueryString) {
                            var from = urlQueryString('from', true);
                            if (from === 'xl'||from === 'pptv'||from === 'tuli') {
                                _position = [(_win.width() - 400) / 2, 300];
                            } else {
                                _position = null;
                            }
                        } else {
                            _position = null;
                        }
                    }
                    //绑定提示对话框
                    WebChat.Doms.Other.alert.dialog({
                        title: (t == null ? '提示' : t),
                        autoOpen: false,
                        modal: modal == null ? false : modal,
                        width: width == null ? 400 : width,
                        height: _height,
                        hasclose: (!noclose),
                        draggable: (isnotzb || !$.browser.msie),
                        position: _position,
                        autoresize: isnotzb,
                        close: function() {
                            if(cancel == null) return;
                            cancel();
                        },
                        buttons: [{
                            text: buttontext, click: function() {
                                WebChat.Doms.Other.alert.dialog("close");
                                if(ok == null) return;
                                ok();
                            }
                        }]
                    });

                    WebChat.Doms.Other.alert.html(msg).dialog("open");
                    WebChat.Doms.Other.alert.find("input:first,textarea:first").setFocus();
                },
                //显示确认提示框
                confirm: function(msg, ok, cancel, t, width, modal, buttonok_text, buttoncancel_text) {
                    var _position = WebChat.Doms.Right.talk_tabs.offset();
                    var _win = $(window);
                    var _height = 185;
                    if(buttonok_text == null) {
                        buttonok_text = "确定";
                    }
                    if(buttoncancel_text == null) {
                        buttoncancel_text = "取消";
                    }
                    var isnotzb = true;
                    if(isAnchor()) {
                        isnotzb = false;
                        _position = [_position.left + 5, (_win.height() - _height) / 2 + _win.scrollTop()];
                    } else {
                        if (window.urlQueryString) {
                            var from = urlQueryString('from', true);
                            if (from === 'xl'||from === 'pptv'||from === 'tuli') {
                                _position = [(_win.width() - 400) / 2, 300];
                            } else {
                                _position = null;
                            }
                        } else {
                            _position = null;
                        }
                    }
                    //绑定确认提示对话框
                    WebChat.Doms.Other.confirm.dialog({
                        title: (t == null ? '提示' : t),
                        modal: modal == null ? false : modal,
                        autoOpen: false,
                        draggable: (isnotzb || !$.browser.msie),
                        position: _position,
                        autoresize: isnotzb,
                        width: width == null ? 400 : width,
                        height: _height,
                        close: function() {
                            if(cancel == null) return;
                            cancel();
                        },
                        buttons: [{ text: buttonok_text, click: function() {
                            WebChat.Doms.Other.confirm.dialog("close");
                            if(ok == null) return;
                            ok();
                        }
                        }, { text: buttoncancel_text, click: function() {
                            WebChat.Doms.Other.confirm.dialog("close");
                            if(cancel == null) return;
                            cancel();
                        }
                        }]
                    });
                    WebChat.Doms.Other.confirm.html(msg).dialog("open");
                    WebChat.Doms.Other.confirm.find("input:first,textarea:first").setFocus();
                },
                //                //用户注册
                //                pleasereg: function (t) {
                //                    WebChat.Doms.Other.login.dialog("close");
                //                    WebChat.Doms.Other.reg.dialog({
                //                        title:(t == null ? '新用户注册' : (t + ' - 请注册')),
                //                        autoOpen: false,
                //                        modal: true,
                //                        height:475,
                //                        width: 450
                //                    });
                //                    WebChat.Doms.Other.reg.dialog("open");
                //                    var src= WebChat.Doms.Other.reg.find("iframe").attr("src");
                //                    if(src!="/reg.aspx")
                //                    WebChat.Doms.Other.reg.find("iframe").attr("src","/reg.aspx");
                //                },
                //登录窗口
                pleaselogin: function(t, istop) {
                    if(istop == null && pagedata.chaturl) {
                        this.alert('录像模式不允许此操作！');
                        return;
                    }
                    if(window.WBtopPublic && WBtopPublic.showLoginLayer) {
                        WBtopPublic.showLoginLayer('zh-cn');
                        return;
                    }
                    t = (t == null ? '请登录' : (t + ' - <span style="color:#ff66cc;">请登录</span>！'));
                    if(WebChat.Doms.Other.login.dialog("iscreated")) {
                        WebChat.Doms.Other.login.dialog("getparent").find(".txt:first").html(t);
                        WebChat.Doms.Other.login.dialog("open");
                        return;
                    }
                    WebChat.Doms.Other.login.dialog({
                        title: t,
                        autoOpen: false,
                        modal: true,
                        width: 350
                    });
                    WebChat.Doms.Other.login.dialog("open");
                    var src = WebChat.Doms.Other.login.find("iframe").attr("src");
                    if(src&&src.length == 11)
                        WebChat.Doms.Other.login.find("iframe").attr("src", WebChat.Config.weibologin);
                },
                //下载插件提示
                pleasecj: function(t, n, modal, hasclose) {
                    var _position = WebChat.Doms.Left.left.offset();
                    WebChat.Doms.Other.alert.dialog({
                        title: (t == null ? '插件安装' : t),
                        autoOpen: false,
                        modal: (modal == null ? true : modal),
                        width: 400,
                        draggable: true,
                        hasclose: (hasclose == null ? true : hasclose),
                        buttons: [{
                            text: '下载插件', click: function() {
                                window.open(sr + 'cj/LiveShow.exe');
                                //WebChat.Doms.Other.alert.dialog("close");
                            }
                        }]
                    });
                    if(!n) n = '您的插件不是最新或者没有安装插件！<br/>（下载安装完成以后请重新打开浏览器）';
                    WebChat.Doms.Other.alert.html(n).dialog("open");
                },
                //转移观众窗口
                moveuser: function() {
                    var guid = WebChat.getGuid();
                    WebChat.Message.confirm('<div class="center"><input id="' + guid + '" maxlength="20" /></div>', function() {
                        WebChat.Comm.adminControl.sendcopyplayerInfo.data.toroomidx = WebChat.Doms.Other.confirm.find("#" + guid).val();
                        WebChat.Comm.adminControl.sendcopyplayerInfo.send(WebChat.Comm.adminControl.sendcopyplayerInfo.data);
                    }, null, "请输入转入房间号码");
                },
                //创建直播室窗口
                createlive: function() {
                    var _html = '', _t = '创建直播';
                    var _style=' style="line-height:25px;"';
                    if(pagedata.isofficial) {
                        var ismulti=pagedata.roomtype===jw.Config.roomtype.multimic;
                        _html = '<li'+_style+'><input type="radio" id="radgk" name="cjzb" checked="true" /><label hidefocus="true" for="radgk">'+(ismulti?'普通麦':'公开')+'<span style="color: #737373;">（任何人都可以观看）</span></label></li>';
                        if(ismulti){
                            _html += '<li'+_style+'><input type="radio" id="radvip" name="cjzb" /><label hidefocus="true" for="radvip">VIP麦<span style="color: #737373;">（只有VIP的用户才可以观看）</span></label></li>';
                        }else{
                            _html += '<li'+_style+'><input type="radio" id="radjm" name="cjzb" /><label hidefocus="true" for="radjm">加密<span style="color: #737373;">（需输入密码才可以观看）</span></label></li><li'+_style+'><input type="radio" id="radff" name="cjzb"  /><label hidefocus="true" for="radff">付费<span style="color: #737373;">（入场观众需付费观看）</span></label></li>';
                        }
                    }
                    else { 
                        //_t='选择开播类型';
                        //_html='<li><input type="radio" id="radxrwt" name="cjzb" checked="true" /><label hidefocus="true" for="radxrwt">新人舞台<span style="color: #737373;">（我是新人秀才华）</span></label></li><li><input type="radio" id="radyxgh" name="cjzb" /><label hidefocus="true" for="radyxgh">游戏公会<span style="color: #737373;">（集聚游戏发烧友）</span></label></li><li><input type="radio" id="raddzsw" name="cjzb"  /><label hidefocus="true" for="raddzsw">电子商务<span style="color: #737373;">（畅聊电子商务信息）</span></label></li>';
                        _html = '<li'+_style+'><input type="radio" id="radgk" name="cjzb" checked="true" /><label hidefocus="true" for="radgk">公开<span style="color: #737373;">（任何人都可以观看）</span></label></li>';
                    }
                    var _send = function(type, password, roompay) {
                        if(!WebChat.Comm.sendChat.inRoomTime) {
                            WebChat.Message.alert('房间加载中，请稍候！');
                            WebChat.Comm.adminControl.reSetLive.send();
                            return;
                        }
                        password = password || '';
                        roompay = roompay || 0;
                        WebChat.Comm.adminControl.sendCreateLive.data.roomFla = type;
                        WebChat.Comm.adminControl.sendCreateLive.data.passWord = password;
                        WebChat.Comm.adminControl.sendCreateLive.data.roomPay = roompay;
                        WebChat.Comm.adminControl.sendCreateLive.send(WebChat.Comm.adminControl.sendCreateLive.data);
                        $("#movie_cj").show();
                    };
                    WebChat.Message.confirm('<div style="width:220px;margin:0 auto;"><ul style="text-align:left;">' + _html + '</ul></div>', function() {
                        if(WebChat.Doms.Other.confirm.find("#radgk:checked").length) {
                            _send(1);
                        } else if(WebChat.Doms.Other.confirm.find("#radjm:checked").length) {
                            WebChat.Message.alert('<div class="center"><input id="txtradjm" type="password" /></div>', function() {
                                var mm = WebChat.Doms.Other.alert.find("#txtradjm").val();
                                if(mm.length == 0) {
                                    alert("密码不能为空！");
                                    WebChat.Doms.Other.confirm.dialog("open");
                                    return;
                                }
                                _send(3, mm);
                                WebChat.Doms.Other.btnviewpwd.show();
                            }, WebChat.Comm.adminControl.reSetLive.send, '请输入预设密码');
                        } else if(WebChat.Doms.Other.confirm.find("#radff:checked").length) {
                            WebChat.Message.alert('<div class="center"><input id="txtradff" type="text" /></div>', function() {
                                var ff = WebChat.Doms.Other.alert.find("#txtradff").val();
                                if((!WebChat.isNumber(ff)) || parseInt(ff) == 0) {
                                    alert("金额请输入大于0的整数！");
                                    WebChat.Doms.Other.confirm.dialog("open");
                                    return;
                                }
                                if(ff < WebChat.Config.roompay_min || ff > WebChat.Config.roompay_max) {
                                    alert("金额必须在" + WebChat.Config.roompay_min + "-" + WebChat.Config.roompay_max + "之间！");
                                    WebChat.Doms.Other.confirm.dialog("open");
                                    return;
                                }
                                _send(2, null, ff);
                            }, WebChat.Comm.adminControl.reSetLive.send, '请输入需付费金额');
                        } else if(WebChat.Doms.Other.confirm.find("#radxrwt:checked").length) {
                            _send(4);
                        } else if(WebChat.Doms.Other.confirm.find("#radyxgh:checked").length) {
                            _send(5);
                        } else if(WebChat.Doms.Other.confirm.find("#raddzsw:checked").length) {
                            _send(6);
                        } else if(WebChat.Doms.Other.confirm.find("#radvip:checked").length){
                            _send(7);
                        }
                    }, WebChat.Comm.adminControl.reSetLive.send, _t);
                },
                //请付费
                pleasepay: function(pay) {
                    WebChat.Message.confirm('<div class="center">该房间为付费房间，需付费<span class="num">' + pay + '</span>币后才能观看！您确定要付费吗？</div>', function() {
                        WebChat.Comm.userControl.sendPayMoney.data.roomPay = pay;
                        WebChat.Comm.userControl.sendPayMoney.send(WebChat.Comm.userControl.sendPayMoney.data);
                    }, function() {
                        alert('付费房间必须付费才能进入！');
                        window.opener = null;
                        window.open("", "_self");
                        window.close();
                    }, '请付费', 400, true);
                },
                //输入密码窗口
                inputpassword: function(t) {
                    var guid = WebChat.getGuid();
                    WebChat.Message.alert('<div class="center">密码：<input id="' + guid + '" type="password" /></div>', function() {
                        WebChat.Comm.userControl.sendPassWord.data.roompwd = WebChat.Doms.Other.alert.find("#" + guid).val();
                        WebChat.Comm.userControl.sendPassWord.send(WebChat.Comm.userControl.sendPassWord.data);
                    }, function() {
                        alert('密码房间必须输入密码才能进入！');
                        window.opener = null;
                        window.open("", "_self");
                        window.close();
                    }, (t == null ? '进入本房间需要密码' : t), 400, true);
                },
                //显示房间密码
                showpassword: function() {
                    var pwd = WebChat.Comm.adminControl.sendCreateLive.data.passWord.length == 0 ? "未设置密码" : WebChat.Comm.adminControl.sendCreateLive.data.passWord;
                    WebChat.Message.alert('<div class="center">密码：' + pwd + '</div>', null, null, "房间密码");
                },
                //显示房间设置
                roomset: function() {
                    var roomopen = WebChat.Comm.adminControl.sendRoomSet.data.roomslt == 0;
                    var rbluseropen = WebChat.Comm.adminControl.sendRoomSet.data.outslt == 1;
                    //<div style="float:right;padding:0px 40px;">房间状态：<input id="rblroomopen"type="radio"name="fjzt" ' + (roomopen ? 'checked="checked"' : '') + ' /><label for="rblroomopen">打开</label>&nbsp;&nbsp;<input id="rblroomclose"type="radio"name="fjzt"' + (roomopen ? '' : 'checked="checked"') + ' /><label for="rblroomclose">关闭</label></div><br/><br/>
                    WebChat.Message.confirm('<div class="center"><div style="padding:0px 40px;">用户进出信息：<input id="rbluseropen"type="radio"name="yhjcxx"' + (rbluseropen ? 'checked="checked"' : '') + ' /><label for="rbluseropen">打开</label>&nbsp;&nbsp;<input id="rbluserclose"type="radio"name="yhjcxx"' + (rbluseropen ? '' : 'checked="checked"') + ' /><label for="rbluserclose">关闭</label></div></div>', function() {
                        WebChat.Comm.adminControl.sendRoomSet.data.roomslt = 0; //WebChat.Doms.Other.confirm.find("#rblroomopen").attr("checked") ? '0' : '1';
                        WebChat.Comm.adminControl.sendRoomSet.data.outslt = WebChat.Doms.Other.confirm.find("#rbluseropen:checked").length == 1 ? '1' : '0';

                        WebChat.Comm.adminControl.sendRoomSet.send(WebChat.Comm.adminControl.sendRoomSet.data);
                        return false;
                    }, null, "房间设置");
                },
                //房间公告
                roomaffice: function() {
                    var guid = WebChat.getGuid();
                    WebChat.Message.confirm('<div class="center"><textarea id="' + guid + '" style="width: 335px; height: 85px">' + WebChat.Doms.Right.private.find("#CC630706-5681-4C97-9F2E-B11F5B9469CE a").html().replace("【公告】：", "") + '</textarea></div>', function() {
                        var msg = $.trim(WebChat.Doms.Other.confirm.find("#" + guid).val());
                        if(msg.length == 0) {
                            alert("公告内容不能为空！");
                            WebChat.Doms.Other.confirm.dialog("open");
                            return;
                        }
                        if(msg.length > WebChat.Config.gg_msgmax) {
                            alert("公告内容不能超过" + WebChat.Config.gg_msgmax + "个字！");
                            WebChat.Doms.Other.confirm.dialog("open");
                            return;
                        }
                        WebChat.Comm.adminControl.sendMsgInfo.data.msg = WebChat.Doms.Other.confirm.find("#" + guid).val().replace(new RegExp('url:', 'gm'), 'url：');
                        WebChat.Comm.adminControl.sendMsgInfo.send(WebChat.Comm.adminControl.sendMsgInfo.data);
                    }, null, '房间公告');
                },
                //                //显示发表日志
                //                showsendblog: function () {
                //                    var guid = WebChat.getGuid();
                //                    WebChat.Message.confirm('<div class="center"><textarea id="' + guid + '" style="width: 335px; height: 85px"></textarea></div>', function () {
                //                        var msg=$.trim(WebChat.Doms.Other.confirm.find("#" + guid).val());
                //                         if(msg.length==0)
                //                        {
                //                            alert("日志内容不能为空！");
                //                            WebChat.Doms.Other.confirm.dialog("open");
                //                            return;
                //                        }
                //                        if(msg.length>WebChat.Config.blog_msgmax)
                //                        {
                //                            alert("日志内容不能超过"+WebChat.Config.blog_msgmax+"个字符！");
                //                            WebChat.Doms.Other.confirm.dialog("open");
                //                            return;
                //                        }
                //                        WebChat.Comm.adminControl.sendBlogInfo.data.msg = WebChat.Doms.Other.confirm.find("#" + guid).val();
                //                        WebChat.Comm.adminControl.sendBlogInfo.send(WebChat.Comm.adminControl.sendBlogInfo.data);
                //                    }, null, '发表日志', 380);
                //                },
                //小喇叭，广播
                xiaolaba: function() {
                    var guid = WebChat.getGuid();
                    var html = '<div id="radioId"><div class="sm_wdlt">您可以输入' + WebChat.Config.xiaolaba_msgmax + '个字(3000星币每条，所有的房间都可以收到！)</div><textarea style="width:330px; height: 85px;" id="' + guid + '"></textarea><div class="sm_wdlt" id="' + guid + 'div">';
                    html += '<a href="javascript:void(0);" onclick="sendemotClick(this, null, 2);return true;"><img src="http://sr.9513.com/live/v3.1.5/images/zbj_face2.png" class="fl" style="margin-left:8px;"></a>';
                    html += '<div class="TC_Tips">您还剩' + WebChat.Config.data.labaNum + '个喇叭</div>';
                    WebChat.Message.alert(html, function () {
                        if(WebChat.Config.data.identity===7 || WebChat.Config.data.identity < 1) {
                            WebChat.Message.pleaselogin("游客不能发送小喇叭");
                            return;
                        }
                        var val = $.trim(WebChat.Doms.Other.alert.find("#" + guid).val()).replace(new RegExp('roomidx\{', 'gm'), 'roomidx﹛');
                        if(val.length == 0) {
                            alert("小喇叭内容不能为空！");
                            WebChat.Doms.Other.alert.dialog("open");
                            return;
                        }
                        if(val.length > WebChat.Config.xiaolaba_msgmax) {
                            alert("发送小喇叭长度不能大于" + WebChat.Config.xiaolaba_msgmax + "个字！");
                            WebChat.Doms.Other.alert.dialog("open");
                            return;
                        }
                        if($("#" + guid + 'chb:checked').length) {
                            val += 'roomidx{' + (pagedata.croomidx||pagedata.vroomidx||WebChat.Config.data.roomidx);
                        }
                        WebChat.Comm.sendLaBaInfo.data.msg = val;
                        WebChat.Comm.sendLaBaInfo.send(WebChat.Comm.sendLaBaInfo.data);
                    }, null, '小喇叭');
                    if(WebChat.Config.data.userLevel > 10)// 11级用户以上才有免费小喇叭
                    {
                        getGradeBar({ sidx: WebChat.Config.data.idx, isrealtime: 1, success: function(data) {
                            if(data.horn) {
                                $("#" + guid + 'div').append('<span style="font-size:12px;color:#ff0000;text-algin:left;padding-left:5px;">您还有' + data.horn + '次免费发送小喇叭机会哦！</span>');
                            }
                        }
                        });
                    }
                },
                //飞屏
                feiping: function() {
                    var guid = WebChat.getGuid();
                    //绑定飞屏弹窗，并绑定弹窗中的确定按钮的单击事件
                    var html = '<div class="center"><div style="padding-bottom: 10px;"><input type="radio" id="' + guid + 'rad1" onclick="$(\'#' + guid + 'tip\').html(\'您可以输入' + WebChat.Config.feiping_msgmax + '个字（500星币每条，本房间飞屏！）\')" checked="true" name="feiping"><label for="' + guid + 'rad1">本房间飞屏</label><input type="radio" id="' + guid + 'rad2" name="feiping" style="margin-left:80px"  onclick="$(\'#' + guid + 'tip\').html(\'您可以输入' + WebChat.Config.feiping_msgmax + '个字（3000星币每条，所有房间飞屏！）\')"><label for="' + guid + 'rad2">所有房间飞屏</label></div><div id="' + guid + 'tip" style="font-size:12px;margin-bottom:5px;">您可以输入' + WebChat.Config.feiping_msgmax + '个字（500星币每条，本房间飞屏！）</div><textarea id="' + guid + '" style="width: 335px; height: 85px;">' + WebChat.Doms.Right.txtmsg.val() + '</textarea></div>';
                    html += '<div class="TC_Tips">您还剩' + WebChat.Config.data.feipingNum + '个飞屏</div>'

                    WebChat.Message.alert(html, function () {
                        if(WebChat.Config.data.identity===7 || WebChat.Config.data.identity < 1) {
                            WebChat.Message.pleaselogin("游客不能发送飞屏");
                            return;
                        }
                        var val = $.trim(WebChat.Doms.Other.alert.find("#" + guid).val());
                        if(val.length == 0) {
                            alert("飞屏内容不能为空！");
                            WebChat.Doms.Other.alert.dialog("open");
                            return;
                        }
                        if(val.length > WebChat.Config.feiping_msgmax) {
                            alert("发送飞屏长度不能大于" + WebChat.Config.feiping_msgmax + "个字！");
                            WebChat.Doms.Other.alert.dialog("open");
                            return;
                        }
                        WebChat.Comm.sendFlyText.data.sendType = WebChat.Doms.Other.alert.find('#' + guid + 'rad1:checked').length;
                        WebChat.Comm.sendFlyText.data.content = val.toChatViewString(true, null, false, 0);
                        WebChat.Comm.sendFlyText.send(WebChat.Comm.sendFlyText.data);
                    }, null, '飞屏');
                },
                //设置海报
                setImage: function(t) {
                    var cur = WebChat.Doms.Right.talk_tabs.offset();
                    var dom = WebChat.Doms.Other.dialog_haibao;
                    if(dom.html().length == 0) {
                        e = '<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=10,0,0,0" width="330" height="448" id="sethaibao" align="middle">';
                        e += '<param name="allowScriptAccess" value="always" /><param name="allowFullScreen" value="false" /><param name="movie" value="' + sr + 'flash/haibao.swf" />';
                        e += '<param name="quality" value="high" /><param name="bgcolor" value="#ffffff" />';
                        e += '<embed src="' + sr + 'flash/haibao.swf" quality="high" bgcolor="#ffffff" width="330" height="448" name="sethaibao" align="middle" allowScriptAccess="always" allowFullScreen="false" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></object>';
                        dom.html(e);
                    }
                    dom.css({ left: cur.left, top: cur.top }).show();
                },
                //设置背景图片
                setBgPic: function(t) {
                    var cur = WebChat.Doms.Right.talk_tabs.offset();
                    var dom = WebChat.Doms.Other.dialog_bgpic;
                    if(dom.html().length == 0) {
                        var e = '<object classid="clsid:d27cdb6e-ae6d-11cf-96b8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=10,0,0,0" width="431" height="179" id="setbgpic" align="middle">';
                        e += '<param name="allowScriptAccess" value="always" /><param name="allowFullScreen" value="false" /><param name="movie" value="' + sr + 'flash/bgset.swf" />';
                        e += '<param name="quality" value="high" /><param name="bgcolor" value="#ffffff" />';
                        e += '<embed src="' + sr + 'flash/bgset.swf" quality="high" bgcolor="#ffffff" width="431" height="179" name="setbgpic" align="middle" allowScriptAccess="always" allowFullScreen="false" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer" /></object>';
                        dom.html(e);
                    }
                    dom.css({ left: cur.left, top: cur.top }).show();
                },
                //设置字体
                setFont: function(position) {
                    if(WebChat.Doms.Other.dialog_font.dialog("iscreated")) {
                        WebChat.Doms.Other.dialog_font.dialog("toggle");
                    }
                    else {
                        if(position == null) {
                            var cur = WebChat.Doms.paodao;
                            var offset = cur.offset();
                            var left = offset.left;
                            var top = offset.top;
                            position = [left, top];
                        }

                        var setfontdefault = function() {
                            var _default = [["color", "#666666"], ["tcolor", "#666666"], ["font-size", "12px"], ["font-weight", "normal"], ["font-style", "normal"], ["text-decoration", "none"]];
                            for(var i = 0, len = _default.length; i < len; i++) {
                                WebChat.Doms.Other.dialog_font_preview.css(_default[i][0], _default[i][1]).data(_default[i][0], _default[i][1]);
                            }
                            WebChat.Doms.Other.dialog_font.find("#dialog-font-fontsize").val("12");
                            WebChat.Doms.Other.dialog_font.dialog("close");
                        };

                        WebChat.Doms.Other.dialog_font.dialog({ title: "字体设置", autoOpen: true, hasclose: true, autoscroll: false, autoresize: false, position: position, width: 320, draggable: (!isAnchor() || !$.browser.msie),
                            buttons: [{
                                text: "确定", click: function() {
                                    if(WebChat.Config.data.identity===7 || WebChat.Config.data.identity < 1) {
                                        WebChat.Message.pleaselogin("游客不能设置字体");
                                        WebChat.Doms.Other.dialog_font.dialog("close");
                                        return false;
                                    }
                                    if((WebChat.Config.data.identity===3 || WebChat.Config.data.identity===4 || WebChat.Config.data.identity===6) && (WebChat.Config.data.vipLevel < 2 || WebChat.Config.data.userLevel < 12) && WebChat.Config.data.vipLevel < 79) {
                                        WebChat.Message.alert('您还没有此权限，需要达到巡抚等级且有紫色VIP时，才可以设置哦！');
                                        setfontdefault();
                                    }
                                    else {
                                        var fpv = WebChat.Doms.Other.dialog_font_preview;
                                        fpv.data("font-size", fpv.css("font-size")).data("font-weight", fpv.css("font-weight")).data("font-style", fpv.css("font-style")).data("text-decoration", fpv.css("text-decoration")).data("tcolor", fpv.data("color"));
                                    }
                                    WebChat.Doms.Other.dialog_font.dialog("close");
                                }
                            }, {
                                text: "默认", click: function() {
                                    setfontdefault();
                                }
                            }], close: function() {
                                setfontdefault();
                            }
                        });

                        //字体颜色
                        $.getScript(WebChat.Config.colourPicker.js, function() {
                            WebChat.Doms.Other.dialog_font.find('#dialog-font-cp').colourPicker({
                                ico: WebChat.Config.colourPicker.ico,
                                title: false
                            });
                        });
                        //自动回复
                        WebChat.Doms.Other.dialog_font.find("#zdhfsz").click(function(e) {
                            WebChat.Doms.Other.dialog_font.dialog("close");
                            WebChat.Message.setAutoRespond(position);

                            WebChat.stopDefault(e);
                        });

                        //字体大小
                        WebChat.Doms.Other.dialog_font.find("#dialog-font-fontsize").change(function() {
                            var val = $(this).val() + "px";
                            WebChat.Doms.Other.dialog_font_preview.css("font-size", val); //.data("font-size",val);
                        });
                        //粗体
                        WebChat.Doms.Other.dialog_font.find("#dialog-font-ct").click(function(evt) {
                            var val = "700";
                            if(WebChat.Doms.Other.dialog_font_preview.css("font-weight") == val) {
                                val = "normal";
                            }
                            WebChat.Doms.Other.dialog_font_preview.css("font-weight", val); //.data("font-weight",val);
                            WebChat.stopDefault(evt);
                        });
                        //斜体
                        WebChat.Doms.Other.dialog_font.find("#dialog-font-xt").click(function(evt) {
                            var val = "italic";
                            if(WebChat.Doms.Other.dialog_font_preview.css("font-style") == val) {
                                val = "normal";
                            }
                            WebChat.Doms.Other.dialog_font_preview.css("font-style", val); //.data("font-style",val);
                            WebChat.stopDefault(evt);
                        });
                        //下划线
                        WebChat.Doms.Other.dialog_font.find("#dialog-font-xhx").click(function(evt) {
                            var val = "underline";
                            if(WebChat.Doms.Other.dialog_font_preview.css("text-decoration") == val) {
                                val = "none";
                            }
                            WebChat.Doms.Other.dialog_font_preview.css("text-decoration", val); //.data("text-decoration",val);
                            WebChat.stopDefault(evt);
                        });
                    }
                },
                //设置自动回复
                setAutoRespond: function(position) {
                    var chkiszdhf = WebChat.Doms.Other.dialog_autorespond.find("#chkiszdhf");
                    var hasnoqx = (WebChat.Config.data.identity===3 || WebChat.Config.data.identity===4 || WebChat.Config.data.identity===6) && (WebChat.Config.data.vipLevel < 2 || WebChat.Config.data.userLevel < 12 && WebChat.Config.data.vipLevel < 79);
                    if(WebChat.Doms.Other.dialog_autorespond.dialog("iscreated")) {
                        chkiszdhf[0].checked = WebChat.Config.autorespond.status == 1;
                        WebChat.Doms.Other.dialog_autorespond.dialog("toggle");
                    }
                    else {
                        var txtmsg = WebChat.Doms.Other.dialog_autorespond.find("#txtautorespond");
                        var cancel = function() {
                            chkiszdhf[0].checked = false;
                            WebChat.Config.autorespond.status = 0;
                            WebChat.Doms.Other.dialog_autorespond.dialog("close");
                        };
                        WebChat.Doms.Other.dialog_autorespond.dialog({ title: "自动回复设置", autoOpen: true, hasclose: true, autoscroll: false, autoresize: false, position: position, width: 320, draggable: (!isAnchor() || !$.browser.msie),
                            load: function() {
                                WebChat.Doms.Other.dialog_autorespond.find('label[for="chkiszdhf"]').html('开启自动回复（' + WebChat.Config.msglengthcontrol + '字以内）');
                            },
                            buttons: [{
                                text: "确定", click: function() {
                                    if(WebChat.Config.data.identity===7 || WebChat.Config.data.identity < 1) {
                                        WebChat.Message.pleaselogin("游客不能设置自动回复");
                                        WebChat.Doms.Other.dialog_autorespond.dialog("close");
                                        return false;
                                    }
                                    var trimmsg = $.trim(txtmsg.val());
                                    var ischecked = chkiszdhf[0].checked;
                                    if(trimmsg.length == 0 && ischecked) {
                                        chkiszdhf[0].checked = false;
                                        txtmsg.val(WebChat.Config.autorespond.msg);
                                        WebChat.Message.alert("自动回复内容不能为空！");
                                        return;
                                    }
                                    if(trimmsg.length > WebChat.Config.msglengthcontrol) {
                                        chkiszdhf[0].checked = false;
                                        WebChat.Message.alert('自动回复内容不能大于' + WebChat.Config.msglengthcontrol + '个字！');
                                        return;
                                    }
                                    if(hasnoqx) {
                                        chkiszdhf[0].checked = false;
                                        WebChat.Message.alert('您还没有此权限，需要达到巡抚等级且有紫色VIP时，才可以设置哦！');
                                        WebChat.Doms.Other.dialog_autorespond.dialog("close");
                                        return;
                                    }
                                    WebChat.Config.autorespond.status = ischecked ? 1 : 0;
                                    WebChat.Doms.Other.dialog_autorespond.dialog("close");
                                    if(trimmsg == WebChat.Config.autorespond.msg) {
                                        return;
                                    }
                                    var msg = escape(trimmsg);
                                    //设置自动回复内容
                                    $.ajax({
                                        type: "POST",
                                        url: WebChat.Config.autorespond.seturl,
                                        data: 'roomidx=' + WebChat.Config.data.roomidx + '&msg=' + msg,
                                        cache: false,
                                        success: function(data) {
                                            if(data == null || data.length == 0) {
                                                return;
                                            }
                                            WebChat.Config.autorespond.msg = trimmsg;
                                        }
                                    });
                                }
                            }, {
                                text: "取消", click: function() {
                                    cancel();
                                }
                            }
                            ], close: function() {
                                cancel();
                            }
                        });

                        WebChat.Doms.Other.dialog_autorespond.find("#ztsz").click(function(e) {
                            WebChat.Doms.Other.dialog_autorespond.dialog("close");
                            WebChat.Message.setFont(position);

                            WebChat.stopDefault(e);
                        });
                        var getautorespond = function() {
                            txtmsg.val("自动回复内容读取中...");
                            //获取自动回复内容
                            $.ajax({
                                type: "POST",
                                url: WebChat.Config.autorespond.geturl,
                                data: 'roomidx=' + WebChat.Config.data.roomidx,
                                cache: false,
                                dataType: "json",
                                success: function(json) {
                                    txtmsg.unbind("click");
                                    if(json == null || json.length == 0) {
                                        txtmsg.val("");
                                        WebChat.Config.autorespond.msg = "";
                                        return;
                                    }
                                    txtmsg.val(json[0].msg);
                                    WebChat.Config.autorespond.msg = json[0].msg;
                                },
                                error: function() {
                                    txtmsg.val("自动回复内容读取失败，点击尝试重新读取！");
                                    txtmsg.unbind("click").bind("click", function() {
                                        getautorespond();
                                    });
                                }
                            });
                        };
                        if(!hasnoqx) {
                            getautorespond();
                        }
                    }

                    WebChat.Doms.Other.dialog_autorespond.find("textarea:first").focus();
                },
                //踢人时间设置
                setoutPlay: function(name) {
                    var guid = WebChat.getGuid();
                    WebChat.Message.confirm('<div class="center"><label><input value="60" type="radio" name="time" />1小时</label><label><input value="300" type="radio" name="time" checked="checked" />5小时</label><label><input value="500000" type="radio" name="time" />永久</label><label for="zidingyi"><input id="zidingyi" value="-1" type="radio" name="time" />自定义</label><input id="' + guid + '" style="width:40px" maxlength="6" value="' + WebChat.Config.outTime + '" />分钟</div>', function() {
                        var cof = WebChat.Doms.Other.confirm;
                        var value = cof.find("input:checked").attr("value");
                        if(value < 0) {
                            value = cof.find("#" + guid).val();
                            if((!WebChat.isNumber(value)) || parseInt(value, 10) == 0) {
                                alert("自定义时间请输入大于0的整数！");
                                WebChat.Doms.Other.confirm.dialog("open");
                                return;
                            }
                        }
                        WebChat.Comm.userControl.data.time = value;
                        var tipTitle='您确定要将<span style="color:red;">'+name+'('+WebChat.Comm.userControl.data.toidx+')';
                        var _times=WebChat.Comm.userControl.data.time;
                        if(_times==60){
                            tipTitle+='</span>踢出房间1小时吗？';
                        }
                        else if(_times==300)
                        {
                            tipTitle+='</span>踢出房间5小时吗？';
                        }
                        else if(_times==500000)
                        {
                            tipTitle+='</span>永久踢出房间吗？';
                        }
                        else
                        {
                            tipTitle+='</span>踢出房间'+_times+'分钟吗？';
                        }
                        WebChat.Message.confirm('<div class="center">'+tipTitle+'</div>',function(){
                            WebChat.Comm.userControl.sendoutPlays.send(WebChat.Comm.userControl.data);
                        },function(){
                            WebChat.Message.setoutPlay(name);
                        },null,null,null,null,'返回修改');
                        
                    }, null, "踢出时间");
                },
                //错误提示type:0登录失败信息、1私聊失败信息、2送礼失败信息,result:返回的错误number
                error: function (type, result) { //Message.error
                    try {
                        if (!WebChat.Config.error["msg" + type + "0" + result]) {
                            WebChat.Message.chat.private.system("消息代码：" + type + "0" + result);
                            return;
                        }
                        if (type == 0) {
                            if (result == "1") {
                                var isyk = pagedata.usersidx === 0;
                                WebChat.Message.confirm(WebChat.Config.error.msg001, function() {
                                    if (isyk) {
                                        WebChat.Message.pleaselogin();
                                    } else {
                                        var href = WebChat.Config.pay_url;
                                        if (window.urlQueryString) {
                                            var from = urlQueryString('from', true);
                                            if (from == 'xl'||from === 'pptv'||from==='tuli') {
                                                href += '?from=' + from;
                                            }
                                        }
                                        window.location.href = href;
                                    }
                                }, function() {
                                    var href = '/go0';
                                    if (window.urlQueryString) {
                                        var from = urlQueryString('from', true);
                                        if (from == 'xl'||from === 'pptv'||from==='tuli') {
                                            href += '?from=' + from;
                                        }
                                    }
                                    window.location.href = href;
                                }, null, null, true, isyk ? '立即登录' : '立即办理', '随便逛逛');
                            } else {
                                WebChat.Message.alert(WebChat.Config.error["msg00" + result], godefault, godefault, null, null, true);
                            }
                        } else {
                            WebChat.Message.chat.private.system(WebChat.Config.error["msg" + type + "0" + result]);
                        }
                    } catch(e) {}
                }
            },
            //通信模块
            Comm: {
                //搜索用户
                searchPlayer: {
                    data: {
                        key: undefined
                    },
                    send: function(data) {
                        try {
                            var msg = '{"roomidx":"';
                            msg += WebChat.Config.data.roomidx;
                            msg += '","key":"';
                            msg += data.key.toChatSendString();
                            msg += '"}';
                            WebChat.Doms.chatComm.sendSearchPlayer(msg);
                        } catch(e) { }
                    }
                },
                //获取管理员列表
                sendGetManager: {
                    data: {},
                    send: function(data) {
                        try {
                            var user = WebChat.Doms.chatComm.getManager();
                            if(user && user.length)
                                jw.Events.userList.addList(user, 1);
                        } catch(e) { }
                    }
                },
                //获取更多用户列表
                sendGetMorePlayer: {
                    data: {
                        pageindex: 0
                    },
                    send: function(data) {
                        try {
                            var msg = '{"roomidx":"';
                            msg += WebChat.Config.data.roomidx;
                            msg += '","pageindex":"';
                            msg += data.pageindex;
                            msg += '"}';
                            WebChat.Doms.chatComm.sendGetMorePlayer(msg);
                        } catch(e) { }
                    }
                },
                //发送消息
                sendChat: {
                    //最后发送时间
                    lastsend: 0,
                    //最后彩条发送时间
                    lastcolourbar: 0,
                    //最后一条消息
                    lastmsg: '',
                    //发送数据
                    data: {
                        roomidx: '0',
                        toidx: '0',
                        msg: undefined
                    },
                    //发送公聊信息
                    sendMsgChar: function(data) {
                        if(!WebChat.getMessagePower(data.msg, WebChat.Config.data)) {
                            return false;
                        }

                        //检查分享
                        if(!WebChat.Comm.sendChat.checkShare())
                            return false;
                        try {
                            var _idx = WebChat.Config.data.idx;
                            var _msg = data.msg.toChatSendString() + WebChat.getFontOptions();
                            var msg = '{"roomidx":"';
                            msg += data.roomidx;
                            msg += '","idx":"';
                            msg += _idx;
                            msg += '","Msg":"';
                            msg += _msg;
                            msg += '"}';

                            if(WebChat.Comm.sendChat.lastmsg == msg) {
                                WebChat.Message.chat.private.system("禁止重复发言！");
                                return false;
                            }
                            //console.log(msg);
                            WebChat.Doms.chatComm.sendMsgChar(msg);
                            WebChat.Comm.sendChat.lastmsg = msg;

                            //本地显示
                            var json = {
                                time: WebChat.getTime(),
                                Msg: _msg,
                                sendPlayer: WebChat.Config.data
                            };
                            showMsg(json, true);
                        } catch(e) { }
                        return true;
                    },
                    //发送私聊 sendChat.sendMsgToOne
                    sendMsgToOne: function(data) {
                        if(!WebChat.getMessagePower(data.msg, WebChat.Config.data))
                            return false;

                        //检查分享
                        if(!WebChat.Comm.sendChat.checkShare())
                            return false;

                        try {
                            var _msg = data.msg.toChatSendString() + WebChat.getFontOptions();
                            var msg = '{"roomId":"';
                            msg += data.roomidx;
                            msg += '","sendIdx":"';
                            msg += WebChat.Config.data.idx;
                            msg += '","acceptIdx":"';
                            msg += data.toidx;
                            msg += '","sedInfo":"';
                            msg += _msg;
                            msg += '"}';

                            if(WebChat.Comm.sendChat.lastmsg == msg) {
                                WebChat.Message.chat.private.system("禁止重复发言！");
                                return false;
                            }

                            WebChat.Doms.chatComm.sendMsgToOne(msg);
                            WebChat.Comm.sendChat.lastmsg = msg;

                            //本地显示
                            var json = {
                                time: WebChat.getTime(),
                                sedInfo: _msg,
                                sendPlayer: WebChat.Config.data,
                                acceptPlayer: WebChat.getUserJsonOnList(data.toidx, WebChat.Doms.Right.txtmsgto_name.val())
                            };
                            showChatToOne(json, true);
                        } catch(e) { }
                        return true;
                    },
                    //发送悄悄话
                    sendChatQiao: function(data, isautorespond) {
                        if(!WebChat.getMessagePower(data.msg, WebChat.Config.data, true))
                            return false;

                        //检查分享
                        if(!WebChat.Comm.sendChat.checkShare())
                            return false;

                        try {
                            var _msg = data.msg.toChatSendString() + (isautorespond != null ? 'autorespond{' : '') + WebChat.getFontOptions();
                            var msg = '{"roomId":"';
                            msg += data.roomidx;
                            msg += '","sendIdx":"';
                            msg += WebChat.Config.data.idx;
                            msg += '","acceptIdx":"';
                            msg += data.toidx;
                            msg += '","sedInfo":"';
                            msg += _msg;
                            msg += '"}';
                            if(WebChat.Comm.sendChat.lastmsg == msg) {
                                WebChat.Message.chat.private.system("禁止重复发言！");
                                return false;
                            }

                            WebChat.Doms.chatComm.sendChatQiao(msg);
                            WebChat.Comm.sendChat.lastmsg = msg;

                            //本地显示
                            var json = {
                                time: WebChat.getTime(),
                                sedInfo: _msg,
                                sendPlayer: WebChat.Config.data,
                                acceptPlayer: WebChat.getUserJsonOnList(data.toidx, WebChat.Doms.Right.txtmsgto_name.val())
                            };
                            showChatQiao(json, true);
                        } catch(e) { }
                        return true;
                    },
                    //检查分享
                    checkShare: function() {
                        //start普通非V用户发言前须分享
                        if(!WebChat.Config.share.isshare && (WebChat.Config.data.identity===3 || WebChat.Config.data.identity===4 || WebChat.Config.data.identity===6) && WebChat.Config.data.userLevel < 1 && WebChat.Config.data.vipLevel < 79) {
                            var wri_name = 'weishow_room_isgz';
                            var wri = getCookie(wri_name);
                            if(wri != null && wri.length > 0) {
                                $.ajax({
                                    async: false,
                                    cache: false,
                                    timeout: 10000,
                                    url: WebChat.Config.share.seturl
                                });
                                WebChat.Config.share.isshare = true;
                            }
                            else {
                                $.ajax({
                                    async: false,
                                    cache: false,
                                    timeout: 10000,
                                    url: WebChat.Config.share.geturl,
                                    success: function(data) {
                                        if(data == "1") {
                                            setCookie(wri_name, "1", 3);
                                            WebChat.Config.share.isshare = true;
                                        }
                                    }
                                });
                            }
                            if(!WebChat.Config.share.isshare) {
                                //pleaseShare('<span style="color:#ff0000">请先分享您的微博，分享之后，您就可以开始您的聊天之旅了！</span>');
                                vfollow();
                            }
                        }
                        else {
                            WebChat.Config.share.isshare = true;
                        }

                        //end
                        return WebChat.Config.share.isshare;
                    }
                },
                //发送礼物
                sendGift: {
                    //发送数据
                    data: {
                        accpetidx: undefined,
                        giftidx: undefined,
                        gifttype: undefined,
                        giftnum: undefined,
                        sendType: 0
                    },
                    send: function (data) { //sendGift.send
                        if(WebChat.Config.data.identity===7 || WebChat.Config.data.identity < 1) {
                            WebChat.Message.pleaselogin("游客不能赠送礼物");
                            return;
                        }
                        var gift = WebChat.Config.gift.data[data.giftidx];
                        if(gift) {
                            var userlevel = gift.userlevel;
                            if(userlevel) {
                                userlevel = userlevel.split(':');
                                if(WebChat.Config.data.userLevel<parseInt(userlevel[0],10)) {
                                    WebChat.Message.chat.private.system('您的等级未达到'+userlevel[1]+'，不可以赠送该礼物哦！');
                                    return;
                                }
                            }
                        }
                        try {
                            var msg = '{"roomidx":"';
                            msg += WebChat.Config.data.roomidx;
                            msg += '","sendidx":"';
                            msg += WebChat.Config.data.idx;
                            msg += '","acceptIdx":"';
                            msg += data.accpetidx;
                            msg += '","sendGiftidx":"';
                            msg += data.giftidx;
                            msg += '","giftType":"';
                            msg += data.gifttype;
                            msg += '","giftNum":"';
                            msg += data.giftnum;
                            msg += '","sendType":"';
                            msg += data.sendType;
                            msg += '"}';
                            WebChat.Doms.chatComm.sendGift(msg);
                        } catch(e) { }
                    }
                },
                //获取喇叭与飞屏的数量
                GetLaba_FeipingNum: function () {
                    $.ajax({
                        url: WebChat.Config.Laba_FeipingNumUrl,
                        cache: false,
                        dataType: "json",
                        success: function (json) {
                            WebChat.Config.data.labaNum = json.LabaNum;
                            WebChat.Config.data.feipingNum = json.feipingNum;
                        }
                    });
                },
                //发送小喇叭
                sendLaBaInfo: {
                    data: {
                        msg: undefined
                    },
                    send: function(data) {
                        try {
                            WebChat.Doms.chatComm.sendLaBaInfo(data.msg.toChatSendString());
                        } catch(e) { }
                    }
                },
                //显示小喇叭
                showHorn: {
                    data: {},
                    send: function(data) {
                        try {
                            WebChat.Doms.hornComm.receiveHorn(data.name, data.idx, data.msg, data.time, data.url);
                        } catch(e) { }
                    }
                },
                //发送飞屏
                sendFlyText: {
                    data: {
                        sendType: 0,
                        content: ''
                    },
                    send: function(data) {
                        try {
                            var msg = '{"position":"150","size":"30","color":"0",';
                            msg += '"sendType":"' + data.sendType;
                            msg += '","content":"' + data.content;
                            msg += '"}';
                            WebChat.Doms.chatComm.sendFlyText(msg);
                        } catch(e) { }
                    }
                },
                //获取日志
                sendGetBlogList: {
                    send: function() {
                        try {
                            WebChat.Doms.chatComm.sendGetBlogList();
                        } catch(e) { }
                    }
                },
                //用户控制
                userControl: {
                    data: {
                        toidx: undefined,
                        time: 0
                    },
                    //禁止发言
                    sendForbidMsg: {
                        send: function(data) {
                            try {
                                var msg = '{"roomidx":"';
                                msg += WebChat.Config.data.roomidx;
                                msg += '","opidx":"';
                                msg += WebChat.Config.data.idx;
                                msg += '","toidx":"';
                                msg += data.toidx;
                                msg += '"}';
                                WebChat.Doms.chatComm.sendForbidMsg(msg);
                            } catch(e) { }
                        }
                    },
                    //恢复发言
                    sendreset: {
                        send: function(data) {
                            try {
                                var msg = '{"roomidx":"';
                                msg += WebChat.Config.data.roomidx;
                                msg += '","opidx":"';
                                msg += WebChat.Config.data.idx;
                                msg += '","toidx":"';
                                msg += data.toidx;
                                msg += '"}';
                                WebChat.Doms.chatComm.sendreset(msg);
                            } catch(e) { }
                        }
                    },
                    //踢人
                    sendoutPlays: {
                        send: function(data) {
                            try {
                                var msg = '{"roomidx":"';
                                msg += WebChat.Config.data.roomidx;
                                msg += '","opidx":"';
                                msg += WebChat.Config.data.idx;
                                msg += '","toidx":"';
                                msg += data.toidx;
                                msg += '","time":"',
                                msg += data.time;
                                msg += '"}';
                                WebChat.Doms.chatComm.sendoutPlays(msg);
                            } catch(e) { }
                        }
                    },
                    //添加管理
                    sendupManager: {
                        send: function(data) {
                            try {
                                var msg = '{"roomidx":"';
                                msg += WebChat.Config.data.roomidx;
                                msg += '","opidx":"';
                                msg += WebChat.Config.data.idx;
                                msg += '","toidx":"';
                                msg += data.toidx;
                                msg += '"}';
                                WebChat.Doms.chatComm.sendupManager(msg);
                            } catch(e) { }
                        }
                    },
                    //删除管理
                    sendDownManager: {
                        send: function(data) {
                            try {
                                var msg = '{"roomidx":"';
                                msg += WebChat.Config.data.roomidx;
                                msg += '","opidx":"';
                                msg += WebChat.Config.data.idx;
                                msg += '","toidx":"';
                                msg += data.toidx;
                                msg += '"}';
                                WebChat.Doms.chatComm.sendDownManager(msg);
                            } catch(e) { }
                        }
                    },
                    //用户退出
                    sendExitInfo: {
                        data: {},
                        send: function(data) {
                            try {
                                var msg = '{"roomidx":"';
                                msg += WebChat.Config.data.roomidx;
                                msg += '","exitidx":"';
                                msg += WebChat.Config.data.idx;
                                msg += '","exitName":"';
                                msg += username;
                                msg += '"}';
                                WebChat.Doms.chatComm.sendExitInfo(msg);
                            } catch(e) { }
                        }
                    },
                    //收费付款
                    sendPayMoney: {
                        data: {
                            roomPay: 0//付费金额
                        },
                        send: function(data) {
                            try {
                                WebChat.Doms.chatComm.sendPayMoney(data.roomPay);
                            } catch(e) { }
                        }
                    },
                    //发送密码
                    sendPassWord: {
                        data: {
                            roompwd: undefined//房间密码
                        },
                        send: function(data) {
                            try {
                                var msg = '{"roomidx":"';
                                msg += WebChat.Config.data.roomidx;
                                msg += '","roomPwd":"';
                                msg += data.roompwd;
                                msg += '"}';
                                WebChat.Doms.chatComm.sendPassWord(msg);
                            } catch(e) { }
                        }
                    },
                    //发送点歌请求
                    sendMsgSong: {
                        data: {
                            songname: '', //歌名
                            singer: ''//歌手名
                        },
                        send: function(data) {
                            try {
                                var msg = '{"roomidx":"' + WebChat.Config.data.roomidx;
                                msg += '","idx":"';
                                msg += WebChat.Config.data.idx;
                                msg += '","Song_Name":"';
                                msg += data.songname.toChatSendString();
                                msg += '","Singer":"';
                                msg += data.singer.toChatSendString();
                                msg += '"}';

                                WebChat.Doms.chatComm.sendMsgSong(msg);

                                WebChat.Doms.Other.dialog_diangeben.dialog("close");
                                WebChat.Message.alert("点歌成功！");
                            } catch(e) { }
                        }
                    },
                    //隐身请求
                    sendSetHide: {
                        data: {
                            ishide: 0//1隐身0显身
                        },
                        send: function(data) {
                            try {
                                var msg = '{"roomidx":"' + WebChat.Config.data.roomidx;
                                msg += '","sendidx":"';
                                msg += WebChat.Config.data.idx;
                                msg += '","ishide":"';
                                msg += data.ishide;
                                msg += '"}';
                                WebChat.Doms.chatComm.sendSetHide(msg);
                            } catch(e) { }
                        }
                    },
                    //粉丝操作
                    sendFans: {
                        data: {},
                        send: function(data) {
                            try {
                                var msg = '{"roomidx":"' + WebChat.Config.data.roomidx;
                                msg += '","toidx":"';
                                msg +=  data.toidx;
                                msg += '","sendidx":"';
                                msg += WebChat.Config.data.idx;
                                msg += '","sendlevel":"0","type":"';
                                msg += data.type;
                                msg += '"}';
                                WebChat.Doms.chatComm.sendFans(msg);
                                
                                //加收藏
                                if(!WebChat.Config.favorite.isadd)
                                {
                                    $.get(WebChat.Config.favorite.url+'?roomid='+WebChat.Config.data.roomidx);
                                    WebChat.Config.favorite.isadd=true;
                                }
                            } catch(e) { }
                        },
                        //自动关注主播
                        auto: function() {
                            //                            if(WebChat.Config.data.isweibo == 1) {
                            //                                if(!WebChat.Config.data.isfans) {
                            //                                    WebChat.Comm.userControl.sendFans.data.type = 1;
                            //                                    WebChat.Comm.userControl.sendFans.data.toidx=pagedata.currentvidx||pagedata.roomidx;
                            //                                    this.send(WebChat.Comm.userControl.sendFans.data);
                            //                                }
                            //                            }
                            //                            else if(WebChat.Config.data.isweibo == -2) {
                            //                                WebChat.Message.chat.private.system('欢迎您<a href="#" onclick="window.scrollToWb&&scrollToWb();return false;">激活微博</a>，更多得关注主播，了解主播动态！', WebChat.getTime());
                            //                            }
                            //                            
                            //                            WebChat.Comm.userControl.sendFans.auto=function(){};
                        }
                    },
                    //主播发微博
                    sendWeibo: {
                        data: {},
                        send: function(data) {
                            try {
                                var msg = '{"roomidx":"';
                                msg += WebChat.Config.data.roomidx;
                                msg += '","sendidx":"';
                                msg += (data.sendidx ? data.sendidx : WebChat.Config.data.idx);
                                msg += '","msg":"';
                                msg += data.msg;
                                msg += '"}';
                                WebChat.Doms.chatComm.sendWeibo(msg);
                            } catch(e) { }
                        }
                    },
                    //主播发私信
                    sendSixin: {
                        data: {},
                        send: function(data) {
                            try {
                                var msg = '{"roomidx":"';
                                msg += WebChat.Config.data.roomidx;
                                msg += '","sendidx":"';
                                msg += (data.sendidx ? data.sendidx : WebChat.Config.data.idx);
                                msg += '","toidx":"';
                                msg += data.toidx;
                                msg += '","msg":"';
                                msg += data.msg;
                                msg += '"}';
                                WebChat.Doms.chatComm.sendSixin(msg);
                            } catch(e) { }
                        }
                    },
                    //查询IP地址
                    getClientIP: {
                        send: function(data) {
                            $.ajax({
                                url: WebChat.Config.getipurl,
                                data: 'sidx=' + data.toidx,
                                cache: false,
                                success: function(ip) {
                                    if(ip.length > 0) {
                                        WebChat.Message.chat.private.system('<a href="http://ip138.com/ips138.asp?ip=' + ip + '" target="_blank">' + data.name + '的IP地址为' + ip + '</a>');
                                    }
                                    else
                                        WebChat.Message.chat.private.system('未能查询到该用户的IP，请稍候重试！');
                                },
                                error: function() {
                                    WebChat.Message.chat.private.system('IP查询失败，请稍候重试！');
                                }
                            });
                        }
                    },
                    //设置禁止私聊
                    sendForbidPrivateMsg: {
                        data:{},
                        send: function(data) {
                            if(WebChat.Config.data.identity===7 || WebChat.Config.data.identity < 1) {
                                WebChat.Message.pleaselogin("游客不能设置悄悄话");
                                return;
                            }
                            try {
                                var msg = '{"roomidx":"';
                                msg += WebChat.Config.data.roomidx;
                                msg += '","opidx":"';
                                msg += WebChat.Config.data.idx;
                                msg += '","optype":"';
                                msg += data.optype;//0禁止 1允许
                                msg += '"}';
                                WebChat.Doms.chatComm.sendForbidPrivateMsg(msg);
	                            
                                WebChat.Doms.Other.pmgd_qqh.attr('isqqh', data.optype).html('<img src="' + (data.optype ? WebChat.Config.qqhimg.qqh : WebChat.Config.qqhimg.qqhx) + '" />');
                            } catch(e) { }
                        }
                    }
                },
                //主播控制
                adminControl: {
                    //发送房间设置
                    sendCreateLive: {
                        data: {
                            roomFla: '1',
                            passWord: '',
                            roomPay: 0
                        },
                        send: function(data) {
                                var msg = '{"roomidx":"';
                                msg += WebChat.Config.data.roomidx;
                                msg += '","roomFla":"';
                                msg += data.roomFla;
                                msg += '","passWord":"';
                                msg += data.passWord.toChatSendString();
                                msg += '","roomPay":';
                                msg += data.roomPay;
                                msg += '}';
                                WebChat.Doms.chatComm.sendCreateLive(msg);
                        }
                    },
                    //创建直播取消动作
                    reSetLive: {
                        send: function() {
                            WebChat.Doms.videoComm.reSetLive();
                        }
                    },
                    //停止直播
                    sendstopLiveInfo: {
                        data: {
                            result: 1
                        },
                        send: function(data) {
                            try {
                                var msg = '{"roomidx":"';
                                msg += WebChat.Config.data.roomidx;
                                msg += '","result":';
                                msg += data.result;
                                msg += '}';
                                WebChat.Doms.chatComm.sendstopLiveInfo(msg);
                                WebChat.Doms.videoComm.stopLive();
                                WebChat.Comm.adminControl.reSetLive.send();
                            } catch(e) { }
                        }
                    },
                    //转移观众
                    sendcopyplayerInfo: {
                        data: {
                            toroomidx: undefined
                        },
                        send: function(data) {
                            try {
                                var msg = '{"roomidx":"';
                                msg += WebChat.Config.data.roomidx;
                                msg += '","opidx":"';
                                msg += WebChat.Config.data.idx;
                                msg += '","toidx":"';
                                msg += data.toroomidx;
                                msg += '"}';
                                WebChat.Doms.chatComm.sendcopyplayerInfo(msg);
                            } catch(e) { }
                        }
                    },
                    //发送房间公告
                    sendMsgInfo: {
                        data: {
                            msg: undefined
                        },
                        send: function(data) {
                            try {
                                WebChat.Doms.chatComm.sendMsgInfo(data.msg.toChatSendString());
                            } catch(e) { }
                        }
                    },
                    //开启关闭公聊
                    sendisForbid: {
                        data: {
                            state: 1
                        },
                        send: function(data) {
                            try {
                                WebChat.Doms.chatComm.sendisForbid(data.state);
                            } catch(e) { }
                        }
                    },
                    //                    //保存录像
                    //                    sendSaveMove: {
                    //                        data: {},
                    //                        send: function (data) {
                    //                            try {
                    //                                WebChat.Doms.chatComm.sendSaveMove();
                    //                            } catch (e) {}
                    //                        }
                    //                    },
                    //                    //发送日志
                    //                    sendBlogInfo: {
                    //                        data: {
                    //                            msg: undefined
                    //                        },
                    //                        send: function (data) {
                    //                            try {
                    //                                WebChat.Doms.chatComm.sendBlogInfo(data.msg.toChatSendString());
                    //                            } catch (e) {}
                    //                        }
                    //                    },
                    //发送房间设置
                    sendRoomSet: {
                        data: {
                            roomslt: 0,
                            outslt: 1
                        },
                        send: function(data) {
                                var msg = '{"roomslt":';
                                msg += data.roomslt;
                                msg += ',"outslt":';
                                msg += data.outslt;
                                msg += '}';
                                WebChat.Doms.chatComm.sendRoomSet(msg);
                        }
                    },
                    //主播点歌响应(同意或取消)
                    sendSongRe: {
                        data: {
                            sendidx: 0,
                            songname: '',
                            singer: '',
                            respond: 0
                        },
                        send: function(data) {
                            try {
                                var msg = '{"roomidx":"';
                                msg += WebChat.Config.data.roomidx;
                                msg += '","sendidx":"';
                                msg += data.sendidx;
                                msg += '","Song_Name":"';
                                msg += data.songname;
                                msg += '","Singer":"';
                                msg += data.singer;
                                msg += '","re_data":"';
                                msg += data.respond;
                                msg += '"}';
                                WebChat.Doms.chatComm.sendSongRe(msg);
                            } catch(e) { }
                        }
                    }
                },
                //自动播放录像
                playMovie: {
                    send: function() {
                        try {
                            WebChat.Doms.chatComm.playMovie();
                        } catch(e) { }
                    }
                },
                //视频设置图标
                setIcon: {
                    seticonid: null,
                    send: function(x, y, imgurl, url, alt) {
                        try {
                            if(videoready) {
                                 
                                WebChat.Doms.videoComm.setIcon(x, y, imgurl, url, alt);
                            }
                            else {
                                var ResetIcon = function() {
                                    if (videoready) {
                                        WebChat.Doms.videoComm.setIcon(x, y, imgurl, url, alt);
                                        return;
                                    }
                                    setTimeout(ResetIcon, 1000);
                                };
                                ResetIcon();
                            }
                        } catch(e) { }
                    },
                    clear:function () {
                        try {
                            WebChat.Doms.videoComm.clearIcon();
                        } catch(e) { }
                    }
                },
                //获取礼物列表
                sendGetGiftList:{
                    send: function(idx) {
                        try {
                            WebChat.Doms.chatComm.getGiftListData(idx);
                        } catch(e) { }
                    }
                }
            },
            //事件处理   开始绑定时间  初始绑定
            Events: {
                init: function() {
                    //分割线
                    /*
                    WebChat.Doms.Right.talk_split.mousedown(function(e) {
                        var screenY = e.screenY;
                        var h = WebChat.Doms.Right.private.height();
                        WebChat.Doms.Right.talk_tabs.bind("mousemove", function(e2) {
                            var curh = h - (e2.screenY - screenY);
                            if(curh >= WebChat.Config.private_maxheight) {
                                curh = WebChat.Config.private_maxheight;
                            }
                            if(curh <= WebChat.Config.private_minheight) {
                                curh = WebChat.Config.private_minheight;
                            }
                            WebChat.Doms.Right.private.css("height", curh);

                            WebChat.Doms.Right.public.css("height", WebChat.Config.public_defualtheight + (WebChat.Config.private_defualtheight - curh));
                        }).bind("mouseup", function() {
                            WebChat.Doms.Right.talk_tabs.unbind("mousemove");
                        });

                        WebChat.Doms.doc.bind("mouseup", function() {
                            WebChat.Doms.Right.talk_tabs.unbind("mousemove");
                            WebChat.Doms.doc.unbind("mouseup");
                        });
                        return false;
                    });
                    
                     WebChat.Doms.Right.sendxlb_list.click(function() {
	                     var _position=null;
	                     if (window.urlQueryString) {
		                     var from = urlQueryString('from', true);
		                     if (from === 'xl'||from === 'pptv'||from==='tuli') {
			                     _position = [($(window).width() - 400) / 2, 300];
		                     }
	                     }
	                     $("#dialog_lblist").dialog({
		                     title: '喇叭信息',
		                     position:_position,
		                     draggable: true,
		                     autoOpen: true,
		                     width: 500
	                     });
	                     return false;
	                     //WebChat.Doms.body.find("#dialog_lblist").dialog("open");
                     });
                     */
                    //获取免费飞屏与广播的数量
                    WebChat.Comm.GetLaba_FeipingNum();

                    //绑定赠送免费花按钮
                    $("#flowersBtn").click(sendFreeFlowerGiveZB);

                    //绑定抢沙发按钮事件
                    $(document).on("click", ".seatlight", function () {
                        console.log(1);
                        var me = $(this);
                        var SeatId = me.attr("data-Seat");
                        var price = SeatJson[SeatId] * 100;//沙发的价格
                        if (price > 0) {
                            jw.Message.confirm("您本次抢沙发需要花费" + price + "星币。", function () {
                                sendRobSeat(SeatId);
                            });
                        } else {
                            sendRobSeat(SeatId);
                        }
                    });

                    //绑定系统消息
                    LookSystemMessage();



                    //绑定发言按钮
                    WebChat.Doms.Right.btnsend.click(function() {
                        if( WebChat.Doms.Right.btnsend.hasClass('submit_s2')){
                            return;
                        }
                        var msg = $.trim(WebChat.Doms.Right.txtmsg.val());
                        //过滤彩条
                        if(msg.indexOf('\/') > -1) {
                            for(var i = 0, len = WebChat.Config.ct.length; i < len; i++) {
                                msg = msg.replace(new RegExp(WebChat.Config.ct[i].k, "gi"), "");
                            }
                        }

                        //start验证
                        var now = (new Date()).getTime();
                        if((now - WebChat.Comm.sendChat.lastsend) < (WebChat.Config.data.identity===6 && WebChat.Config.data.userLevel < 1 ? WebChat.Config.sendlimit_normal : WebChat.Config.sendlimit)) {
                            /*var tip = "您说得太快了";
                            if((WebChat.Config.data.identity===3 || WebChat.Config.data.identity===4 || WebChat.Config.data.identity===6) && WebChat.Config.data.userLevel < 1 && WebChat.Config.data.vipLevel < 79) {
                                tip += "，普通用户发言间隔时间限定为" + WebChat.Config.sendlimit_normal / 1000 + "秒";
                            }
                            WebChat.Message.chat.private.system(tip + "！", null, 1);*/
                            WebChat.Doms.Right.btnsend.addClass('submit_s2');
                            setTimeout(function(){                                        
                                WebChat.Doms.Right.btnsend.removeClass('submit_s2');
                            },(now - WebChat.Comm.sendChat.lastsend));  
    
                            return;
                        }
                        //end验证

                        //设置发送信息
                        var result = false;
                        WebChat.Comm.sendChat.data.roomidx = WebChat.Config.data.roomidx;
                        WebChat.Comm.sendChat.data.msg = msg;
                        WebChat.Comm.sendChat.data.acceName = WebChat.Doms.Right.txtmsgto_name.val();

                        if(WebChat.Comm.sendChat.data.toidx == 0 || (!WebChat.Doms.Right.chkqqh[0].checked)) {
                            if(WebChat.Comm.sendChat.data.toidx == 0) {
                                //发送公聊消息
                                result = WebChat.Comm.sendChat.sendMsgChar(WebChat.Comm.sendChat.data);
                            } else {
                                //发送私聊消息
                                result = WebChat.Comm.sendChat.sendMsgToOne(WebChat.Comm.sendChat.data);
                            }
                        } else {
                            //发送悄悄话
                            result = WebChat.Comm.sendChat.sendChatQiao(WebChat.Comm.sendChat.data);
                        }
                        if(result) {
                            WebChat.Doms.Right.txtmsg.val("");
                            WebChat.Comm.sendChat.lastsend = now;
                        }
                        else {
                            WebChat.Doms.Right.txtmsg.val(msg);
                        }
                        WebChat.Doms.Right.txtmsg.focus();
                    });

                    //绑定搜索框焦点、输入事件
                    if (WebChat.Doms.Right.txtsearchuser) {
                        WebChat.Doms.Right.txtsearchuser.focus(function () {
                            if (WebChat.Doms.Right.txtsearchuser.val() == "搜索观众") WebChat.Doms.Right.txtsearchuser.val("");
                        }).blur(function () {
                            if (WebChat.Doms.Right.txtsearchuser.val().length == 0) WebChat.Doms.Right.txtsearchuser.val("搜索观众");
                        }).keyup(function () {
                            var val = $.trim(this.value);
                            if (val.length > 0) {
                                WebChat.Doms.Right.txtsearchuser.html("").show();
                                WebChat.Doms.Right.user_list_list.hide();
                                WebChat.Doms.Right.user_list_admin.hide();
                                WebChat.Doms.Right.user_list_mic.hide();

                                if (WebChat.Doms.Right.txtsearchuser.attr("lastsearch") == val) return;
                                WebChat.Doms.Right.txtsearchuser.attr("lastsearch", val);

                                WebChat.Doms.Right.user_list_search.html('<ul class="loading" ><li><img src="' + WebChat.Config.loadingimg + '" /></li></ul>').show();
                                //搜索
                                WebChat.Comm.searchPlayer.data.key = val;
                                WebChat.Comm.searchPlayer.send(WebChat.Comm.searchPlayer.data);
                            } else {
                                WebChat.Doms.Right.user_list_search.hide();
                                var index = WebChat.Doms.Right.txtsearchuser.attr("index");
                                if (!index) index = 0;
                                if (index == 0) {
                                    WebChat.Doms.Right.user_list_list.show();
                                }
                                else if (index == 1) {
                                    WebChat.Doms.Right.user_list_admin.show();
                                }
                                else if (index == 2) {
                                    WebChat.Doms.Right.user_list_mic.show();
                                }
                                WebChat.Doms.Right.txtsearchuser.attr("lastsearch", val);
                            }
                        });
                    }
                    //点击隐藏窗口
                    var bindDocClickshowOther = function(n, autohide) {
                        if(autohide) {
                            WebChat.Doms.doc.one("click", function(e) {
                                var cur = null, cur2 = null,cur3=null,mout;
                                if(n === 0) {
                                    cur = WebChat.Doms.Other.wait_to_name;
                                    cur2 = WebChat.Doms.Right.txtmsgto_name;
                                    WebChat.Doms.doc.one("click",function (e2) {
                                        if(e2.target.id != cur2[0].id)
                                            cur.hide();
                                    });
                                }
                                else if(n === 1) {
                                    cur = WebChat.Doms.Other.ctlist;
                                    cur2 = WebChat.Doms.Right.sendct;
                                }
                                else if(n === 2) {
                                    cur = WebChat.Doms.Other.emotlist;
                                    cur2 = WebChat.Doms.Right.sendemot;
                                }
                                else if(n === 4) {
                                    cur = WebChat.Doms.Other.number;
                                    cur2 = WebChat.Doms.Left.txt_gift_num;
                                    cur3 = WebChat.Doms.Left.txt_gift_num_btn;
                                    mout=$.data(cur, "mout");
                                    WebChat.Doms.doc.one("click",function (e2) {
                                        if ((mout == null || mout == 1) && e2.target.id != cur2[0].id && e2.target.id != cur3[0].id) {
                                            cur.removeData("mout").hide();
                                        }
                                    });
                                }
                                mout=$.data(cur, "mout");
                                if((n === 2||n === 4 ? (mout==null||mout == 1) : true) && e.target.id != cur2[0].id) {
                                    if(n===2){
                                        cur.removeData("mout").dialog("close");
                                        WebChat.Doms.Other.emotlist_face.hide();
                                    }
                                    else if(n===4){
                                        cur.removeData("mout").hide();
                                    }
                                    else {
                                        cur.hide();
                                    }
                                    //WebChat.Doms.doc.unbind("click");
                                }
                            });
                        }

                        if (n !== 0 && WebChat.Doms.Other.wait_to_name)
                            WebChat.Doms.Other.wait_to_name.hide();
                        if (n !== 1 && WebChat.Doms.Other.ctlist)
                            WebChat.Doms.Other.ctlist.hide();
                        if (n !== 2) {
                            if (WebChat.Doms.Other.emotlist)
                                WebChat.Doms.Other.emotlist.dialog("close");
                            if (WebChat.Doms.Other.emotlist_face)
                                WebChat.Doms.Other.emotlist_face.hide();
                        }
                        if (n !== 3) {
                            if (WebChat.Doms.Other.dialog_font)
                                WebChat.Doms.Other.dialog_font.dialog("close");
                            if (WebChat.Doms.Other.dialog_autorespond)
                                WebChat.Doms.Other.dialog_autorespond.dialog('close');
                        }
                        if (n !== 4 && WebChat.Doms.Other.number)
                            WebChat.Doms.Other.number.hide();
                        if (WebChat.Doms.Other.contextmenu)
                            WebChat.Doms.Other.contextmenu.hide();
                    };

                    //绑定消息候选发送人
                    WebChat.Events.setMsgTo(0,'所有人');
                    WebChat.Doms.Right.txtmsgto_name.click(function (e) {
                        var txtmsgto_offset = WebChat.Doms.Right.txtmsgto_name.offset();
                        if($.data(WebChat.Doms.Other.wait_to_name, "seted") === undefined) {
                            WebChat.Doms.Other.wait_to_name.css("left", txtmsgto_offset.left);
                            $.data(WebChat.Doms.Other.wait_to_name, "seted", 1);
                        }
                        WebChat.Doms.Other.wait_to_name.css("top", txtmsgto_offset.top - (WebChat.Doms.Other.wait_to_name.find('>a').length * 25)).toggle().find('>a').each(function(i) {
                            if(i % 2 == 0) $(this).addClass("alt");
                            else
                                $(this).removeClass("alt");
                        });
                        bindDocClickshowOther(0, true);
                    });

                    //绑定彩条按钮点击事件
                    if (WebChat.Doms.Right.sendct){
                        WebChat.Doms.Right.sendct.click(function() {
                            if(WebChat.Doms.Right.sendct.hasClass('Ct_icon_B'))
                            {
                                return false;
                            }
                        
                            if($.data(WebChat.Doms.Other.ctlist, "seted") === undefined) {
                                var _ctlist=[];
                                for(var i=0,len=WebChat.Config.ct.length;i<len;i++){
                                    _ctlist.push('<a code="'+WebChat.Config.ct[i].k+'"'+(i%2===0?' class="alt"':'')+' href="#">'+WebChat.Config.ct[i].n+'</a>');
                                }
                            
                                //绑定彩条鼠标经过、点击事件
                                WebChat.Doms.Other.ctlist.html(_ctlist.join('')).find(">a").click(function() {
                                    if(WebChat.Doms.Right.sendct.hasClass('Ct_icon_B'))
                                    {
                                        return false;
                                    }
                                    var cur = $(this);
                                    var now = (new Date()).getTime();
                                    //if((now - WebChat.Comm.sendChat.lastcolourbar) < WebChat.Config.colourbarlimit) {
                                    //WebChat.Message.chat.private.system("请勿频繁发送彩条！");
                                    WebChat.Doms.Right.sendct.addClass('Ct_icon_B');
                                    //return;
                                    //}
                                    setTimeout(function(){
                                        WebChat.Doms.Right.sendct.removeClass('Ct_icon_B');
                                    },WebChat.Config.colourbarlimit); 
                                    var lastmsg = WebChat.Comm.sendChat.lastmsg;
                                    WebChat.Comm.sendChat.lastmsg = '';

                                    WebChat.Comm.sendChat.data.msg = cur.attr("code");
                                    if(WebChat.Comm.sendChat.sendMsgChar(WebChat.Comm.sendChat.data)) {
                                        WebChat.Comm.sendChat.lastcolourbar = now;
                                        WebChat.Comm.sendChat.lastmsg = lastmsg;
                                    }
                                    WebChat.Doms.Other.ctlist.hide();
                                    return false;
                                }); 
                                var sendct_offset = WebChat.Doms.Right.sendct.offset();
                                WebChat.Doms.Other.ctlist.css("top", sendct_offset.top - 4 - (WebChat.Doms.Other.ctlist.find(">a").length * 25)).css("left", sendct_offset.left).show();
                            
                                $.data(WebChat.Doms.Other.ctlist, "seted", 1);
                            } else {
                                WebChat.Doms.Other.ctlist.toggle();
                            }
                            bindDocClickshowOther(1, true);
                            return false;
                        });
                    }

                    //绑定表情按钮点击事件
                    WebChat.Doms.Right.sendemot.click(function (e) {  sendemotClick(this, e, 1); return false; });
                    
                    //定义表情事件
                    window.sendemotClick = function (me, e, type) {
                        /*if(WebChat.Doms.Other.emotlist.dialog("iscreated")) {
                            WebChat.Doms.Other.emotlist.dialog("toggle");
                        }
                        else { }*/
                        //初始化表情
                        var offset = $(me).offset();
                        var left = offset.left + (WebChat.Config.data.identity===(pagedata.roomtype===jw.Config.roomtype.multimic?11:1) || WebChat.Config.data.mxid == 2 ? 20 : 0) - WebChat.Doms.Other.emotlist.width() / 2+100;
                        var top = offset.top - WebChat.Doms.Other.emotlist.height() - 53;

                        var title = '';
                        var content = '';
                        for(var i = 0, len = WebChat.Config.emot.length; i < len; i++) {
                            title += '<a href="#" hidefocus="true">' + WebChat.Config.emot[i].name + '</a>&nbsp;&nbsp;';
                            content += '<div class="panel" ' + (i == 0 ? '' : 'style="display:none"') + '></div>';
                        }
                        title += '<div class="clearit"></div>';
                        WebChat.Doms.Other.emotlist.html(content).dialog({
                            title: title, width: 400, autoOpen: true, position: [left, top], autoscroll: false, autoresize: false,
                            draggable: (!isAnchor() || !$.browser.msie), load: function() {
                                WebChat.Events.initEmot(0, WebChat.Doms.Other.emotlist.find("div[class='panel']:first"), type);
                                //WebChat.Doms.Other.emotlist.parents(".dialog").css({ "z-index": "999" });
                                WebChat.Doms.Other.emotlist.parent().prev().find("a").each(function(i) {
                                    $(this).click(function() { //选项卡
                                        var panel = WebChat.Doms.Other.emotlist.find("div[class='panel']:eq(" + i + ")").show();
                                        panel.siblings().hide();
                                        WebChat.Events.initEmot(i, panel, type);
                                        //$(this).parent().addClass("okli").siblings().removeClass("okli");
                                        return false;
                                    });
                                });
                            }
                        });
                        WebChat.Doms.Other.emotlist.dialog("getparent").hover(function() { $.data(WebChat.Doms.Other.emotlist, "mout", 0); }, function() { $.data(WebChat.Doms.Other.emotlist, "mout", 1); });
                        //bindDocClickshowOther(2, true);
                        return false;
                    }


                    //聊天设置 按钮
                    if (WebChat.Doms.Right.chatoptions) {
                        WebChat.Doms.Right.chatoptions.click(function () {
                            WebChat.Message.setFont();

                            bindDocClickshowOther(3, false);
                            return false;
                        });
                    }

                    //绑定发送小喇叭按钮
                    if (WebChat.Doms.Right.sendxlb) {
                        WebChat.Doms.Right.sendxlb.click(function () {

                            WebChat.Message.xiaolaba();

                            bindDocClickshowOther(5, false);
                            return false;
                        });
                    }

                    //绑定发送飞屏按钮
                    WebChat.Doms.Right.btnfeiping.click(function() {
                        WebChat.Message.feiping();

                        bindDocClickshowOther(5, false);
                        return false;
                    });

                    //发送抱麦消息
                    var sendBaoMai = function(idx, mxid) {
                        WebChat.Comm.userControl.sendBaoMai.data.toidx = idx;
                        WebChat.Comm.userControl.sendBaoMai.data.mxid = mxid;
                        WebChat.Comm.userControl.sendBaoMai.send(WebChat.Comm.userControl.sendBaoMai.data);
                    };

                    
                    //绑定用户上下文菜单按钮
                    WebChat.Doms.Other.contextmenu.find("a").click(function() {
                        var cur = $(this);
                        var cur_id = this.id;
                        if(cur.hasClass("disabled")|| (WebChat.Config.usercontrol!==1 && cur_id != "zslw" && cur_id != "fsxx" && cur_id != "xmic" && cur_id != "cxipdz" && cur_id != "addfriend")) {
                            return false;
                        }
                         
                        var uidx = WebChat.Doms.Other.contextmenu.attr("uidx");
                        var name = WebChat.Doms.Other.contextmenu.attr("uname");
                        //设置操作对象
                        WebChat.Comm.userControl.data.toidx = uidx;
                        switch(cur_id) {
                            case "zslw":
                                WebChat.Events.setGiftTo(uidx, name);
                                break;
                            case "fsxx":
                                WebChat.Events.setMsgTo(uidx, name);
                                break;
                            case "jy":
                                WebChat.Comm.userControl.sendForbidMsg.send(WebChat.Comm.userControl.data);
                                break;
                            case "hfjy":
                                WebChat.Comm.userControl.sendreset.send(WebChat.Comm.userControl.data);
                                break;
                            case "swgly":
                                WebChat.Comm.userControl.sendupManager.send(WebChat.Comm.userControl.data);
                                break;
                            case "jwpthy":
                                var identity = WebChat.Doms.Other.contextmenu.attr("identity");
                                if(identity == 9 && WebChat.Comm.userControl.sendViceRoomer) {
                                    WebChat.Comm.userControl.sendViceRoomer.data.toidx = uidx;
                                    WebChat.Comm.userControl.sendViceRoomer.data.opid = 0;
                                    WebChat.Comm.userControl.sendViceRoomer.send(WebChat.Comm.userControl.sendViceRoomer.data);
                                }
                                else
                                    WebChat.Comm.userControl.sendDownManager.send(WebChat.Comm.userControl.data);
                                break;
                            case "tcfj":
                                WebChat.Comm.userControl.data.time = WebChat.Config.outTime;
                                if(WebChat.Config.data.identity===2||WebChat.Config.data.identity===10) {
                                    WebChat.Message.setoutPlay(name);
                                }
                                else {
                                    WebChat.Comm.userControl.sendoutPlays.send(WebChat.Comm.userControl.data);
                                }
                                break;
                            case "swfsz":
                                if(WebChat.Comm.userControl.sendViceRoomer) {
                                    WebChat.Comm.userControl.sendViceRoomer.data.toidx = uidx;
                                    WebChat.Comm.userControl.sendViceRoomer.data.opid = 1;
                                    WebChat.Comm.userControl.sendViceRoomer.send(WebChat.Comm.userControl.sendViceRoomer.data);
                                }
                                break;
                            case "smic1":
                                sendBaoMai(uidx, 0);
                                break;
                            case "smic2":
                                sendBaoMai(uidx, 1);
                                break;
                            case "smic3":
                                sendBaoMai(uidx, 2);
                                break;
                            case "xmic":
                                WebChat.Comm.userControl.sendXiaMai.send(WebChat.Comm.userControl.data);
                                break;
                            case "cxipdz":
                                WebChat.Comm.userControl.getClientIP.send({ toidx: uidx, name: name });
                                break;
                            case "addfriend":
                                window.IM&&IM.addFriend(uidx);
                                break;
                            default:
                                break;
                        }
                        WebChat.Doms.Other.contextmenu.hide();
                        return false;
                    });

                    //用户上下文菜单hover事件
                    WebChat.Doms.Other.contextmenu.hover(function() {
                        var cur = $(this);
                        cur.show();
                        //WebChat.Doms.Right.user_list.find("ul[idx='"+cur.attr("uidx")+"']").removeClass("hover");
                    }, function(e) {
                        //WebChat.Doms.Right.user_list.find("ul[class='hover']").removeClass("hover");

                        //if(!WebChat.isInRegion(WebChat.Doms.Right.user_list.find("ul[idx='" + WebChat.Doms.Other.contextmenu.attr("uidx") + "']"), e.pageX, e.pageY))
                        WebChat.Doms.Other.contextmenu.hide();
                    });

                    //公聊控制滚动
                    WebChat.Doms.Right.public.hover(function(e) {
                        if($.data(WebChat.Doms.Other.pmgd_config, 'target') === 'public') {
                            WebChat.Doms.Other.pmgd_config.show();
                        }else{
                            WebChat.Doms.Other.pmgd_config.width(100);
                            WebChat.Doms.Other.pmgd_qqh && WebChat.Doms.Other.pmgd_qqh.hide();
                            show_gdpm_config(WebChat.Doms.Right.public);
                            WebChat.Doms.Other.pmgd_scroll.html('<img src="' + (WebChat.Config.public_autoscroll ? WebChat.Config.gpqpimg.gp : WebChat.Config.gpqpimg.gpx) + '" />');
                            $.data(WebChat.Doms.Other.pmgd_config, 'target', 'public');
                        }
                    }, function(e) {
                        //if(!WebChat.isInRegion($(this), e.pageX, e.pageY))
                        WebChat.Doms.Other.pmgd_config.hide();
                    });

                    //私聊控制滚动
                    WebChat.Doms.Right.private.hover(function(e) {
                        if($.data(WebChat.Doms.Other.pmgd_config, 'target') === 'private'){
                            WebChat.Doms.Other.pmgd_config.show();
                        }else{
                            var haspower = WebChat.Config.data.vipLevel > 1;
                            if(haspower) {
                                WebChat.Doms.Other.pmgd_config.width(165);
                            }
                            show_gdpm_config(WebChat.Doms.Right.private,haspower?-65:0);
                            WebChat.Doms.Other.pmgd_scroll.html('<img src="' + (WebChat.Config.private_autoscroll ? WebChat.Config.gpqpimg.gp : WebChat.Config.gpqpimg.gpx) + '" />');
                            $.data(WebChat.Doms.Other.pmgd_config, 'target', 'private');
	                        
                            if(haspower) {
                                var isqqh;
                                if (!WebChat.Doms.Other.pmgd_qqh) {
                                    WebChat.Doms.Other.pmgd_qqh = $('<a id="pmgd_qqh" isqqh="1"><img src="' + WebChat.Config.qqhimg.qqh + '" /></a>').appendTo(WebChat.Doms.Other.pmgd_config.append('&nbsp;'));
                                    //禁用启用悄悄话按钮
                                    WebChat.Doms.Other.pmgd_qqh.click(function() {
                                        isqqh = $(this).attr('isqqh') === '1' ? 0 : 1;
                                        with (WebChat.Comm.userControl.sendForbidPrivateMsg){
                                            data = { optype: isqqh };
                                            send(data);
                                        }
                                    });

                                } else {
                                    isqqh = WebChat.Comm.userControl.sendForbidPrivateMsg.data.optype === 0 ? 0 : 1;
                                    WebChat.Doms.Other.pmgd_qqh.show().attr('isqqh', isqqh).html('<img src="' + (isqqh ? WebChat.Config.qqhimg.qqh : WebChat.Config.qqhimg.qqhx) + '" />');
                                }
                            }

                        }
                    }, function(e) {
                        //if(!WebChat.isInRegion($(this), e.pageX, e.pageY))
                        WebChat.Doms.Other.pmgd_config.hide();
                    });

                    //清屏滚屏按钮显示位置设置
                    function show_gdpm_config(cur,fixleft) {
                        var cur_offset = cur.offset();
                        var curtop = cur.parents(".zbj_chatInfo").offset().top+18;
                        WebChat.Doms.Other.pmgd_config.css({ left: cur_offset.left + cur.width() - 100 + (fixleft || 0), top: curtop }).show();
                    }

                    //清屏滚屏按钮鼠标事件
                    WebChat.Doms.Other.pmgd_config.hover(function() {
                        WebChat.Doms.Other.pmgd_config.show();
                    }, function(e) {
                        //if(!(WebChat.isInRegion(WebChat.Doms.Right.public, e.pageX, e.pageY) || WebChat.isInRegion(WebChat.Doms.Right.private, e.pageX, e.pageY)))
                        WebChat.Doms.Other.pmgd_config.hide();
                    });

                    //清屏按钮
                    WebChat.Doms.Other.pmgd_clear.click(function () {

                        var target = $.data(WebChat.Doms.Other.pmgd_config, 'target');
                        if(target === 'public') {
                            WebChat.Message.chat.public.clear();
                        }
                        else if(target === 'private') {
                            WebChat.Message.chat.private.clear();
                        }
                    });

                    //滚屏按钮
                    WebChat.Doms.Other.pmgd_scroll.click(function() {
                        var target = $.data(WebChat.Doms.Other.pmgd_config, 'target');
                        if(target === 'public') {
                            WebChat.Config.public_autoscroll = !WebChat.Config.public_autoscroll;
                            WebChat.Doms.Other.pmgd_scroll.html('<img src="' + (WebChat.Config.public_autoscroll ? WebChat.Config.gpqpimg.gp : WebChat.Config.gpqpimg.gpx) + '" />');
                        }
                        else if(target === 'private') {
                            WebChat.Config.private_autoscroll = !WebChat.Config.private_autoscroll;
                            WebChat.Doms.Other.pmgd_scroll.html('<img src="' + (WebChat.Config.private_autoscroll ? WebChat.Config.gpqpimg.gp : WebChat.Config.gpqpimg.gpx) + '" />');
                        }
                    });

                    //显示送礼个数快捷选择界面
                    WebChat.Doms.Left.txt_gift_num.click(function() {
                        var cur = WebChat.Doms.Left.txt_gift_num;
                        var _number=WebChat.Doms.Other.number;
                        if($.data(cur, 'loaded') === undefined) {
                            var _html=[];
                            _html.push('<div class="taitou"><a href="#" hidefocus="true">数量</a><a href="#" class="on" hidefocus="true">图形</a></div><div style="display:none;" class="sbox_out">');
                            var show=[1,11,20,38,58,88,99,158,200];
                            for(var i=0,len=show.length;i<len;i++)
                            {
                                _html.push('<a'+(i%2==0?' class="alt"':'')+' num="'+show[i]+'" href="#">'+show[i]+'</a>');
                            }
                            _html.push('</div><div class="sbox_out pic">');
                            show = [
                                {index: 10, name: '笑脸', val: 10 },
                                {index: 50, name: 'V', val: 50 },
                                {index:1,name:'快乐音符',val:300},
                                {index:2,name:'LOVE',val:520},
                                {index:3,name:'公主皇冠',val:888},
                                {index:4,name:'萌动之心',val:999},
                                {index:5,name:'甜蜜相恋',val:1314},
                                {index:6,name: '相爱的心', val: 9999}
                            ];
                            for (var i = 0; i < show.length; i++)
                            {
                                _html.push('<a num="'+show[i].val+'" href="#"><div class="sbox sbox_pic'+show[i].index+'">'+show[i].name+'<br />('+show[i].val+')</div></a>'); 
                            }
                            _html.push('</div>');
                            _number.html(_html.join('')).find('.taitou a').each(function (i) {
                                var _this=$(this);
                                _this.click(function () {
                                    _this.addClass('on').siblings().removeClass('on');
                                    _number.find('.sbox_out:eq('+i+')').show().siblings('.sbox_out').hide();
                                    return false;
                                });
                            });
                            //绑定送礼个数快捷选择界面鼠标经过、点击事件
                            _number.hover(function() { $.data(_number, "mout", 0); }, function() { $.data(_number, "mout", 1); }).find("a[num]").click(function() {
                                WebChat.Doms.Left.txt_gift_num.val($(this).attr("num"));
                                WebChat.Doms.Other.number.hide();
                                return false;
                            });
                        }
                        var _offset = cur.offset(),top = 0;
                        if((WebChat.Config.data.identity===(pagedata.roomtype===jw.Config.roomtype.multimic?11:1) || WebChat.Config.data.mxid > -1) && $.browser.msie) {
                            top = _offset.top + 5 + WebChat.Doms.Left.txt_gift_num.height();
                        } else {
                            top = _offset.top - 2 - _number.height();
                        }
                        _number.css("top", top).css("left", _offset.left + 1).toggle();
                        
                        $.data(cur, 'loaded', 1);
                        bindDocClickshowOther(4, true);
                    }).keyup(function() {
                        var _number=WebChat.Doms.Other.number;
                        if(WebChat.Doms.Left.txt_gift_num.val().length == 0) {
                            _number.show();
                        } else {
                            _number.hide();
                        }
                    });
                    //绑定送礼个数按钮                    
                    WebChat.Doms.Left.txt_gift_num_btn.click(function () {
                        WebChat.Doms.Left.txt_gift_num.click();
                    });


                    //绑定送赠按钮
                    WebChat.Doms.Left.btnlargess.click(function() {
 
                        if(!WebChat.Doms.Left.selectgift) {
                            WebChat.Message.alert("请选择要赠送的礼物！");
                            return false;
                        }
                        var giftgs = WebChat.Doms.Left.txt_gift_num.val();

                        if((!WebChat.isNumber(giftgs)) || parseInt(giftgs, 10) == 0) {
                            WebChat.Message.alert("数量请输入大于0的整数！");
                            return false;
                        }
                        if(giftgs > WebChat.Config.giftnum_max) {
                            WebChat.Message.alert("礼物数量超出最大值！");
                            return false;
                        }
                        //设置赠送礼物信息
                        WebChat.Comm.sendGift.data.giftidx = WebChat.Doms.Left.selectgift.id;
                        WebChat.Comm.sendGift.data.giftnum = giftgs;
                        WebChat.Comm.sendGift.data.gifttype = WebChat.Doms.Left.selectgift.type;
                        //赠送礼物 
                        WebChat.Comm.sendGift.send(WebChat.Comm.sendGift.data);

                        return false;
                    });

                    //绑定对话框回车事件  
                    WebChat.Doms.Right.txtmsg.keypress(function(evt) {
                        if(evt.keyCode == 13) {
                            WebChat.stopDefault(evt);
                            WebChat.Doms.Right.btnsend.click();
                        }
                    });

                    //初始化礼物栏
                    this.initGiftList(0);
                    //绑定TAB标签切换事件
                    this.initTabs();
                },
                //绑定TAB标签切换事件
                initTabs: function() {
                    //初始化礼物TAB
                    WebChat.Doms.Left.gift_tabs.find("#gift_tab li").each(function(i) {
                        $(this).click(function() {
                            WebChat.Doms.Left.selectgift = null;
                            WebChat.Doms.Left.gift_tabs.find("#gift_tab li").removeClass();
                            $(this).addClass("gift_btn_on");
                            WebChat.Events.initGiftList(i);
                            WebChat.Doms.Left.gift_tabs.find(".items:eq(" + i + ")").show().siblings(":not(ul)").hide();
                            return false;
                        });
                    });

                    //初始化用户列表窗口TAB
                    WebChat.Doms.Right.user_tab_a.each(function(i) {
                        $(this).click(function() {
                            WebChat.Doms.Right.user_tab_a.removeClass();
                            var cur = $(this);
                            var index = cur.attr("index");
                            cur.addClass("talk_btn_on");
                            var selector = cur.attr("data-selector");//内容窗口的选择器
                            if (WebChat.Doms.Right.txtsearchuser)
                                WebChat.Doms.Right.txtsearchuser.val("搜索观众").attr("lastsearch", "").attr("index", index);
                            if (WebChat.Doms.Right.user_list_search)
                                WebChat.Doms.Right.user_list_search.hide();

                            if (index == 0) {
                                WebChat.Doms.Right.user_list_list.parents(selector).show();
                                WebChat.Doms.Right.user_list_admin.parents(selector).hide();
                                WebChat.Doms.Right.user_list_mic.hide();
                            }
                            else if(index == 1) {
                                WebChat.Doms.Right.user_list_list.parents(selector).hide();
                                WebChat.Doms.Right.user_list_mic.hide();

                                if(!WebChat.Doms.Right.user_list_admin.is(':visible'))
                                {
                                    WebChat.Comm.sendGetManager.send();
                                }
                                WebChat.Doms.Right.user_list_admin.parents(selector).show();
                            }
                            else if(index == 2) {
                                WebChat.Doms.Right.user_list_list.parents(selector).hide();
                                WebChat.Doms.Right.user_list_admin.parents(selector).hide();
                                WebChat.Doms.Right.user_list_mic.show();
                            }
                            return false;
                        });
                    });

                    //初始化聊天窗口TAB
                    WebChat.Doms.Right.talk_tab_a.each(function(i) {
                        var cur=$(this);
                        cur.click(function() {
                             
                            if(this.className === "outtabs") return;
                            WebChat.Doms.Right.talk_tab_a.removeClass("talk_btn_on");
                            this.className='talk_btn_on';
                            /*if($.browser.msie){
                                  DD_belatedPNG.fix('#talk_tab .mov_talk_tab li.talk_btn_on'); 
                            }*/
                            cur=WebChat.Doms.Right.talk_tabs.find("#talk_list_" + i);
                            cur.show().siblings(".mov_talk_box").hide();
                            if(i == 0) {
                                WebChat.Message.chat.public.scroll();
                                WebChat.Message.chat.private.scroll();
                            }
                            else if(i == 1) {
                                     
                                //礼物图片自适应大小
                                if (jw.Doms.Right.talk_gift_list) {
                                    WebChat.Doms.Right.talk_gift_list.find("img").each(function () {
                                        WebChat.imgAdaptive(this, 50, 50);
                                    });
                                }
                                if(window.talk_tab_aM){
                                    talk_tab_aM();
                                }else{
                                    WebChat.Events.giftList.get(WebChat.Config.data.roomidx);
                                }
                            }
                            else if(i == 2){
                                var _gUrl='/User/shop.aspx?i='+pagedata.roomidx;
                                try
                                {
                                    var from = window.urlQueryString?urlQueryString('from',true):'';
                                    if(from==='tuli')
                                    {
                                        window.location.href = _gUrl+ "&from=" +from;
                                    }
                                    else
                                    {
                                        var op = window.open('about:blank', '_blank');
                                        op.location = _gUrl;
                                    }
                                }
                                catch(e)
                                {
                                    window.open(_gUrl);
                                }
                            }
                            return false;
                        });
                    });
                },
                //根据礼物类型生成礼物列表
                initGiftList: function(type, giftview) {
                    var _load = function() {
                        if (giftview == null) {
                            giftview = WebChat.Doms.Left.gift_tabs.find("#gift_list_box_" + type);
                        }
                        var m_btn_style = 'display: block;';
                        var l_padding = '';
                        var l_box_w = 'width: 420px;';
                        var _gifthtml = '';
                        var _egifthtml = '';
                        var gift_show_list;
                        if (pagedata.roomtype == jw.Config.roomtype.threemic) {
                            m_btn_style = 'display: none;';
                            l_padding = 'padding-right:7px;';
                            l_box_w = 'width:435px;';
                        }
                        var gift_open = WebChat.Doms.Left.gift_tabs.hasClass('mov_gift_open');
                        /* 道具不需要额外造盒子 
                        if (gift_open) {
                            _gifthtml = '<div style="position: relative; display: block;_width:430px;" class="jcarousel-container jcarousel-container-horizontal"><div  class="jcarousel-clip-fix-on" style="width:430px;">';
                            _gifthtml += '<ul style="overflow: hidden; position: relative; top: 0px; margin: 0px; padding: 0px; left: 0px;' + l_box_w + ' " id="gift_list_' + type + '" class="first-and-second-carousel jcarousel-list jcarousel-list-horizontal '+(type==6?'stock_small':'')+'">';
                            _egifthtml = '</ul></div><div style="' + m_btn_style + '" id="gift_show_list_' + type + '" class="jcarousel-next-horizontal2"></div></div>';
                        } else {
                            _gifthtml = '<div style="position: relative; display: block;_width:430px;" class="jcarousel-container jcarousel-container-horizontal"><div  class="jcarousel-clip-fix">';
                            _gifthtml += '<ul style="overflow: hidden; position: relative; top: 0px; margin: 0px; padding: 0px; left: 0px;' + l_box_w + ' " id="gift_list_' + type + '" class="first-and-second-carousel jcarousel-list jcarousel-list-horizontal">';
                            _egifthtml = '</ul></div><div style="' + m_btn_style + '" id="gift_show_list_' + type + '" class="jcarousel-next-horizontal"></div></div>';
                        }
                       */
                        WebChat.Comm.sendGift.data.sendType = type === WebChat.Doms.Left.gift_tabs.find('#gift_tab li').length - 1 ? 1 : 0;

                        if (!giftview.children(':first').length) {
                            if (WebChat.Config.gift.data == null) return;
                            var liststr = '', img = '', id, g, max, ishot, iskc, msg, version, userlevel, owner;
                            for (var i = 0, len = WebChat.Config.gift.ids.length; i < len; i++) {
                                id = WebChat.Config.gift.ids[i];
                                g = WebChat.Config.gift.data[id];
                                if (g === undefined) continue;
                                max = g.maxmultiple;
                                ishot = g.ishot;
                                iskc = g.iskc;
                                msg = g.msg;
                                version = g.version;
                                userlevel = g.userlevel;
                                owner = g.owner;
                                if (userlevel) {
                                    userlevel = userlevel.split(':');
                                }
                                //特设礼物
                                if (owner && !~(',' + owner + ',').indexOf(',' + WebChat.Config.data.idx + ',')) {
                                    continue;
                                }
                                //朱海波 2015-04-15 库存修改需要修改下方的type === 6为对应的数字
                                if ((type === 1 && ishot == 1) || g.type == type || (type === 6 && iskc == 1)) {
                                    img = '<img src="' + WebChat.Config.gift.smallurl + id + '.png?d=20120412' + (version == null ? '' : '&v=' + version) + '" />';
                                    liststr += '<li class="giftItem" style=' + l_padding + '>';
                                    liststr += (userlevel && WebChat.Config.data.userLevel < parseInt(userlevel[0], 10) ? '<em class="lock_ico"></em>' : '') +
                                        '<a href="#" class="hvr-float-shadow" idx="' + id + '" n="' + g.n + '" title="' + g.name + '，价格：' + g.price + '星币' + (g.back == "0" ? "" : '，对方可得' + g.back + '星币') +
                                        (max ? '，最高可获得' + max + '倍奖金' : '') + (userlevel ? ',限' + userlevel[1] + '等级及以上用户使用' : '') + (msg ? '，' + msg : '') + '。" hidefocus="true">' + img + '</a><s></s>';
                                    if (g.active!=undefined && g.active == 0)
                                        liststr += '<em class="gift_star">周星</em>';//周星   朱海波  2015-05-12
                                    liststr += '</li>';
                                }
                            }
                            _gifthtml += liststr;

                            _gifthtml += _egifthtml;
                            giftview.html(_gifthtml).show().find("a").click(function() {
                                //绑定点击礼物事件
                                WebChat.Doms.Left.btnlargess.click();
                                return false;
                            }).mouseenter(function () {
                                var id = $(this).attr("idx");
                                WebChat.Doms.Left.selectgift = WebChat.Config.gift.data[id];
                                WebChat.Doms.Left.selectgift.id = id;
                                WebChat.Doms.Left.gift_tabs.find(".giftItem").removeClass("gift_on");
                                $(this).parent().addClass("gift_on");
                            });
                            
                            //初始化道具样式   朱海波  2015-04-22
                            /**/
                            giftview.find(".giftItem:gt(8)").hide();
                            giftview.find(".giftItem").each(function (i) {
                                var me = $(this);
                                //me.attr("class", "giftItem");
                                $(this).addClass("posit" + (parseInt(me.index()) % 9 + 1));
                            });
                            

                            /*上一页下一页信息,在room.js中已写
                            gift_show_list = giftview.find("#gift_show_list_" + type);
                            gift_show_list.click(function() {
                                var _curp = WebChat.Doms.Left.gift_tabs;
                                if (_curp.hasClass('mov_gift_open')) {
                                    _curp.removeClass('mov_gift_open');
                                    _curp.addClass('mov_gift');
                                    gift_show_list.removeClass('jcarousel-next-horizontal2').addClass('jcarousel-next-horizontal');
                                    gift_show_list.prev().removeClass('jcarousel-clip-fix-on').addClass('jcarousel-clip-fix');
                                    $(("#gift_show_list_" + type)).removeClass('jcarousel-next-horizontal2');
                                    $(("#gift_show_list_" + type)).addClass('jcarousel-next-horizontal');
                                    if(type==6&&$("#gift_list_"+type).hasClass('stock_small')){
                                        $("#gift_list_"+type).removeClass('stock_small');
                                    }
                                } else {
                                    _curp.removeClass('mov_gift');
                                    _curp.addClass('mov_gift_open');
                                    $(("#gift_show_list_" + type)).prev().removeClass('jcarousel-clip-fix');
                                    $(("#gift_show_list_" + type)).prev().addClass('jcarousel-clip-fix-on');
                                    gift_show_list.removeClass('jcarousel-next-horizontal').addClass('jcarousel-next-horizontal2');
                                    gift_show_list.prev().removeClass('jcarousel-clip-fix').addClass('jcarousel-clip-fix-on');
                                    if(type==6&&!$("#gift_list_"+type).hasClass('stock_small')){
                                        $("#gift_list_"+type).addClass('stock_small');
                                    }
                                }
                            });
                            */
                        } else {
                            giftview.show();
                            /*上一页下一页信息,在room.js中已写
                            gift_show_list = giftview.find("#gift_show_list_" + type);
                            if (pagedata.roomtype === jw.Config.roomtype.single) {
                                if (gift_open) {
                                    gift_show_list.removeClass('jcarousel-next-horizontal').addClass('jcarousel-next-horizontal2');
                                    gift_show_list.prev().removeClass('jcarousel-clip-fix').addClass('jcarousel-clip-fix-on');
                                    if(type==6&&!$("#gift_list_"+type).hasClass('stock_small')){
                                        $("#gift_list_"+type).addClass('stock_small');
                                    }
                                } else {
                                    gift_show_list.removeClass('jcarousel-next-horizontal2').addClass('jcarousel-next-horizontal');
                                    gift_show_list.prev().removeClass('jcarousel-clip-fix-on').addClass('jcarousel-clip-fix');
                                    if(type==6&&$("#gift_list_"+type).hasClass('stock_small')){
                                        $("#gift_list_"+type).removeClass('stock_small');
                                    }
                                }
                                if ((pagedata.roomtype === jw.Config.roomtype.single) && (!($("#gift_tabs").hasClass('mov_gift_open')))) {
                                    $(("#gift_show_list_" + type)).prev().removeClass('jcarousel-clip-fix-on');
                                    $(("#gift_show_list_" + type)).prev().addClass('jcarousel-clip-fix');
                                    $(("#gift_show_list_" + type)).removeClass('jcarousel-next-horizontal2');
                                    $(("#gift_show_list_" + type)).addClass('jcarousel-next-horizontal');
                                }
                            }
                            */
                        }
                        if (WebChat.Config.gift.load) {
                            WebChat.Config.gift.load(giftview);
                        }
                    };
                    if (WebChat.Config.gift.data) {
                        _load();
                    } else {
                        //获取礼物列表生成JSON
                        $.ajax({
                            cache: true,
                            url: WebChat.Config.gift.url,
                            jsonpCallback: '_getgiftjsonp',
                            dataType: 'jsonp',
                            success: function(json) {
                                WebChat.Config.gift.ids = json.ids;
                                WebChat.Config.gift.data = json.data;
                                _load();
                            }
                        });
                    }
                },
                //初始化表情
                initEmot: function(i, panel,c_type) {
                    if(panel.children(':first').length)
                        return;
                    var list = '<table>';
                    var _len = WebChat.Config.emot[i].list.length;
                    var _len2 = parseInt(_len / WebChat.Config.emotcolumns);
                    if(_len % WebChat.Config.emotcolumns != 0) {
                        _len2++;
                    }
                    for(var j = 0; j < _len2; j++) {
                        list += '<tr>';
                        var c = j * WebChat.Config.emotcolumns;
                        for(var k = c; k < c + WebChat.Config.emotcolumns; k++) {
                            if(!WebChat.Config.emot[i].list[k]) {
                                list += '<td style="cursor:default;">&nbsp;</td>';
                                continue;
                            }
                            list += '<td p="' + WebChat.Config.emot[i].val + '" index="' + WebChat.Config.emot[i].list[k].v + '" ><img height="24" width="24" title="' + WebChat.Config.emot[i].list[k].k + '" src="' + WebChat.getEmotUrl(WebChat.Config.emot[i].val, WebChat.Config.emot[i].list[k].v, 1, 1) + '" /></td>'
                        }
                        list += '</tr>';
                    }
                    list += '</table>';
                    panel.html(list).find("table").hover(function() { }, function() {
                        WebChat.Doms.Other.emotlist_face.hide();
                    }).find("td").hover(function(evt) {
                        WebChat.Doms.Other.emotlist_face.show();
                        var cur = $(this);
                        var offset = cur.offset();
                        var _p = cur.parent().parent();
                        var p_width = _p.width();
                        var p_offset = _p.offset();
                        var p = cur.attr("p");
                        var index = cur.attr("index");
                        var left = p_offset.left, top = p_offset.top, f_width = WebChat.Doms.Other.emotlist_face.width();
                        if(cur.html() != "&nbsp;") {
                            cur.addClass("hover");
                        }
                        if(!index) {
                            WebChat.Doms.Other.emotlist_face.hide();
                            return;
                        }
                        if(evt.pageX < p_offset.left + (p_width / 2)) {
                            left = p_offset.left + p_width - f_width - 12;
                        }
                        else {
                            left = p_offset.left;
                        }
                        WebChat.Doms.Other.emotlist_face.html('<table><tr><td style="vertical-align:middle;text-align:center;"><img style="vertical-align:middle;" src="' + WebChat.getEmotUrl(p, index, 1) + '" /></td></tr></table>').css({ left: left, top: top });
                    }, function() {
                        $(this).removeClass("hover");
                    }).click(function() {
                        var cur = $(this);
                        var index = cur.attr("index");
                        var p = cur.attr("p");
                        if(!index) {
                            return;
                        }
                        switch (c_type)
                        {
                            case 1:
                                WebChat.Doms.Right.txtmsg.insertAtCaret("[" + p + "/" + index + ']');
                                break;
                            case 2:
                                $("#radioId textarea").insertAtCaret("[" + p + "/" + index + ']');
                                break;
                            default:
                                WebChat.Doms.Right.txtmsg.insertAtCaret("[" + p + "/" + index + ']');
                                break;
                        }
                        WebChat.Doms.Other.emotlist.dialog("close");
                    });
                },
                //设置消息、操作对象
                setMsgTo: function(uidx, name) {
                    if(name==null||(uidx&&uidx == WebChat.Config.data.idx)) return;
                    //设置操作对象
                    WebChat.Comm.userControl.data.toidx = uidx;

                    //设置接收消息人IDX
                    WebChat.Comm.sendChat.data.toidx = uidx;

                    //显示对话人
                    WebChat.Doms.Right.txtmsgto_name.val(name);

                    if(WebChat.Doms.Other.wait_to_name.find(">a[idx='" + uidx + "']").length > 0) {
                        return;
                    }
                    var waitcount = WebChat.Doms.Other.wait_to_name.find(">a").length;
                    if(waitcount > 5) {
                        WebChat.Doms.Other.wait_to_name.find(">a:eq(1)").remove();
                    }

                    WebChat.Doms.Other.wait_to_name.append($('<a idx="' + uidx + '" >' + name + '</a>').click(function() {
                        var cur = $(this);
                        var curidx = cur.attr("idx");
                        WebChat.Doms.Right.txtmsgto_name.val($.trim(cur.text()));

                        //设置接收消息人IDX
                        WebChat.Comm.sendChat.data.toidx = curidx;
                        WebChat.Doms.Other.wait_to_name.hide();
                        WebChat.Doms.Right.txtmsg.setFocus();
                    }));
                },
                //设置礼物接收人、操作对象
                setGiftTo: function(uidx, name) {
                    if(name==null||uidx == WebChat.Config.data.idx) return;
                    //设置操作对象
                    WebChat.Comm.userControl.data.toidx = uidx;

                    //设置礼物接收人IDX
                    WebChat.Comm.sendGift.data.accpetidx = uidx;

                    //显示收礼人
                    WebChat.Doms.Left.txt_gift_to.val(name + '(' + uidx + ')');
                },
                //权限分配
                set_contextmenu: function(cur_idx,cno, name, cur, direction, ismic) {
                    if(cur_idx==-1) {
                        return;
                    }
                    var mxid = cur.attr('mxid');
                    if(window.set_contextmenuM) {
                        set_contextmenuM(ismic,mxid);
                    }
                    var identity = parseInt(cur.attr("identity"),10);
                    var vname = name;
                    if(identity===1 || identity===11 || identity===2 || identity===3 || identity===8 || identity===9 || identity===10) {
                        var _s = '{0}' + (name.length > 9 ? '<br/>' : '&nbsp;');
                        var _name={1:'主播', 2:'超管', 3:'管理', 8:'代理', 9:'副室', 10:'巡管'};
                        if(pagedata.roomtype===jw.Config.roomtype.multimic){
                            _name[1]='室主';
                            _name[3]='临管';
                            _name[11]='主播';
                        }
                        vname = _s.replace('{0}', _name[identity]) + name;
                    }
                    WebChat.Doms.Other.contextmenu_toname.html(vname + "<br/>" + (cur_idx > 0 ? "(" + cno + ")" : "") + "：");
                    var cm = WebChat.Doms.Other.contextmenu;
                    var offset = cur.offset();
                    var left = direction == null || direction == 'right' ? offset.left + cur.width()-20 : offset.left - cur.width();
                    cm.attr("uname", name).attr("uidx", cur_idx).attr("identity", identity).css({ left: left-70, top: offset.top }).show();

                    //当有上下文菜单权限时
                    if(WebChat.Config.usercontrol===1) {
                        var userLevel = parseInt(cur.attr("userLevel"),10);
                        var vipLevel = parseInt(cur.attr("vipLevel"),10);

                        //秀场之王、王后覆盖在紫P上
                        if(userLevel > 99) {
                            vipLevel = 2;
                        }
                        if(identity===7) {
                            cm.find("a[id!='tcfj']").addClass("disabled").end().find('#tcfj').removeClass("disabled");
                        }
                        else {
                            cm.find("a[id!='btnjgz']").removeClass("disabled");
                        }
                        var _disabledel = '';
                        //自己只能上下麦
                        if(WebChat.Config.data.idx == cur_idx) { 
                            identity = WebChat.Config.data.identity;
                            _disabledel = ',#zslw,#fsxx,#jy,#hfjy,#tcfj,#swfsz,#swgly,#jwpthy,#cxipdz,#addfriend';
                            //自己不是主播、超管、副室主、在麦上不能上麦
                            if((identity!==1 && identity!==11 && identity!==2 && identity!==9 && identity!==10) || mxid != -1) {
                                _disabledel += ',#smic1,#smic2,#smic3';
                            }
                        }
                            //超管
                        else if(WebChat.Config.data.identity===2) {
                            //对方是主播、超管、代理、巡管、秀场之王&王后、不能升降管理及副室主
                            if(identity===1|| identity===11 || identity===2 || identity===8 || identity===10 || userLevel > 99) {
                                _disabledel += ',#swgly,#jwpthy,#swfsz';
                                //对方是超管不能被禁言、踢出房间
                                if(identity===2) {
                                    _disabledel += ',#jy,#hfjy,#tcfj';
                                }
                            }
                                //对方是管理或秀场之王、王后不能再被升为管理
                            else if(identity===3) {
                                _disabledel += ',#swgly';
                            }
                                //对方是副室主不能再被升为副室主
                            else if(identity===9) {
                                _disabledel += ',#swgly,#swfsz';
                            }
                                //对方不是管理、副室主不需要降
                            else {
                                _disabledel += ',#jwpthy';
                            }
                            //已在麦序禁止上麦
                            if(mxid != '-1') {
                                _disabledel += ',#smic1,#smic2,#smic3';
                                if(identity===2) {
                                    _disabledel += ',#xmic';
                                }
                            }
                        }
                            //巡管
                        else if(WebChat.Config.data.identity===10) {
                            _disabledel += ',#swgly,#swfsz,#jwpthy,#swfsz,#jy,#hfjy,#cxipdz';
                            if(identity==2||identity==10) {
                                _disabledel += ',#tcfj';
                            }
                            //已在麦序禁止上麦
                            if(mxid != '-1' || identity===2) {
                                _disabledel += ',#smic1,#smic2,#smic3';
                            }
                            //不能下超管、巡管的麦
                            if(identity===2 || identity===10) {
                                _disabledel += ',#xmic';
                            }
                        }
                            //主播
                        else if(WebChat.Config.data.idx === WebChat.Config.data.roomidx||WebChat.Config.data.identity === 11) {
                            var ism = identity===2||identity===8||identity===10;
                            if(WebChat.Config.data.identity===11)
                                ism=ism||identity===1||identity===11;
                            //对方是超管、代理、巡管、秀场之王&王后不能被升降管理及副室主
                            if(ism || vipLevel > 79 || userLevel > 99) {
                                _disabledel += ',#swgly,#jwpthy,#swfsz';
                            }
                                //对方是管理不能再被升为管理
                            else if(identity===3) {
                                _disabledel += ',#swgly';
                            }
                                //对方是副室主不能再被升为副室主
                            else if(identity===9) {
                                _disabledel += ',#swgly,#swfsz';
                            }
                                //对方不是管理、副室主不需要降
                            else {
                                _disabledel += ',#jwpthy';
                            }

                            var anchorLevel=WebChat.Config.data.anchorLevel;
                            //如果主播等级低于14不能将紫P禁言，主播等级低于25不能将黑P禁言，财主、至尊、超管、代理、巡管、userLevel大于99不能被踢、禁言
                            if((anchorLevel < 15 && vipLevel===2) || (anchorLevel < 25 && vipLevel===3) || ism || userLevel > 99||vipLevel>=4) {
                                _disabledel += ',#tcfj,#jy,#hfjy';
                            }
                            if(WebChat.Config.data.identity===(pagedata.roomtype===jw.Config.roomtype.multimic?11:1)&&vipLevel>1&&!(ism || userLevel > 99)){
                                _disabledel += ',#tcfj';
                            }
                            //已在麦序禁止上麦
                            if(mxid != '-1' || ism) {
                                _disabledel += ',#smic1,#smic2,#smic3';
                                //不能下超管、巡管的麦
                                if(ism) {
                                    _disabledel += ',#xmic';
                                }
                            }
                            _disabledel += ',#cxipdz';
                            
                            //非主播小于V3的用户不能添加好友
                            if(WebChat.Config.data.userLevel<3&&(!isAnchor())){
                                _disabledel+=',#addfriend';
                            }
                        }
                            //副室主
                        else if(WebChat.Config.data.identity===9) {
                            var ism = identity===1|| identity===11 || identity===2 || identity===10;
                            //对方是黄P、紫P、黑P、财主、至尊、副室主、主播、代理、巡管不能被踢和禁言
                            if(identity===8 || identity===9 || ism || vipLevel > 1) {
                                if(WebChat.Config.data.vipLevel >= 3) {
                                    if (identity === 8 || identity === 9 || ism || vipLevel>=WebChat.Config.data.vipLevel) {
                                        _disabledel += ',#jy,#hfjy';
                                    }
                                } else {
                                    _disabledel += ',#jy,#hfjy';
                                }
                                //至尊加了副室主能踢、财主、黑P、紫P、黄P
                                if (identity === 8 || identity === 9 || ism || (WebChat.Config.data.vipLevel >= 3 && vipLevel>=WebChat.Config.data.vipLevel)) {
                                    _disabledel += ',#tcfj';
                                }
                                //非黄P、紫P、黑P、财主、至尊不能升降管理
                                if (vipLevel < 1 || ism || identity===9)
                                    _disabledel += ',#swgly,#jwpthy';
                            }
                            //对方是秀场之王&王后不能被升为管理员
                            if(userLevel > 99) {
                                _disabledel += ',#swgly,#jwpthy';
                            }
                                //对方是管理不能再被升为管理
                            else if(identity===3) {
                                _disabledel += ',#swgly';
                            }
                            else {
                                _disabledel += ',#jwpthy';
                            }
                            //已在麦序禁止上麦
                            if(mxid != '-1' || ism) {
                                _disabledel += ',#smic1,#smic2,#smic3';
                                //不能对主播、超管、巡管抱麦、下麦
                                if(ism)
                                    _disabledel += ',#xmic';
                            }

                            _disabledel += ',#swfsz,#cxipdz';
                            
                            //小于V3的用户不能添加好友
                            if(WebChat.Config.data.userLevel<3){
                                _disabledel+=',#addfriend';
                            }
                        }
                            //房间管理员、紫P、黑P、财主、至尊、 userLevel>99
                        else if(WebChat.Config.data.identity===3 || WebChat.Config.data.vipLevel>1 || WebChat.Config.data.userLevel > 99) {
                            var ism = identity===1|| identity===11 || identity===2 || identity===8 || identity===10;
                            var _ism= ism||identity===3 || identity===9;
                            //对方是黄P、紫P、黑P、财主、管理员、主播、代理、巡管不能被踢和禁言
                            if(vipLevel>0 || _ism) {
                                if (WebChat.Config.data.vipLevel === 2 || WebChat.Config.data.userLevel > 99) {
                                    //不能禁言除黄P外
                                    if (vipLevel != 1 || _ism)
                                        _disabledel += ',#jy,#hfjy';

                                    //秀场之王、王后能禁言紫P
                                    if (WebChat.Config.data.userLevel > 99 && vipLevel === 2 && userLevel < 100 && !_ism) {
                                        _disabledel = _disabledel.replace(',#jy,#hfjy', '');
                                    }
                                } else if (WebChat.Config.data.vipLevel === 5) {//至尊
                                    //除主播、超管、代理、巡官都能踢
                                    if(ism||vipLevel>=5) {
                                        _disabledel += ',#jy,#hfjy,#tcfj';
                                    }
                                } else if (WebChat.Config.data.vipLevel > 2) {
                                    //黑P、财主可以禁言,踢管理员、黄P、紫P、黑P
                                    if (ism || (WebChat.Config.data.vipLevel === 3 && WebChat.Config.data.userLevel <= userLevel && vipLevel === 3) || vipLevel >=4 || identity === 9) {
                                        _disabledel += ',#jy,#hfjy,#tcfj';
                                    }
                                } else {
                                    _disabledel += ',#jy,#hfjy';
                                }
                                if (WebChat.Config.data.vipLevel < 3)
                                    _disabledel += ',#tcfj';
                            }
                            _disabledel += ',#swgly,#jwpthy,#smic1,#smic2,#smic3,#xmic,#swfsz,#cxipdz';
                            
                            //小于V3的用户不能添加好友
                            if(WebChat.Config.data.userLevel<3){
                                _disabledel+=',#addfriend';
                            }
                        }
                            //黄P
                        else if(WebChat.Config.data.vipLevel===1) {
                            //对方是2级以上普通用户、非普通用户不能被禁言
                            if(userLevel > 2 || identity!==6 || vipLevel>0) {
                                _disabledel += ',#jy,#hfjy';
                            }
                            //不能踢人、上下麦、升降管理及副室主
                            _disabledel += ',#tcfj,#swgly,#jwpthy,#smic1,#smic2,#smic3,#xmic,#swfsz,#cxipdz';
                            
                            //小于V3的用户不能添加好友
                            if(WebChat.Config.data.userLevel<3){
                                _disabledel+=',#addfriend';
                            }
                        }
                        else {
                            _disabledel += ',#jy,#hfjy,#tcfj,#swgly,#jwpthy,#smic1,#smic2,#smic3,#xmic,#swfsz,#cxipdz';
                            //小于V3的用户不能添加好友
                            if(WebChat.Config.data.userLevel<3){
                                _disabledel+=',#addfriend';
                            }
                        }

                        _disabledel = _disabledel.substring(1, _disabledel.length);
                        cm.find(_disabledel).addClass("disabled");
                    }
                    else {
                        if(identity===7) {
                            cm.find("a").addClass("disabled");
                        }
                        else {
                            var _qx;
                            if(WebChat.Config.data.idx == cur_idx) {
                                _qx = '#xmic';
                            }
                            else {
                                _qx = '#zslw,#fsxx,#btnjgz';
                                //大于V3的用户、代理可以加好友
                                if(WebChat.Config.data.userLevel>3||WebChat.Config.data.identity===8)
                                    _qx+=',#addfriend';
                            }
                            var qx = cm.find(_qx).removeClass("disabled");
                            cm.find("a").not(qx).addClass("disabled");
                        }
                    }

                    //                    //炸弹、烟花、飞屏活动
                    //                    if(WebChat.Config.bombresult) {
                    //                        var _len = WebChat.Config.bombresult.length;
                    //                        if(!_len) return;
                    //                        var _c = cm.find('#bomb_line,#bomb_li');

                    //                        var _b = null;
                    //                        var _h = '', _n = '';
                    //                        var _count = 0;
                    //                        var _name = { 1: '小飞侠', 2: '福星', 3: '炸弹狂人', 4: '炸弹烈士' };
                    //                        for(var i = 0; i < _len; i++) {
                    //                            _b = WebChat.Config.bombresult[i];
                    //                            if(_b.sidx == cur_idx) {
                    //                                _n = _name[_b.type];
                    //                                if(_count===1 || _count===3) {
                    //                                    _h += '&nbsp;&nbsp;';
                    //                                }
                    //                                if(_count===2) {
                    //                                    _h += '<br/>';
                    //                                }
                    //                                _h += '<img src="' + WebChat.Config.users_faceurl + 'bomb_' + _b.type + '.gif" title="' + _n + '" alt="' + _n + '"/>';
                    //                                _count++;
                    //                            }
                    //                        }
                    //                        if(_c.length) {
                    //                            if(_h.length) {
                    //                                _c.each(function() {
                    //                                    if(this.id == 'bomb_li') {
                    //                                        this.innerHTML = _h;
                    //                                        return false;
                    //                                    }
                    //                                }).show();

                    //                            }
                    //                            else
                    //                                _c.hide();
                    //                        }
                    //                        else {
                    //                            if(_h.length) {
                    //                                _h = '<li id="bomb_li">' + _h + '</li><li id="bomb_line" class="userczspan">------------</li>';
                    //                            }
                    //                            cm.find('.userczspan:first').after(_h);
                    //                        }
                    //                    }
                },
                //聊天区域点击用户
                clickUser: function(obj) {
                    var cur = $(obj);
                    var name = cur.html();
                    var cur_idx = cur.attr("idx");
                    var cno = cur.attr("cno");

                    if(cur.attr("identity") == '8') {
                        WebChat.Events.userList.toggleDaili(true);
                    }

                    if(cur_idx == WebChat.Config.data.idx) {
                        WebChat.Events.userList.positioning(cur_idx);
                        WebChat.Doms.Other.contextmenu.hide();
                        return false;
                    }

                    WebChat.Events.setMsgTo(cur_idx, name);

                    this.set_contextmenu(cur_idx,cno, name, cur, 'left', false);
                    with(WebChat.Doms.Other){
                        wait_to_name.hide();
                        ctlist.hide();
                        emotlist.dialog("close");
                        emotlist_face.hide();
                        dialog_font.dialog("close");
                        dialog_autorespond.dialog('close');
                        number.hide();
                    }
                    WebChat.Doms.doc.one("click", function() {
                        WebChat.Doms.doc.one("click", function(e2) {
                            if ((!e2.target.className) || e2.target.className != 'user') {
                                WebChat.Doms.Other.contextmenu.hide();
                                //WebChat.Doms.doc.unbind("click");
                            }
                        });
                        //dohide(e);
                    });

                    WebChat.Events.userList.positioning(cur_idx);
                    return false;
                },
                //用户列表
                userList: {
                    getuser: function(player, classname, mxid) {
                        var pic = WebChat.getUserPic(player);
                        var name = player.userName.unescape();
                        var pcss = '', logo = '';
                        var anchorLevel=player.anchorLevel===undefined?WebChat.Config.data.anchorLevel:player.anchorLevel;
                        var iszb=(player.identity===(pagedata.roomtype===jw.Config.roomtype.multimic?11:1));
                        //                        if(iszb && anchorLevel > 29) {
                        //                            //pcss = ' z';
                        //                        }
                        if(player.from==1){
                            logo = '<img title="来自Android" src="' + WebChat.Config.users_faceurl + 'phone.png" />';
                            if(!pcss.length)
                                pcss = ' l';
                        }else if(player.from==2){
                            logo = '<img title="来自iPhone" src="' + WebChat.Config.users_faceurl + 'iPhone.png" />';
                            if(!pcss.length)
                                pcss = ' l';
                        }

                        if(player.isGreenCard){
                            logo += '<img src="' + WebChat.Config.users_faceurl + 'gcard.gif" />';
                            if(!pcss.length)
                                pcss = ' l';
                        }
                        if(player.family > 0) {
                            var _wb = 'http://webimg.9513.com/familyImg/j';
                            logo += '<img src="' + _wb + player.family + '.gif?d=' + (new Date()).getTime() + '" onerror="this.src=\'' + _wb + '0.gif\'" />';
                            if(!pcss.length || (iszb && anchorLevel < 30))
                                pcss += ' l';
                        }
                        if(player.idx > 8008000 && player.idx < 8008301) {
                            logo += '<img src="' + WebChat.Config.users_faceurl + 'lh.gif" />';
                            if(!pcss.length)
                                pcss = ' l';
                        }
                        
                        var _mxname = mxid != null ? mxid == 0 ? '主' : mxid == 1 ? '2' : mxid == 2 ? '3' : '' : '';
                        if(_mxname.length > 0) {
                            _mxname = '<span style="color:#ff0000">' + _mxname + '麦：</span>';
                        }

                        return '<ul class="' + classname + (player.vipLevel === 2 ? " vip2" : "") + (player.ishide ? " hide" : "") + '" idx="' + player.idx + '" cno="' + player.cno + '" identity="' + player.identity + '" userLevel="' + player.userLevel + '" vipLevel="' + player.vipLevel + '" uname="' + name + '"' + (mxid != null ? (' mxid="' + mxid + '"') : '') + '><li><p' + (player.idx == -1 ? ' style="color:#000;line-height:40px;"' : '') + ' class="userIco">' + pic + (player.idx > 0 ? '</p><p class="u' + pcss + '">' : '') + logo + _mxname + name + '<span class="urid1">(' + player.cno + ')</span></p></li></ul>';

                    },
                    //插入用户列表 userList.add
                    add: function(data,isadminlist) {
                         
                        /*if(data.player.ishide&&(data.player.idx!=pagedata.usersidx)){
                            return;
                        }*/
                        //用户进入提示
                        
                        if (data.isg==false) {
                            data.isadd = true;
                            this.showPlayerAddTip(data);  //拉到上面，游客也要提示
                        }
                        //紫P、黑P、超管隐身显示控制
                        if(data.player.ishide&&(data.player.idx!=pagedata.usersidx)){
                            //(WebChat.Config.data.identity==2&&data.player.identity==2)||
                            if(WebChat.Config.data.vipLevel!=100){
                                return;
                            }   
                        }   
                        if(data.index == null || data.index < 0 || WebChat.Doms.Right.user_list_list.find("ul[idx='" + data.player.idx + "']").length > 0||!data.player.idx) return;
                        var cur = WebChat.Doms.Right.user_list_list.find("ul[idx]:eq(" + data.index + ")");
                        var index = cur.length == 0 ? WebChat.Doms.Right.user_list_list.find("ul[idx][hide!='1']:last").index() + 1 : (data.index - WebChat.Doms.Right.user_list_list.find("ul[idx][hide='0']:lt(" + data.index + ")").length);
                        var normal = index % 2 == 0 ? "alt" : "";
                          
                        var _add = $(this.getuser(data.player, normal)).click(function() {
                            WebChat.Events.userList.userEvents("click", this);
                        }).mouseenter(function() {
                            WebChat.Events.userList.userEvents("mouseenter", this);
                        }).mouseleave(function(e) {
                            WebChat.Events.userList.userEvents("mouseleave", this, e);
                        });
                           


                        if(cur.length == 0) {
                            WebChat.Doms.Right.user_list_list.append(_add);
                        } else {
                            cur.before(_add);
                            if(data.player.identity!==8)
                                this.resetClass(_add);
                        }

                        if(data.player.identity == 8) {
                            //代理用户处理
                            this.toggleDaili(false);
                        }
                    },
                    //插入用户列表  userList.addList
                    addList: function(userlist, isadminlist, isnew) {
                        var userhtml = '';
                        var normal = '';
                        var admincount=0;
                        //,pic='',name='',pcss='',logo='';
                        for(var i = 0, len = userlist.length; i < len; i++) {
                            if(!userlist[i].idx)continue;
                            normal = (normal == "alt" ? "" : "alt");
                            //紫P、黑P、超管隐身显示控制
                            if(userlist[i].ishide&&(userlist[i].idx!=pagedata.usersidx)){
                                //(WebChat.Config.data.identity==2&&userlist[i].identity==2)||
                                if(WebChat.Config.data.vipLevel!=100){
                                    continue;
                                }   
                            } 
                            userhtml += this.getuser(userlist[i], normal);
                            admincount++; 
                            if(userlist[i].idx === WebChat.Config.data.idx) {
                                var _data = {};
                                _data.isadd = true;
                                _data.player = userlist[i];
                                this.showPlayerAddTip(_data);
                                
                                if(userlist[i].anchorLevel)
                                    WebChat.Config.data.anchorLevel=userlist[i].anchorLevel;
                            }
                        }
                        var _addlist = function(dom) {
                            dom.html(userhtml).children("[idx]").click(function() {
                                WebChat.Events.userList.userEvents("click", this);
                            }).mouseenter(function() {
                                WebChat.Events.userList.userEvents("mouseenter", this);
                            }).mouseleave(function(e) {
                                WebChat.Events.userList.userEvents("mouseleave", this, e);
                            });
                        };
                        if(isadminlist){
                            _addlist(WebChat.Doms.Right.user_list_admin);
                            window.showOnlineNumber&&showOnlineNumber(jw.Config.onlineviewer, admincount);
                        }
                        else {
                            _addlist(WebChat.Doms.Right.user_list_list);
                            //代理用户处理
                            this.toggleDaili();
                            //                            //显示全部用户
                            //                            if(isnew == false && WebChat.Comm.sendChat.data.toidx) {
                            //                                WebChat.Events.userList.positioning(WebChat.Comm.sendChat.data.toidx, true);
                            //                            }
                        }
                    },
                    //从用户列表中删除(包括搜索、管理列表)
                    remove: function(jq_dom, clearclass) {
                        jq_dom.each(function() {
                            var cur = $(this);
                            if(cur.is('[hide!="1"]')) {
                                if(cur.attr('identity') == '8') {
                                    WebChat.Events.userList.toggleDaili();
                                }
                                else if(clearclass == null || clearclass) {
                                    WebChat.Events.userList.resetClass(cur, true);
                                }
                            }
                            cur.remove();
                        });
                    },
                    //显示搜索结果
                    showSearchResult: function(userlist) {
                        WebChat.Doms.Right.user_list_search.empty();
                        var _list = '', normal = ''; //pic='',name=''
                        for(var i = 0, len = userlist.length; i < len; i++) {
                            if(!userlist[i].idx)continue;
                            if(userlist[i].ishide&&(userlist[i].idx!=pagedata.usersidx)){
                                if(WebChat.Config.data.vipLevel!=100){
                                    continue;
                                }   
                            } 
                            normal = (normal == 'alt' ? '' : 'alt');
                            _list += this.getuser(userlist[i], normal);
                        }
                        WebChat.Doms.Right.user_list_search.html(_list).children("[idx]").click(function() {
                            WebChat.Events.userList.userEvents("click", this);
                        }).mouseenter(function() {
                            WebChat.Events.userList.userEvents("mouseenter", this);
                        }).mouseleave(function(e) {
                            WebChat.Events.userList.userEvents("mouseleave", this, e);
                        });
                    },
                    //显隐身时重置Class
                    resetClass: function(cur, isdelete, isvisible) {
                     
                        if(cur.length == 0)
                            return;
                        var normal = "";
                        var alt = "";
                        var index = cur.index();

                        if(isdelete) {
                            normal = index % 2 == 0 ? "alt" : "";
                            alt = index % 2 == 0 ? "" : "alt"
                        }
                        else {
                            normal = index % 2 == 0 ? "" : "alt";
                            alt = index % 2 == 0 ? "alt" : ""
                        }
                        cur.nextAll('ul[idx]' + (isvisible == null || isvisible ? '[hide!="1"]' : '')).each(function(i) {
                            this.className = this.className.replace('alt', '');
                            if(i % 2 == 0) {
                                this.className += ' ' + normal;
                            }
                            else {
                                this.className += ' ' + alt;
                            }
                        });
                    },
                    //用户进入提示
                    showPlayerAddTip: function(json) {
                        //if(json.isg) return;  //不知道什么东西，影响游客进入房间提示

                        //判断是否有提示过
                        var tempkey = 'Idx_' + json.player.idx;
                        //console.log(YKIDX);
                        if (YKIDX[tempkey] != 1) {
                            //console.log(YKIDX, YKIDX[tempkey]);
                            if(json.isadd && !json.player.ishide) {   //&& json.player.identity!==7  注释掉，游客进入也要有提示  朱海波  2015-05-19
                                var cur = WebChat.Doms.Right.user_list_list.find("ul[idx='" + json.player.idx + "']");
                                if(cur.length > 0) {
                                    return;
                                }
                                /*
                                if(WebChat.Comm.adminControl.sendRoomSet.data.outslt === 0 && json.player.identity === 6 && json.player.userLevel === 0) {
                                    return;
                                }
                                if(json.opid!=undefined&&json.opid!=1021&&json.opid!=6901&&json.opid!=1003) {
                                    return;
                                }*/
                                if(!json.time) {
                                    json.time = WebChat.getTime();
                                }
                                var name = WebChat.getChatPic(json.player); //用户等级图标
                                var msg = '';
                                var _d = '进入房间！';
                                var _gyygnn = WebChat.Config.gyygnns && WebChat.Config.gyygnns[json.player.idx];
                                var _qztip = WebChat.Config.quzidx && WebChat.Config.quzidx[json.player.idx];
                                if(_gyygnn != null) {
                                    if(_gyygnn.flashid != null && _gyygnn.flashid.length > 0) {
                                        WebChat.Events.showGift.screenShow.show(_gyygnn.flashid, 1, 1, 0,'',_gyygnn.version);
                                    }
                                    msg = '<span style="color:#ff0000">' + _gyygnn.msg.replace('$u', name) + '</span>';
                                    WebChat.Message.chat.public.system('<img src="' + WebChat.Config.users_faceurl + _gyygnn.id + '.gif?d=20120327" /><br/>' + msg, json.time);
                                }
                                    //区长
                                else if(_qztip!=null)
                                {
                                    msg = '<span style="color:#ff0000">欢迎'+ name+_qztip.msg+_d+'</span>';
                                }
                                    //秀场之王
                                else if(json.player.userLevel === 101) {
                                    msg = '<span style="color:#ff0000">全体起立，热烈欢迎秀场之王' + name + '大驾光临！</span>';
                                }
                                    //秀场王后
                                else if(json.player.userLevel === 100) {
                                    msg = '<span style="color:#ff0000">全体起立，热烈欢迎秀场王后' + name + '大驾光临！</span>';
                                }
                                else if(json.player.identity === (pagedata.roomtype===jw.Config.roomtype.multimic?11:1) || json.player.identity === 2 || json.player.identity === 8) {
                                    msg = name + _d;
                                }else{
                                    if(json.player.userLevel > 9 && json.player.userLevel < 11) {
                                        msg = '欢迎' + name + _d;
                                    }
                                    else if(json.player.userLevel > 10 && json.player.userLevel < 17) {
                                        msg = '<span style="color:#e8641b">欢迎' + name + '莅临指导！</span>';
                                    }
                                    else if(json.player.userLevel > 16 && json.player.userLevel < 25) {
                                        msg = '<span>热烈欢迎' + name + '屈尊降临！</span>';
                                    }
                                    else if(json.player.userLevel > 24&& json.player.userLevel<27) {
                                        msg = '<span style="color:#ff0000">全体起立，恭候' + name + '大驾光临！</span>';
                                    }
                                    else if(json.player.userLevel === 27) {
                                        msg = '<span style="color:#ff0000">全体起立，恭候' + name + '创世之神降临凡间！</span>';
                                    }
                                    else if(json.player.userLevel === 28) {
                                        msg = '<span style="color:#ff0000">全体起立，恭候' + name + '宇宙霸主降临凡间！</span>';
                                    }
                                    else {
                                        if (WebChat.Comm.adminControl.sendRoomSet.data.outslt >=0)//房间消息打开,房间消息永久打开  朱海波
                                        {
                                            msg = WebChat.PackTime(json.time) + name + _d;
                                            WebChat.Message.chat.public.append(msg);
                                            YKIDX[tempkey] = 1;//记录提示已提示过
                                            return;
                                        } else if (json.player.vipLevel > 0) {
                                            msg = name + _d;
                                        }
                                    }
                                }
                                if(msg.length > 0) {
                                    WebChat.Message.chat.private.system(msg, json.time);
                                }
                            }
                        }
                    },
                    //用户退出提示
                    showPlayerExitTip: function(json) {
                        if(json.time==null||json.time.toString()=="0"){
                            return;
                        }
                        if(json.isadd && !json.exPlayer.ishide /*&& WebChat.Comm.adminControl.sendRoomSet.data.outslt == "1"*/ && json.exPlayer.identity!==7 && json.exPlayer.idx != WebChat.Config.data.idx) {
                            var tempkey = 'Idx_' + json.exPlayer.idx;
                            YKIDX[tempkey] = 0; 
                            WebChat.Message.chat.public.append(WebChat.PackTime(json.time) + WebChat.getChatPic(json.exPlayer) + '离开房间。');
                        }
                    },
                    //绑定显示更多按钮事件
                    getMoreList: function(obj) {
                     
                        var cur = $(obj);
                        if(WebChat.Config.data.insertuserlist_index){
                        
                            WebChat.Config.data.insertuserlist_index=WebChat.Config.data.insertuserlist_index+1;
                        }
                        else
                        {
                            WebChat.Config.data.insertuserlist_index=1;
                        }
                        /*var pageindex = parseInt(cur.attr("pageindex")) + 1;*/
                       
                        WebChat.Doms.Right.user_list_list.append('<ul id="user_loading"><li><img src="' + WebChat.Config.loadingimg + '" /></li></ul>');

                        //显示更多
                        WebChat.Comm.sendGetMorePlayer.data.pageindex =  WebChat.Config.data.insertuserlist_index;
                        WebChat.Comm.sendGetMorePlayer.send(WebChat.Comm.sendGetMorePlayer.data);
                        cur.remove();
                        return false;
                    },
                    //绑定用户列表区域鼠标经过、点击事件、用户上下文菜单
                    userEvents: function(name, obj, e, ismic) {
                        var cur = $(obj);
                        if(name == "click") {
                            if(cur.attr("identity") == 7)
                                return false;
                            WebChat.Events.setMsgTo(cur.attr("idx"), cur.attr("uname"));
                            return false;
                        }
                        else if(name == "mouseenter") {
                            cur.addClass("hover").siblings('.hover').removeClass("hover");
                            var cur_idx = cur.attr("idx");
                            if(!ismic) {
                                if(cur_idx == WebChat.Config.data.idx) {
                                    WebChat.Doms.Other.contextmenu.hide();
                                    return false;
                                }
                            }
                            var name = cur.attr("uname");
                            var cno = cur.attr("cno");
                            WebChat.Events.set_contextmenu(cur_idx,cno, name, cur, 'right', ismic);
                        }
                        else if(name == "mouseleave") {
                            //                            if(WebChat.isInRegion(cur, e.pageX, e.pageY)) {
                            //                                return false;
                            //                            }
                            cur.removeClass("hover");

                            //if(!WebChat.isInRegion(WebChat.Doms.Other.contextmenu, e.pageX, e.pageY))
                            WebChat.Doms.Other.contextmenu.hide();
                        }
                    },
                    //代理用户处理
                    toggleDaili: function(show) {
                        var daili_list = WebChat.Doms.Right.user_list_list.find('ul[idx][identity="8"]');
                        if(daili_list.length == 0)
                            return false;
                        var _html = '';
                        var cur = null;
                        var _do = function() {
                            WebChat.Events.userList.resetClass($(daili_list[0]).prev());
                            daili_list.removeClass('daili');
                            WebChat.Doms.Right.user_list_list.find('#btnmoredaili').remove();
                        };
                        var len = daili_list.length;
                        if(len < 4) {
                            daili_list.removeAttr('hide').show();
                            _do();
                            return false;
                        }
                        if(show == null) {
                            daili_list.each(function() {
                                show = $(this).attr('hide');
                                if(show)
                                    return false;
                            });
                        }
                        if(show) {
                            daili_list.removeAttr('hide').show().removeClass('hover');
                            _html = '收起';
                        }
                        else {
                            var m = [];
                            var s1 = null;
                            for(var i = 0; i < len; i++) {
                                var cur = $(daili_list[i]);
                                if(cur.attr('idx') == WebChat.Config.data.idx)
                                    s1 = i;
                                else
                                    m.push(i);
                            }
                            var getm = function() {
                                var _m = parseInt(Math.random() * m.length);
                                var _temp = m[_m];
                                m.splice(_m, 1);
                                return _temp;
                            };
                            if(s1 == null)
                                s1 = getm();
                            var s2 = getm();
                            var s3 = getm();
                            daili_list.each(function(i) {
                                var cur = $(this);
                                if(i != s1 && i != s2 && i != s3) {
                                    cur.hide().attr('hide', '1');
                                }
                                else
                                    cur.removeAttr('hide').show().removeClass('hover');
                            });
                        }
                        _do();
                        WebChat.Doms.Right.user_list_list.find('ul[idx][identity="8"][hide!="1"]:last').addClass('daili').find('a').append('<p id="btnmoredaili" class="u"><span onclick="WebChat.Events.userList.toggleDaili()" style="color:#ff0000;">' + (_html.length > 0 ? _html : '更多代理') + '</span></p>');
                        return false;
                    },
                    //定位到用户
                    positioning: function(idx, isall) {
                        WebChat.Doms.Right.user_tab.find('li[index="0"]').click();
                        var ull = WebChat.Doms.Right.user_list_list;
                        var cur = ull.find('ul[idx="' + idx + '"][hide!="1"]');
                        if(cur.length) {
                            ull.children('.hover[hide!="1"]').removeClass('hover');
                            var sh = ull[0].scrollHeight;
                            ull.scrollTop(sh * ((cur.offset().top + ull.scrollTop() - ull.offset().top) / sh));
                            cur.addClass('hover');
                        }
                        //                        else if(!isall)
                        //                        {
                        //                            WebChat.Comm.sendGetMorePlayer.data.pageindex = -1;
                        //                            WebChat.Comm.sendGetMorePlayer.send(WebChat.Comm.sendGetMorePlayer.data);
                        //                        }
                    }
                },
                //礼物列表
                giftList: {
                    //插入礼物列表
                    add: function (data) {
                        if (jw.Doms.Right.talk_gift_list) {
                            var gl = WebChat.Doms.Right.talk_gift_list;
                            if (window.pagedata.roomtype === jw.Config.roomtype.multimic) {
                                gl = gl.find('#gift_list_' + data.toidx);
                            }
                            var name = data.sendName.unescape();
                            var sender = data.idx + '_' + data.giftidx;
                            var history = gl.find('ul[sender="' + sender + '"]');
                            var sendNum = data.sendNum;
                            if (history.length > 0) {
                                sendNum += parseInt(history.find('.num').html());
                                history.remove();
                            }
                            var g = WebChat.Config.gift.data[data.giftidx];
                            var add = '<ul sender="' + sender + '"><li><table style="width:90%"><tr><td  width="50%"><a idx="' + data.idx + '" class="user" href="#"  onclick="return false;"  hidefocus="true">' + name + '</a></td><td width="30%" style="text-align:center;"><span class="gift"><img  src="' + WebChat.Config.gift.smallurl + data.giftidx + '.png?d=20120412' + (g.version == null ? '' : '&v=' + g.version) + '" /></span></td><td width="20%" style="text-align:right;"><span class="num">' + sendNum + '</span></td></tr></table></li></ul>';
                            var first = gl.children("ul:first");
                            if (first.length) {
                                first.before(add);
                            }
                            else {
                                gl.append(add);
                            }
                        }
                    },
                    //插入待刷礼物列表
                    addGiveList: function (gift) {
                        var notin = true;
                        for(var i = 0, len = WebChat.Events.brushGift.give_list.length; i < len; i++) {
                            if(WebChat.Events.brushGift.give_list[i].sendidx == gift.sendidx && WebChat.Events.brushGift.give_list[i].sendGiftidx == gift.sendGiftidx && WebChat.Events.brushGift.give_list[i].acceptIdx == gift.acceptIdx) {
                                WebChat.Events.brushGift.give_list[i].giftNumE = gift.giftNumE;
                                notin = false;
                            }
                        }
                        if(notin) {
                            WebChat.Events.brushGift.give_list.push(gift);
                        }
                    },
                    //获取礼物列表
                    get: function (idx) { //giftList.get
                        if (jw.Doms.Right.talk_gift_list) {
                            var gl = WebChat.Doms.Right.talk_gift_list;
                            $.data(gl, 'get' + idx, 1);
                            if (window.pagedata.roomtype === jw.Config.roomtype.multimic) {
                                gl.find('#btnnames' + idx).addClass('on').siblings().removeClass('on');
                                gl = gl.find('#gift_list_' + idx).show();
                                gl.siblings('div').hide();
                            }
                            if (gl.find('ul[sender]:first').length) {
                                return false;
                            }
                            WebChat.Comm.sendGetGiftList.send(idx);
                        }
                        return false;
                    }
                },
                //刷礼物
                brushGift: {
                    //刷礼物Interval标识
                    intervalid: null,
                    //停止标识
                    stopgiveid: null,
                    //当前刷的礼物index
                    give_index: 0,
                    //待刷礼物列表
                    give_list: new Array(),
                    //启动刷礼物
                    start: function() {
                        if(this.intervalid)
                            return;
                        //                        this.intervalid = setInterval(function() {
                        //                            for(var i = 0; i < WebChat.Config.giveNumber; i++) {
                        //                                if(WebChat.Events.brushGift.give_list.length == 0) {
                        //                                    WebChat.Events.brushGift.give_index = 0;
                        //                                    clearInterval(WebChat.Events.brushGift.intervalid);
                        //                                    WebChat.Events.brushGift.intervalid = null;
                        //                                    break;
                        //                                }
                        //                                if(WebChat.Events.brushGift.give_index >= WebChat.Events.brushGift.give_list.length) {
                        //                                    WebChat.Events.brushGift.give_index = 0;
                        //                                }
                        //                                var json = WebChat.Events.brushGift.give_list[WebChat.Events.brushGift.give_index];

                        //                                var gift = WebChat.Config.gift.data[json.sendGiftidx];
                        //                                var giftname = gift.n + gift.name;

                        //                                var msg = json.time + json.picsendname + '送给' + json.picacceptname + '第' + json.giftNumS + giftname + '<img src="' + WebChat.Config.gift.bigurl + json.sendGiftidx + '.gif?d=20120412' + (gift.version == null ? '' : '&v=' + gift.version) + '" />&nbsp;';
                        //                                WebChat.Message.chat.public.append(msg);

                        //                                if(json.giftNumS >= json.giftNumE) {
                        //                                    WebChat.Events.brushGift.give_list.splice(WebChat.Events.brushGift.give_index, 1);
                        //                                }
                        //                                else {
                        //                                    json.giftNumS++;
                        //                                    WebChat.Events.brushGift.give_index++;
                        //                                }
                        //                            }
                        //                        }, WebChat.Config.giveInterval);
                        var _dostart = function () {
                            lwRef = true;
                            for (var i = 0; i < WebChat.Config.giveNumber; i++) {
                                if(WebChat.Events.brushGift.give_list.length == 0) {
                                    WebChat.Events.brushGift.give_index = 0;
                                    clearInterval(WebChat.Events.brushGift.intervalid);
                                    WebChat.Events.brushGift.intervalid = null;
                                    break;
                                }
                                if(WebChat.Events.brushGift.give_index >= WebChat.Events.brushGift.give_list.length) {
                                    WebChat.Events.brushGift.give_index = 0;
                                }
                                var json = WebChat.Events.brushGift.give_list[WebChat.Events.brushGift.give_index];

                                var gift = WebChat.Config.gift.data[json.sendGiftidx];
                                var giftname = gift.n + gift.name;

                                if (json.giftNumE - json.giftNumS > 20)
                                {
                                    json.giftNumS = json.giftNumE - 20;//礼物窗口最多20条礼物发送信息
                                }

                                var msg = '<div class="times fl">' + WebChat.PackTime(json.time) + "</div>";
                                msg += '<div class="text fl">' + json.picsendname + '&nbsp;送给&nbsp;' + json.picacceptname + '第' + json.giftNumS + giftname;
                                //msg += '<img src="' + WebChat.Config.gift.bigurl + json.sendGiftidx + '.gif?d=20120412' + (gift.version == null ? '' : '&v=' + gift.version) + '" />&nbsp;';
                                msg += '&nbsp;</div>';
                                //WebChat.Message.chat.public.append(msg); //送礼物的提示
                                
                                WebChat.Message.chat.Addlb.append(msg);

                                //执行道具抛物线
                                paoLine(WebChat.Config.gift.smallurl + json.sendGiftidx + '.png?d=20120412' + (gift.version == null ? '' : '&v=' + gift.version));

                                if(json.giftNumS >= json.giftNumE) {
                                    WebChat.Events.brushGift.give_list.splice(WebChat.Events.brushGift.give_index, 1);
                                }
                                else {
                                    json.giftNumS++;
                                    WebChat.Events.brushGift.give_index++;
                                }
                               
                            }
                            lwRef = false;
                            WebChat.Events.brushGift.intervalid = setTimeout(function(){_dostart();},WebChat.Config.giveInterval);
                        };
                        _dostart();
                    },
                    //停止刷礼物 force：是否强制停止刷礼物
                    stop: function(force) {
                        if(!this.intervalid)
                            return;
                        if(this.stopgiveid) {
                            clearTimeout(this.stopgiveid);
                            this.stopgiveid = null;
                        }
                        this.stopgiveid = setTimeout(function() {
                            if(!force) {
                                if(WebChat.Events.brushGift.give_list.length > 0)
                                    return;
                            }
                            clearInterval(WebChat.Events.brushGift.intervalid);
                            WebChat.Events.brushGift.intervalid = null;
                        }, WebChat.Config.giveTimeout);
                    }
                },
                //                //刷跑道
                //                brushPaoDao:{
                //                    //刷跑道Interval标识
                //                    intervalid:null,
                //                    //待刷跑道列表
                //                    list:new Array(),
                //                    //启动刷跑道
                //                    start: function () {
                //                            if(WebChat.Events.brushPaoDao.intervalid!=null)
                //                                return;    
                //                            var _div=WebChat.Doms.doc.find('#paodao_div');
                //                            WebChat.Events.brushPaoDao.intervalid=setInterval(function (){
                //                                if(WebChat.Events.brushPaoDao.list.length==0)
                //                                {
                //                                    clearInterval(WebChat.Events.brushPaoDao.intervalid);
                //                                    WebChat.Events.brushPaoDao.intervalid=null;
                //                                    return;
                //                                }
                //                                var complete=_div.marquee("complete");
                //                                var iscreated=_div.marquee("iscreated");
                //                                if(iscreated==false||complete>0)
                //                                {
                //                                   _div.find("#paodao").html(WebChat.Events.brushPaoDao.list[0]);//paodao是ul
                //                                   _div.marquee({direction:'left',scrollAmount:1,scrollDelay:20});
                //                                   WebChat.Events.brushPaoDao.list.splice(0,1);
                //                                }
                //                        },1000);
                //                    }
                //                },
                //刷喇叭
                brushLaBa: {
                    //刷喇叭Interval标识
                    intervalid: null,
                    //停止标识
                    stoplabaid: null,
                    //待刷喇叭列表
                    list: new Array(),
                    //启动刷喇叭
                    start: function() {
                        if(this.intervalid)
                            return;
                        var _div = WebChat.Doms.doc.find('#xiaolaba_div');
                        this.intervalid = setInterval(function() {
                            if(WebChat.Events.brushLaBa.list.length == 0) {
                                clearInterval(WebChat.Events.brushLaBa.intervalid);
                                WebChat.Events.brushLaBa.intervalid = null;
                            }
                            var complete = _div.marquee("complete");
                            var iscreated = _div.marquee("iscreated");
                            if(iscreated == false || complete > 0) {
                                WebChat.Message.affiche.append(WebChat.Events.brushLaBa.list[0]);
                                _div.marquee({ direction: 'left', loop: 1, scrollDelay: 20 });

                                WebChat.Events.brushLaBa.list.splice(0, 1);
                            }

                        }, 200);
                    }
                },
                //礼物展示
                showGift: {
                    //全屏展示
                    screenShow: {
                        //    礼物动画  showGift.screenShow.show
                        show: function(giftid, num, type, price, sendname, version) {
                            if(!WebChat.Config.gift.showgift) {
                                return;
                            }
                            var ext = type ? 'swf' : 'png';
                            this.autosize(type ? 564 : 470);
                            var swfurl = WebChat.Config.gift.swfurl + giftid + "." + ext + "?d=20120606" + (version != null ? '&v=' + version : '');
                            try {
                                WebChat.Doms.showGiftComm.swfshow(swfurl, num, type, price);

                                if(giftid == 701)//烟花提示
                                {
                                    WebChat.Doms.showGiftComm.showFireText('烟花绽放，' + sendname + '撒下星币，造福房间！', 11000);
                                }
                            } catch(e) { 
                                setTimeout(function(){
                                    WebChat.Events.showGift.screenShow.show(giftid, num, type, price, sendname, version);
                                },50);
                            }
                        },
                        //展示幸运礼物中奖
                        showLuckInfo: function(player, giftName, multi, money, time, num) {
                            if(!WebChat.Config.gift.showgift) {
                                return;
                            }
                            this.autosize();
                            try {
                                WebChat.Doms.showGiftComm.showLuckInfo(player.idx, player.userName.unescape(), player.userLevel, player.vipLevel, giftName, multi, money, time, num);
                            } catch(e) { }
                        },
                        //展示气球宝藏信息
                        showQQInfo: function(player, giftName, time, num) {
                            if(!WebChat.Config.gift.showgift) {
                                return;
                            }
                            this.autosize();
                            try {
                                WebChat.Doms.showGiftComm.showQQInfo(player.idx, player.userName.unescape(), player.userLevel, player.vipLevel, giftName, time, num);
                            } catch(e) { }
                        },
                        //展示飞屏信息，飞屏发送成功展示飞屏信息
                        showFlyText: function(json) {
                            this.autosize();
                            try {
                                if (WebChat.Config.data.feipingNum>0)
                                    WebChat.Config.data.feipingNum = WebChat.Config.data.feipingNum - 1;
                                WebChat.Doms.showGiftComm.flyText(json);
                            } catch(e) { }
                        },
                        //显示广告
                        showAdv: function() {
                            //                            var adhide = getCookie('adhide');
                            //                            if(adhide > 2) return;
                            //                           this.autosize(390, true, (pagedata.fromsource===2 ? 30 : 0));
                            //                           try {
                            //                                WebChat.Doms.showGiftComm.showAdv();
                            //                            } catch(e) { }
                        },
                        //隐藏礼物展示
                        hide: function() {
                            try {
                                WebChat.Doms.showGiftComm.clear();
                                var cur = $(WebChat.Doms.showGiftComm).width(1).height(1);
                                WebChat.Doms.showgift.width(1).height(1).find("#GShow2").width(1).height(1);
                            } catch(e) { }
                        },
                        //自动设置GShow宽度
                        autosize: function(_h, pointerauto, addtop) {
                            var win = WebChat.Doms.all;
                            var win_position = win.position();
                            var _w = $(window).width();
                            var _l = 0;
                            var _p;
                            if(WebChat.Config.data.identity===(pagedata.roomtype===jw.Config.roomtype.multimic?11:1) || WebChat.Config.data.mxid > -1) {
                                _w = _w - WebChat.Doms.Left.left.width() - (_w - WebChat.Doms.all.width()) / 2;
                                _p = WebChat.Doms.Right.talk_tabs.position();
                                _l = _p.left;
                            }
                            else {
                                //_p = WebChat.Doms.all.offset();
                                _l = 0;//-_p.left;
                            }
                            if(_h == null) {
                                _h = 470; //win.height()-670;
                            }
                            var cur = $(WebChat.Doms.showGiftComm);
                            cur.width(_w).height(_h).find("#GShow2").width(_w).height(_h);
                            WebChat.Doms.showgift.css({ width: _w, height: _h, left: _l, top: (win_position.top + (addtop ? addtop : 0)), pointerEvents: pointerauto ? 'auto' : 'none' });
                        }
                    },
                    //右侧礼物展示
                    rightShow: {
                        //大额展示
                        largeShow: {
                            timeoutid: null,
                            show: function(msg) {
                                if(!WebChat.Config.gift.showgift || msg == null) {
                                    return;
                                }
                                if(WebChat.Events.showGift.rightShow.largeShow.timeoutid != null) {
                                    clearTimeout(WebChat.Events.showGift.rightShow.largeShow.timeoutid);
                                    WebChat.Events.showGift.rightShow.largeShow.timeoutid == null
                                }
                                var _offset = WebChat.Doms.paodao.offset();
                                msg = '<img src="' + WebChat.Config.showGift.largeimg + '" /><span >' + msg + '</span>';
                                WebChat.Doms.Other.dialog_giftH.css("left", _offset.left + 470).css("top", _offset.top).html(msg).show();
                                WebChat.Events.showGift.rightShow.largeShow.timeoutid = setTimeout(WebChat.Events.showGift.rightShow.largeShow.hide, 10000);
                            },
                            hide: function() {
                                if(WebChat.Events.showGift.rightShow.largeShow.timeoutid != null) {
                                    clearTimeout(WebChat.Events.showGift.rightShow.largeShow.timeoutid);
                                    WebChat.Events.showGift.rightShow.largeShow.timeoutid == null
                                }
                                WebChat.Doms.Other.dialog_giftH.empty().hide();
                            }
                        },
                        //普通展示
                        normalShow: {
                            intervalid: null,
                            show: function(msg) {
                                if(!WebChat.Config.gift.showgift || msg == null) {
                                    return;
                                }
                                if(WebChat.Events.showGift.rightShow.normalShow.intervalid !== null) {
                                    clearInterval(WebChat.Events.showGift.rightShow.normalShow.intervalid);
                                    WebChat.Events.showGift.rightShow.normalShow.intervalid = null;
                                }
                                var _offset = WebChat.Doms.Right.user_tab.offset();
                                msg = '<ul><li><img src="' + WebChat.Config.showGift.normalimg + '" /><br/>' + msg + '</li></ul>';
                                if(WebChat.Doms.Other.dialog_giftPT.children().length > 30) {
                                    return;
                                }
                                WebChat.Doms.Other.dialog_giftPT.css("left", _offset.left + 50).css("top", _offset.top).append(msg).end().show();
                                WebChat.Events.showGift.rightShow.normalShow.intervalid = setInterval(function() {
                                    WebChat.Events.showGift.rightShow.normalShow.hide(0);
                                }, 3000);
                            },
                            hide: function(i) {
                                var dom = WebChat.Doms.Other.dialog_giftPT.find("ul:first");
                                if(i == null) {
                                    dom.empty();
                                } else {
                                    var find = dom.find("ul:eq(" + i + ")");
                                    if(find.length === 1) {
                                        find.remove();
                                    }
                                }
                                if(WebChat.Events.showGift.rightShow.normalShow.intervalid !== null && dom.children(':first').length === 0) {
                                    clearInterval(WebChat.Events.showGift.rightShow.normalShow.intervalid);
                                    WebChat.Events.showGift.rightShow.normalShow.intervalid = null;
                                    WebChat.Doms.Other.dialog_giftPT.hide();
                                }
                            }
                        }
                    }
                }
            },
            //全局DOM
            Doms: {
                //                //documentDOM
                //                doc: undefined,
                //                //聊天室模块顶级DOM
                //                all: undefined,
                //                //视频组件DOM
                //                videoComm:undefined,
                //                //通信组件DOM
                //                chatComm: undefined,
                //                //展示礼物组件DOM
                //                showGiftComm:undefined,
                //                showgift:undefined,
                //                //跑道DIV DOM
                //                paodao:undefined,
                //左边
                Left: {
                    //                    left: undefined,
                    //                    //公告信息、小喇叭信息显示DOM
                    //                    affiche: undefined,
                    //                    //礼物列表顶级DOM
                    //                    gift_tabs: undefined,
                    //                    //送礼顶级DOM
                    //                    gift_to: undefined,
                    //                    //收礼人姓名输入框DOM
                    //                    txt_gift_to: undefined,
                    //                    //送礼个数输入框DOM
                    //                    txt_gift_num: undefined,
                    //                    //赠送按钮DOM
                    //                    btnlargess: undefined,
                    //                    //余额DOM
                    //                    money: undefined,
                    //                    //选中礼物DOM
                    //                    selectgift: undefined
                },
                //右边
                Right: {
                    //                    right: undefined,
                    //                    //聊天区域顶级DOM
                    //                    talk_tabs: undefined,
                    //                    //对话标签所以a的DOM集合
                    //                    talk_tab_a: undefined,
                    //                    //公聊信息显示元素DOM
                    //                    public: undefined,
                    //                    //分隔线DOM
                    //                    talk_split: undefined,
                    //                    //私聊信息显示元素DOM
                    //                    private: undefined,
                    //                    //发送消息区域顶级DOM
                    //                    talk_msg: undefined,
                    //                    //发送表情按钮DOM
                    //                    sendemot: undefined,
                    //                    //设置按钮DOM
                    //                    chatoptions: undefined,
                    //                    //发送彩条按钮DOM
                    //                    sendct: undefined,
                    //                    //发送小喇叭按钮DOM
                    //                    sendxlb: undefined,
                    //                    //消息接收人输入框DOM
                    //                    txtmsgto_name: undefined,
                    //                    //发言文本框DOM
                    //                    txtmsg: undefined,
                    //                    //是否是悄悄话DOM
                    //                    chkqqh: undefined,
                    //                    //发送消息按钮DOM
                    //                    btnsend: undefined,
                    //                    //礼物历史窗口DOM
                    //                    talk_gift_list: undefined,
                    //                    //日志窗口DOM
                    //                    talk_blogs: undefined,
                    //                    //用户列表顶级DOM
                    //                    rightlist: undefined,
                    //                    //用户列表TAB顶级DOM
                    //                    user_tab: undefined,
                    //                    //用户列表TAB元素a的DOM集合
                    //                    user_tab_a: undefined,
                    //                    //房间管理员人数显示DOM
                    //                    user_tab_admin: undefined,
                    //                    //房间管理员人数显示DOM
                    //                    user_tab_viewer: undefined,
                    //                    //用户列表顶级DOM
                    //                    user_list: undefined,
                    //                    //搜索输入文本框DOM
                    //                    txtsearchuser: undefined,
                    //                    //用户列表DOM
                    //                    user_list_list: undefined,
                    //                    //管理员列表DOM
                    //                    user_list_admin: undefined,
                    //                    //搜索结果列表DOM
                    //                    user_list_search: undefined,
                    //                    //点歌列表
                    //                    reqlist:undefined,
                    //                    //点歌列表分页控件DOM
                    //                    pagin_reqlist:undefined,
                    //                    //点歌按钮所在DIV的DOM
                    //                    songbutton:undefined
                },
                //其他窗口顶级
                Other: {
                    //                    //其他窗口顶级DOM
                    //                    other: undefined,
                    //                    //alert DOM
                    //                    alert: undefined,
                    //                    //confirm DOM
                    //                    confirm: undefined,
                    //                    //注册窗口 DOM
                    //                    reg:undefined,
                    //                    //登录窗口 DOM
                    //                    login: undefined,
                    //                    //接收消息缓存列表DOM
                    //                    wait_to_name: undefined,
                    //                    //表情列表DOM
                    //                    emotlist: undefined,
                    //                    //表情动态展示DOM
                    //                    emotlist_face:undefined,
                    //                    //彩条列表DOM
                    //                    ctlist: undefined,
                    //                    //屏幕滚动设置列表DOM
                    //                    pmgd_config:undefined,
                    //                    //清屏按钮DOM
                    //                    pmgd_clear:undefined,
                    //                    //滚动按钮DOM
                    //                    pmgd_scroll:undefined,
                    //                    //用户上下文菜单
                    //                    contextmenu: undefined,
                    //                    //用户上下文菜单显示姓名元素DOM
                    //                    contextmenu_toname:undefined,
                    //                    //送礼个数快捷选择DOM
                    //                    number: undefined,
                    //                    //查看房间密码按钮DOM
                    //                    btnviewpwd:undefined,
                    //                    //停止直播按钮DOM
                    //                    btnstoplive:undefined,
                    //                    //设置模板按钮DOM
                    //                    btntemplate:undefined,
                    //                    //设置海报窗口DOM
                    //                    dialog_haibao:undefined,
                    //                    //设置背景图片窗口DOM
                    //                    dialog_bgpic:undefined,
                    //                    //字体设置DOM
                    //                    dialog_font:undefined,
                    //                    //自动回复设置
                    //                    dialog_autorespond:undefined,
                    //                    //大额礼物展示DOM
                    //                    dialog_giftH:undefined,
                    //                    //普通礼物展示DOM
                    //                    dialog_giftPT:undefined,
                    //                    //点歌本
                    //                    dialog_diangeben:undefined,
                    //                    //点歌本列表
                    //                    dialog_songlist:undefined,
                    //                    //点歌本分页控件DOM
                    //                    pagin_songlist:undefined
                },
                //初始化
                init: function() {
                    //console.time("doms");
                    WebChat.Doms.all = $("body");
                    WebChat.Doms.videoComm = swfobject.getObjectById("asVideo");
                    WebChat.Doms.chatComm = swfobject.getObjectById("weblive_chat");
                    WebChat.Doms.showGiftComm = swfobject.getObjectById("GShow");//flash消息
                    WebChat.Doms.showgift = $("#showgift");
                    WebChat.Doms.hornComm = swfobject.getObjectById("horn");

                    WebChat.Doms.doc = $(document);
                    WebChat.Doms.body = WebChat.Doms.doc.find('body');

                    WebChat.Doms.Left.money = $("#lblmoney");//用户余额
                    WebChat.Doms.Left.money2 = $("#lblmoney2");//用户余额2（第二处地方显示余额）

                    //聊天相关
                    WebChat.Doms.Right.btnsend = $("#btnsend"); //发言按钮
                    WebChat.Doms.Right.btnfeiping = $("#btnfeiping"); //飞屏按钮
                    WebChat.Doms.Right.public = $("#zbj_chatlogs"); //公聊滚动窗口
                    WebChat.Doms.Right.private = $("#zbj_privatelogs");//私聊滚动窗口
                    WebChat.Doms.Other.pmgd_config = $("#pmgd_config");  //清屏滚屏按钮盒子
                    WebChat.Doms.Other.pmgd_clear = $("#pmgd_config_qp"); //清屏按钮
                    WebChat.Doms.Other.pmgd_scroll = $("#pmgd_config_gp"); //滚屏按钮
                    WebChat.Doms.Right.txtmsgto_name = $("#txtmsgto_name"); //悄悄话是对谁说得（input控件）
                    WebChat.Doms.Other.wait_to_name = $("#wait_to_name"); //悄悄话针对人物选择列表
                    WebChat.Doms.Right.chkqqh = $("#chkqqh"); //是否说悄悄话
                    WebChat.Doms.Right.sendemot = $("#btnbq");    //表情按钮
                    WebChat.Doms.Right.sendemot2 = $("#btnbq2");    //表情按钮2
                    WebChat.Doms.Other.emotlist = $("#emotlist");  //表情框
                    WebChat.Doms.Other.emotlist_face = $("#emotlist_face"); //表情盒子
                    WebChat.Doms.Other.ctlist = $("#ctlist"); //表情，作用未知

                    WebChat.Doms.Right.txtmsg = $("#txtmsg");   //对话框
                    WebChat.Doms.Right.talk_tabs = $("#talk_tabs"); //聊天窗口容器盒子
                    WebChat.Doms.Right.talk_tab_a = $("#talk_tab li"); //聊天窗口中的选项卡
                    
                    WebChat.Doms.Other.alert = $("#dialog-alert"); //飞屏弹窗
                    WebChat.Doms.Right.sendxlb = $("#btnxlb"); //喇叭按钮
                    WebChat.Doms.Right.btnxlb_ScrollList = $("#btnxlb_ScrollList"); //喇叭滚动列表
                    WebChat.Doms.Right.btnxlb_ScrollList.setInterval = null;//滚动列表定时器

                    WebChat.Doms.Other.dialog_font = $("#dialog-font"); //发言字体相关设置
                    WebChat.Doms.Other.dialog_font_preview = $("#dialog-font-preview"); //预览字体
                    WebChat.Doms.Other.dialog_autorespond = $("#dialog-autorespond");//自动回复弹窗？

                    //操作用户菜单，禁言等
                    WebChat.Doms.Other.contextmenu = $("#dialog-contextmenu"); //用户操作菜单
                    WebChat.Doms.Other.contextmenu_toname = $("#toname"); //用户操作菜单中的用户名

                    WebChat.Doms.Right.user_tab = $("#user_tab");  //用户盒子
                    WebChat.Doms.Right.user_tab_a = WebChat.Doms.Right.user_tab.find("li"); //用户与管理选项卡
                    WebChat.Doms.Right.user_tab_viewer = $("#onlineNum");//在线会员人数
                    WebChat.Doms.Right.user_tab_viewer2 = $("#onlineNum2");//在线会员人数2
                    WebChat.Doms.Right.user_tab_admin = $("#onlineAdmin"); //管理员在线人数
                    

                    WebChat.Doms.Right.user_list = $("#userlist"); //用户列表主框
                    WebChat.Doms.Right.user_list_list = $("#userlist");  //观众正常的列表
                    WebChat.Doms.Right.user_list_admin = $("#listadmin"); //管理员的列表
                    WebChat.Doms.Right.user_list_mic = $("#listmic"); //删除用户
                    
                    


                    //WebChat.Doms.Right.txtsearchuser = $("#txtsearchuser"); //搜索观众input控件
                    //WebChat.Doms.Right.user_list_search = $("#listsearch"); //搜索结果列表



                    //礼品相关
                    WebChat.Doms.Left.txt_gift_to = $("#gift_u");   //送礼物的对象
                    WebChat.Doms.Left.txt_gift_num = $("#gift_n");  //送礼个数input
                    WebChat.Doms.Left.txt_gift_num_btn = $("#gift_n_btn"); //送礼个数按钮
                    WebChat.Doms.Other.number = $("#dialog-number");//送礼个数的弹窗

                    WebChat.Doms.Left.btnlargess = $("#btnlargess"); //赠送按钮
                    WebChat.Doms.Left.gift_tabs = $("#gift_tabs");  //礼物的容器盒子

                    WebChat.Doms.Left.lb_list = $("#lb_list"); //礼物赠送消息

                    WebChat.Doms.Other.confirm = $("#dialog-confirm"); //收到礼物的提示相关

                    WebChat.Doms.Other.dialog_giftH = $("#dialog_giftH"); //礼物特效1
                    WebChat.Doms.Other.dialog_giftPT = $("#dialog_giftPT");//礼物特效2

                    WebChat.Doms.AtStart = $("#gift_AtStart");//道具抛物线起点位置区域
                    WebChat.Doms.AtEnd = $("#gift_AtEnd");//道具抛物线终点位置区域

                    //其他
                    WebChat.Doms.Other.reg = $("#dialog-reg");
                    WebChat.Doms.Other.login = $("#dialog-login");
                    WebChat.Doms.Left.left = $("#chat_left"); //下载插件提示相关



                    //设置海报
                    WebChat.Doms.Other.dialog_haibao = $("#dialog_haibao");
                    WebChat.Doms.Other.dialog_bgpic = $("#dialog_bgpic");

                    /*
                    
                   
                    WebChat.Doms.paodao = WebChat.Doms.doc.find("#paodao_div");
                    
                    
                    WebChat.Doms.Left.affiche = WebChat.Doms.all.find("#affiche");
                    WebChat.Doms.Left.gift_to = WebChat.Doms.Left.left.find("#gift_to");
                    
                    
                    

                    WebChat.Doms.Left.btnxlb_list=WebChat.Doms.Left.left.find("#btnxlb_list");
                    
                    WebChat.Doms.Right.right = WebChat.Doms.all.find("#chat_right");
                    
                    
                    WebChat.Doms.Right.talk_split = WebChat.Doms.Right.talk_tabs.find("#talk_split");
                    
                    WebChat.Doms.Right.talk_msg = WebChat.Doms.Right.right.find("#talk_msg");
                    WebChat.Doms.Right.sendemot = WebChat.Doms.Right.right.find("#btnbq");
                    WebChat.Doms.Right.chatoptions = WebChat.Doms.body.find("#btnsz");  //聊天设置
                    WebChat.Doms.Right.sendct = WebChat.Doms.Right.right.find("#btnct");   //彩条
                    
                    WebChat.Doms.Right.sendxlb_list=WebChat.Doms.all.find("#btnxlb_list");
                    
                    
                    
                    
                    WebChat.Doms.Right.talk_gift_list = WebChat.Doms.Right.talk_tabs.find("#talk_gift_list"); //礼物记录窗口
                    //WebChat.Doms.Right.talk_blogs = WebChat.Doms.Right.talk_tabs.find("#talk_blogs");
                    WebChat.Doms.Right.songbutton = WebChat.Doms.Right.right.find("#songbutton");
                    WebChat.Doms.Right.reqlist = WebChat.Doms.Right.right.find("#reqlist");
                    WebChat.Doms.Right.pagin_reqlist = WebChat.Doms.Right.right.find("#pagin_reqlist");

                    WebChat.Doms.Right.rightlist = WebChat.Doms.Right.right.find("#rightlist");
                    
                    
                   
                    
                    

                    //WebChat.Doms.Other.other = WebChat.Doms.body.find("#other-window");
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    
                    WebChat.Doms.Other.dialog_diangeben = WebChat.Doms.body.find("#dialog_diangeben");
                    WebChat.Doms.Other.dialog_songlist = WebChat.Doms.Other.dialog_diangeben.find("#dialog_songlist");
                    WebChat.Doms.Other.pagin_songlist = WebChat.Doms.Other.dialog_diangeben.find("#pagin_diangeben");
                   
                    
                    //console.timeEnd("doms");
                    */
                }
            },
            //配置
            Config: {
                //数据信息
                data: {
                    //房间IDX
                    roomidx: 0,
                    //当前用户IDX
                    idx: 0,
                    //当前用户identity身份
                    identity: 7,
                    //当前用户userLevel消费等级
                    userLevel: 0,
                    //当前用户vip等级
                    vipLevel: 0,
                    //主播等级
                    anchorLevel: 0,
                    //超级粉丝之星
                    fansstar: 0,
                    //当前直播之星
                    livestar: 0,
                    //是否是三麦房
                    is3mic: 0,
                    //自己的麦序ID
                    mxid: -1,
                    //喇叭数量
                    labaNum: 0,
                    //飞屏数量
                    feipingNum:0
                },
                //海报图片服务器
                haibaourl: 'http://api.9513.com/upph/SaveLivePic.ashx',
                //设置背景图片地址
                bgimagesethost: 'http://api.9513.com/upph/SaveBgImage.ashx',
                //充值地址
                pay_url: '/Pay.aspx',
                //免费飞屏与喇叭数量获取地址
                Laba_FeipingNumUrl: '/Ashx/GetFree_LabaFeipin.ashx',
                //进房间发言时间限制(秒)
                sendlimitinroom: 0,
                //发言时间间隔(毫秒)
                sendlimit: 1000,
                //发言时间间隔(毫秒),普通用户
                sendlimit_normal: 3000,
                //彩条发送时间间隔(毫秒)
                colourbarlimit: 10000,
                //消息最大上限数，超过则清屏
                clearnum: 25,
                //在线观众
                onlineviewer: 0,
                //在线管理
                onlineadmin: 0,
                //表情列数
                emotcolumns: 13,
                //是否可以操作用户（踢人等）
                usercontrol: 0,
                //踢人默认时间（分钟）
                outTime: 1,
                //普通用户聊天字符限制
                userlengthcontrol: 12,
                //V1-V2用户聊天字符限制
                user2lengthcontrol: 35,
                //聊天字符限制
                msglengthcontrol: 100,
                //加载图片地址
                loadingimg: sr + 'images/loading.gif',
                //房间付费最小金额
                roompay_min: 100,
                //房间付费最大金额
                roompay_max: 1000000,
                //公聊窗口默认高度
                public_defualtheight: 320,
                //公聊窗口是否自动滚动
                public_autoscroll: true,
                //私聊窗口默认高度
                private_defualtheight: 135,
                //私聊窗口最大高度
                private_maxheight: 370,
                //私聊窗口最小高度
                private_minheight: 50,
                //私聊窗口是否自动滚动
                private_autoscroll: true,
                //小喇叭窗口是否自动滚动
                affiche_autoscroll: true,
                //滚屏清屏
                gpqpimg: {
                    //滚屏
                    gp: sr + 'images/gp.png',
                    //不允许滚屏
                    gpx: sr + 'images/gpx.png'
                },
                //启用禁用悄悄话
                qqhimg: {
                    //允许
                    qqh:sr+'images/qqh.png',
                    //禁止
                    qqhx:sr+'images/qqhx.png'
                },
                //点歌
                song: {
                    js: sr + 'js/weishow.live.songmanage.min.js?d=20110921',
                    //设置点歌本
                    sz: sr + 'images/szdgb.png',
                    //我要点歌
                    dg: sr + 'images/wydg.png',
                    //每页显示条数
                    pagesize: 8,
                    //获取点歌列表地址
                    getlisturl: '/ashx/live/getsonglist.ashx',
                    //获取点歌请求列表地址
                    getrequesturl: '/ashx/live/getsongrequest.ashx',
                    //歌管理地址
                    manageurl: '/ashx/live/songmanage.ashx'
                },
                //房间公告最大字符数
                gg_msgmax: 50,
                //日志最大字符数
                blog_msgmax: 200,
                //小喇叭最大字符数
                xiaolaba_msgmax: 40,
                //飞屏最大字符数
                feiping_msgmax: 25,
                //送礼物最大个数
                giftnum_max: 9999,
                //送礼刷新间隔时间（毫秒）
                giveInterval: 200,
                //每次刷多少个礼物
                giveNumber: 5,
                //自动停止刷礼物时间（毫秒）
                giveTimeout: 30000,
                //礼物列表
                gift: { 
                    //礼物配置文件地址  gift.url
                    url: '/ashx/live/getgift.ashx',
                    //flash的礼物配置文件地址 gift.flashurl
                    flashurl: sr + 'xml/gift.xml',
                    //礼物大图路径  gift.bigurl
                    bigurl: sr + 'images/giftjs/',
                    //礼物小图路径  gift.smallurl
                    smallurl: sr + 'images/giftjs/50-50_png/',
                    //展示礼物路径  gift.swfurl
                    swfurl: sr + 'flash/gift/',
                    //FLASH跑道礼物地址  gift.giftswfurl
                    giftswfurl: sr + 'images/giftjs/',
                    //是否展示礼物
                    showgift: true,
                    //展示配置数
                    showcount: ',300,520,888,999,1314,9999,',
                    //礼物数据
                    data: undefined,
                    //礼物加载完成事件
                    load: null
                },
                //展示礼物
                showGift: {
                    //大额展示图片
                    largeimg: sr + 'images/giftD_2.gif',
                    //大额金额限定
                    largemoney: 100000,
                    //普通展示图片
                    normalimg: sr + 'images/giftD_1.gif',
                    //普通数量限定
                    normalnum: 98
                },
                //要过滤的域名后缀
                filter_domain: 'com([.。．]cn)?|net([.。．]cn)?|org([.。．]cn)?|gov([.。．]cn)?|cn|mobi|tel|asia|name|me|info|cc|hk|tw|biz|tv|tk|in|us|gy|ws|gd|us|im|gs|pn|vu|vn|vc|jp|tr|fr|it',
                //过滤广告正则
                filter_ad:'[\u62630-9\uff11\uff12\uff13\uff14\uff15\uff16\uff17\uff18\uff19\uff10\u4e00\u4e8c\u4e09\u56db\u4e94\u516d\u4e03\u516b\u4e5d\u96f6\u2460\u2461\u2462\u2463\u2464\u2465\u2466\u2467\u2468\u3220\u3221\u3222\u3223\u3224\u3225\u3226\u3227\u3228\u2474\u2475\u2476\u2477\u2478\u2479\u247a\u247b\u247c\u58f9\u8d30\u53c1\u8086\u4f0d\u9646\u67d2\u634c\u7396./\uff0e\u70b9\u3002a-z\uff41\uff42\uff43\uff44\uff45\uff46\uff47\uff48\uff49\uff47\uff4b\uff4c\uff4d\uff4e\uff4f\uff50\uff51\uff52\uff53\uff54\uff55\uff56\uff57\uff58\uff59\uff5a\uff21\uff22\uff23\uff24\uff25\uff26\uff27\uff28\uff29\uff27\uff2b\uff2c\uff2d\uff2e\uff2f\uff30\uff31\uff32\uff33\uff34\uff35\uff36\uff37\uff38\uff39\uff3a\u3089\u310b\u2488\u2489\u248b\u248c\u248d\u248e\u248f\u2490\u0392\u0421\u039f\u039a\u041a\u041c\u0422\u03a7\u0399\u039d\u0442\u043a\u03c4\u03ba\u2530\u03a4]',
                //用户身份图片路径
                users_faceurl: sr + 'v2.0/images/face/',
                //表情目录路径
                emot_url: sr + 'images/emot/',
                //微博登录页面地址
                weibologin: 'http://login.show.weibo.com/minilogin.php',
                //颜色选取插件
                colourPicker: {
                    js: sr + 'js/jquery.colourPicker.js',
                    ico: sr + 'images/jquery.colourPicker.gif'
                },
                //分页插件
                pagination: {
                    js: sr + 'js/jquery.pagination.js'
                },
                //用户列表
                users: undefined,
                //表情列表
                emot: [{ "name": "第一页", "val": "b", "list": [{ "k": "", "v": "53"},{ "k": "", "v": "1" }, { "k": "", "v": "2" }, { "k": "", "v": "3" }, { "k": "", "v": "4" }, { "k": "", "v": "5" }, { "k": "", "v": "6" }, { "k": "", "v": "7" }, { "k": "", "v": "8" }, { "k": "", "v": "9" }, { "k": "", "v": "10" }, { "k": "", "v": "11" }, { "k": "", "v": "12" }, { "k": "", "v": "13" }, { "k": "", "v": "14" }, { "k": "", "v": "15" }, { "k": "", "v": "16" }, { "k": "", "v": "17" }, { "k": "", "v": "18" }, { "k": "", "v": "19" }, { "k": "", "v": "20" }, { "k": "", "v": "21" }, { "k": "", "v": "22" }, { "k": "", "v": "23" }, { "k": "", "v": "24" }, { "k": "", "v": "25" }, { "k": "", "v": "26" }, { "k": "", "v": "27" }, { "k": "", "v": "28" }, { "k": "", "v": "29" }, { "k": "", "v": "30" }, { "k": "", "v": "31" }, { "k": "", "v": "32" }, { "k": "", "v": "33" }, { "k": "", "v": "34" }, { "k": "", "v": "35" }, { "k": "", "v": "36" }, { "k": "", "v": "37" }, { "k": "", "v": "38" }, { "k": "", "v": "39" }, { "k": "", "v": "40" }, { "k": "", "v": "41" }, { "k": "", "v": "42" },{ "k": "", "v": "44" }, { "k": "", "v": "45" }, { "k": "", "v": "46" }, { "k": "", "v": "47" }, { "k": "", "v": "48" }, { "k": "", "v": "49" }, { "k": "", "v": "50" }, { "k": "", "v": "51" }, { "k": "", "v": "52"}] }, { "name": "第二页", "val": "a", "list": [{ "k": "", "v": "1" }, { "k": "", "v": "2" }, { "k": "", "v": "3" }, { "k": "", "v": "5" }, { "k": "", "v": "7" }, { "k": "", "v": "8" }, { "k": "", "v": "9" }, { "k": "", "v": "10" }, { "k": "", "v": "11" }, { "k": "", "v": "12" }, { "k": "", "v": "13" }, { "k": "", "v": "14" }, { "k": "", "v": "15" }, { "k": "", "v": "16" }, { "k": "", "v": "17" }, { "k": "", "v": "18" }, { "k": "", "v": "19" }, { "k": "", "v": "21" }, { "k": "", "v": "22" }, { "k": "", "v": "23" }, { "k": "", "v": "24" }, { "k": "", "v": "26" }, { "k": "", "v": "27" }, { "k": "", "v": "28" }, { "k": "", "v": "29" }, { "k": "", "v": "30" }, { "k": "", "v": "31" }, { "k": "", "v": "32" }, { "k": "", "v": "33" }, { "k": "", "v": "34" }, { "k": "", "v": "35" }, { "k": "", "v": "36" }, { "k": "", "v": "37" }, { "k": "", "v": "38" }, { "k": "", "v": "39" }, { "k": "", "v": "40" }, { "k": "", "v": "41" }, { "k": "", "v": "42" }, { "k": "", "v": "44" }, { "k": "", "v": "45" }, { "k": "", "v": "46" }, { "k": "", "v": "47" }, { "k": "", "v": "48" }, { "k": "", "v": "49" }, { "k": "", "v": "50" }, { "k": "", "v": "51" }, { "k": "", "v": "52" }, { "k": "", "v": "53" }, { "k": "", "v": "54" }, { "k": "", "v": "55" }, { "k": "", "v": "56"}]},{ "name": "专属", "val": "c", "list": [{ "k": "就是帅", "v": "1"},{ "k": "卖萌", "v": "2"},{ "k": "捏脸", "v": "3"},{ "k": "飞吻", "v": "4"},{ "k": "害羞", "v": "5"}]}],
                //彩条
                ct: [
                //真好听 /zht
                    {"k": "/zht","n":"真好听", "v": "<img src='" + sr + "images/ct/zht.gif' />" },
                //赞 /zan
                    {"k": "/zan","n":"赞", "v": "<img src='" + sr + "images/ct/zan.gif' />" },
                //你真棒/tbl
                    {"k": "/tbl","n":"你真棒", "v": "<img src='" + sr + "images/ct/tbl.gif' />" },
                //非常好听 /fcht
                    {"k": "/fcht","n":"非常好听", "v": "<p class=\"fs_20\"><span class=\"z_3\">∴★</span><span class=\"green\">啪</span><span class=\"z_3\">啪</span><span class=\"green\">啪</span><span class=\"z_3\">★∴</span><span class=\"g_3\">▁</span><span class=\"g_3\">▂</span><span class=\"g_3\">▃</span><span class=\"g_4\">▄</span><span class=\"g_5\">▅</span><span class=\"g_6\">▆</span><span class=\"g_7\">▇</span><span class=\"z_1\">非常好听</span><span class=\"r_1\">▇</span><span class=\"r_2\">▆</span><span class=\"r_3\">▅</span><span class=\"r_4\">▄</span><span class=\"r_5\">▃</span><span class=\"r_5\">▂</span><span class=\"r_5\">▁</span><span class=\"z_1\">∴★°★∴</span></p>" },
                //啪啪啪 /ppp
                    {"k": "/ppp","n":"啪啪啪", "v": "<p class=\"fs_20\"><span class=\"red\">啪啪啪▂▃▄▅▆▇█▇▆▅▄▃▂</span><img src=\"" + sr + "images/ct/1.gif\" /></p>" },
                //加油 /jy
                    {"k": "/jy","n":"加油", "v": "<p class=\"fs_20\"><img src=\"" + sr + "images/ct/6-1.gif\" /><img src=\"" + sr + "images/ct/6-2.gif\" /><img src=\"" + sr + "images/ct/2.gif\" /><img src=\"" + sr + "images/ct/6-2.gif\" /><span class=\"yellow\">^(oo)^...</span> </p>" },
                //红心 /hx
                    {"k": "/hx","n":"红心", "v": "<p class=\"fs_20\"><img src=\"" + sr + "images/ct/4-1.gif\" /><img src=\"" + sr + "images/ct/4-2.gif\" /><img src=\"" + sr + "images/ct/4-3.gif\" /><img src=\"" + sr + "images/ct/4-4.gif\" /><img src=\"" + sr + "images/ct/4-5.gif\" /><img src=\"" + sr + "images/ct/4.gif\" /><img src=\"" + sr + "images/ct/4-5.gif\" /><img src=\"" + sr + "images/ct/4-4.gif\" /><img src=\"" + sr + "images/ct/4-3.gif\" /><img src=\"" + sr + "images/ct/4-2.gif\" /><img src=\"" + sr + "images/ct/4-1.gif\" /></p>" },
                //太感动 /tgd
                    {"k": "/tgd","n":"太感动", "v": "<p class=\"fs_20\"><img src=\"" + sr + "images/ct/7-1.gif\" /><img src=\"" + sr + "images/ct/7-2.gif\" /><img src=\"" + sr + "images/ct/7-3.gif\" /><span class=\"z_1\">Good</span><img src=\"" + sr + "images/ct/7-4.gif\" /><img src=\"" + sr + "images/ct/7.gif\" /><span class=\"z_3\"> 太感动了～!</span>   <img src=\"" + sr + "images/ct/7-4.gif\" /><img src=\"" + sr + "images/ct/7-5.gif\" /><img src=\"" + sr + "images/ct/7-6.gif\" /><span class=\"z_1\">gooD</span><img src=\"" + sr + "images/ct/7-3.gif\" /><span class=\"b_3\"> 太好了～!</span><img src=\"" + sr + "images/ct/7.gif\" /> <img src=\"" + sr + "images/ct/7.gif\" />  <span class=\"z_1\">GOOD</span><span class=\"b_3\">     太好了～! </span>  </p>" },
                //太强悍 /tqh
                    {"k": "/tqh","n":"太强悍", "v": "<p class=\"fs_20\"> <img src=\"" + sr + "images/ct/3.gif\"/><img src=\"" + sr + "images/ct/8.gif\" /> <span class=\"h_1\">太</span><span class=\"h_2\">强</span><span class=\"h_3\">悍</span><span class=\"h_4\">了</span> <span class=\"red\"> 太</span><span class=\"yellow\">厉</span><span class=\"y_2\">害</span><span class=\"y_3\">了</span> <img src=\"" + sr + "images/ct/8.gif\" />  <img src=\"" + sr + "images/ct/3.gif\"/>" },
                //冒个泡 /mgp
                    {"k": "/mgp","n":"冒个泡", "v": "<img src='" + sr + "images/ct/mgp.gif' />" }
                ],
                //敏感词
                LXB: '',
                //自动回复
                autorespond: {
                    //状态
                    status: 0,
                    //消息
                    msg: '',
                    //设置地址
                    seturl: '/ashx/live/setautorespond.ashx',
                    //获取地址
                    geturl: '/ashx/live/getautorespond.ashx'
                },
                //分享
                share: {
                    //用户是否分享
                    isshare: false,
                    //设置地址
                    seturl: '/ashx/live/setshare.ashx',
                    //获取地址
                    geturl: '/ashx/live/getshare.ashx'
                },
                //错误提示
                error: {},
                //获取用户IP地址
                getipurl: '/ashx/member/getclientip.ashx',
                //房间类型
                roomtype:{single:0,threemic:3,multimic:5},
                //收藏
                favorite:{
                    isadd:false,
                    url:'/ajax/addfavorite.aspx'
                }
            },
            //生成一个GUID
            getGuid: function() {
                var guid = "";
                for(var i = 1; i <= 32; i++) {
                    var n = Math.floor(Math.random() * 16.0).toString(16);
                    guid += n;
                    if((i == 8) || (i == 12) || (i == 16) || (i == 20)) guid += "-";
                }
                return guid;
            },
            //获取字符串的hascode
            getHashCode: function(str) {
                str = str + "";
                var h = 0, off = 0;
                var len = str.length;
                for(var i = 0; i < len; i++) {
                    h = 31 * h + str.charCodeAt(off++);
                    if(h > 0x7fffffff || h < 0x80000000) {
                        h = h & 0xffffffff;
                    }
                }
                return h;
            },
            //检查正整数
            isNumber: function(num) {
                if(!num) return false;
                var strP = /^(\d)?\d*$/;
                if(!strP.test(num)) {
                    return false;
                }
                try {
                    if(parseInt(num, 10) != num) {
                        return false;
                    }
                } catch(ex) {
                    return false;
                }
                return true;
            },
            //获取用户vip标识、性别图片
            getUserPic: function(user) {
                var img = '';
                var tmp = '<img style="vertical-align:middle;"  src="' + WebChat.Config.users_faceurl + '$pic.gif?d=201405291522" />';
                var temp2 = tmp.replace('bottom', 'middle');
                var userlevel = user.userLevel;
                var _resetLogo = WebChat.Config.resetLogo && WebChat.Config.resetLogo[user.idx];
                var _resetVip=WebChat.Config.resetVip &&WebChat.Config.resetVip[user.idx];
                //幸运女神
                if(WebChat.Config.gyygnns && WebChat.Config.gyygnns[user.idx] === 0)//&&userlevel<100
                {
                    userlevel = 102;
                }
                if(user.identity!==1 && user.identity!==11 && user.identity!==7) {
                    img = tmp.replace('$pic', (user.identity == 3 ? 'sexm_' : user.identity === 9 ? 'sexf' : 'sexu') + (user.sex > 1 ? 1 : user.sex));
                }

                //守护公聊图标
                if (user.guardtype) {
                    var src = "http://sr.9513.com/Images/guard/" + user.guardtype + ".png";
                    img += '<img style="vertical-align:middle;margin-right:2px;" src="' + src + '" />'
                } else {
                    var current = $("#GuardList li[dataIdx=" + user.cno + "]");
                    if (current.length > 0) {
                        var src = "http://sr.9513.com/Images/guard/" + current.attr("data-Type") + ".png";
                        img += '<img style="vertical-align:middle;margin-right:2px;" src="' + src + '" />'
                    }
                }


                if(user.identity === 1 || user.identity === 2  || user.identity === 8|| user.identity === 10|| user.identity === 11) {
                    var _identity = pagedata.roomtype === jw.Config.roomtype.multimic ? (user.identity === 1 ? 'sz' : user.identity) : user.identity;
                    var anchorLevel = user.anchorLevel; //user.identity === 11?user.anchorLevel:WebChat.Config.data.anchorLevel;
                    //if(pagedata.roomtype!=WebChat.Config.roomtype.multimic){
                    //     anchorLevel=user.anchorLevel;
                    //}
                    if ((_identity == 1 || _identity == 11) && anchorLevel > 0) {
                        img = temp2.replace('$pic', 'z' + anchorLevel);
                        img += tmp.replace('bottom', 'top').replace('$pic', _identity);
                    } else{
                        img += tmp.replace('$pic', _identity);
                    }
                    if(_resetVip!=null){
                        img += temp2.replace('$pic',_resetVip.logo);
                    }
                } else if(user.vipLevel > 79) {
                    var _vl = { 100: 2, 80: 8, 90: 10 };
                    img += tmp.replace('$pic', _vl[user.vipLevel]);
                    if(_resetVip!=null){
                        img += temp2.replace('$pic',_resetVip.logo);
                    }
                }
                else if(user.identity!==7) {
                    
                    if(userlevel > 0) {
                        if(user.starLevel > 0) {
                            var star = '';
                            if(userlevel < 11) {
                                star = 'v-'+ user.starLevel;
                            }
                            else if(userlevel > 10 && userlevel < 23) {
                                star = 'v-' + user.starLevel;
                            }
                            else if(userlevel > 22 && userlevel < 26) {
                                star = 'v23-' + user.starLevel;
                            }
                            else {
                                star = 'v26-' + user.starLevel;
                            }
                            star = WebChat.Config.users_faceurl + star;
                            var userpic = WebChat.Config.users_faceurl + 'v' + userlevel + '.gif?v=2.0';
                            if(_resetLogo!=null){
                                //userpic=userpic.replace('v' + userlevel,WebChat.Config.resetLogo[user.idx].logo);
                                img+=tmp.replace('$pic', WebChat.Config.resetLogo[user.idx].logo);
                            }
                            else{
                                img += '<img style="vertical-align:middle;background:url(' + userpic + ') no-repeat;" src="' + star + 's.gif" />';
                            }
                         
                        }
                        else {
                            img += tmp.replace('$pic', 'v' + userlevel);
                            if(_resetLogo!=null){
                                img=img.replace('v' + userlevel,WebChat.Config.resetLogo[user.idx].logo);
                            }
                        }
                    }
                    //绿卡图标
                    //                    if(user.isGreenCard){
                    //                          img+=temp2.replace('$pic', 'gcard');
                    //                    }
                    
                    if(user.vipLevel > 0 && user.vipLevel < 80) {
                        //活动奖励logo替换
                        if(_resetVip!=null){
                            img += temp2.replace('$pic',_resetVip.logo);
                        }
                        else if(WebChat.Config.quzidx&&WebChat.Config.quzidx[user.idx])
                        {
                            img+=temp2.replace("$pic",(WebChat.Config.quzidx[user.idx].ico));
                        }
                        else
                        {   
                            img += temp2.replace('$pic', 'vip' + ((WebChat.Config.hmjidx&&WebChat.Config.hmjidx[user.idx]) ? '_hmj' : user.vipLevel));
                        }
                    }
                    else
                    {
                        if(_resetVip!=null){
                            img += temp2.replace('$pic',_resetVip.logo);
                        }
                        else if(WebChat.Config.quzidx&&WebChat.Config.quzidx[user.idx]){
                            img+=temp2.replace("$pic",(WebChat.Config.quzidx[user.idx].ico));
                        }
                    }
                }
                return img;
            },
            //获取用户聊天头像标识图片
            getChatPic: function(user, needfirst, needname, honorific, contextmenu) {
                var img = '';
                var setimg = function() {
                    var tmp = '<img style="vertical-align:middle;margin-right:2px;"  src="' + WebChat.Config.users_faceurl + '$pic.gif?d=201405291522" />';
                    var userlevel = user.userLevel;
                    var _resetLogo = WebChat.Config.resetLogo && WebChat.Config.resetLogo[user.idx];
                    //幸运女神
                    if(WebChat.Config.gyygnns && WebChat.Config.gyygnns[user.idx] === 0)//&&userlevel<100
                    {
                        userlevel = 102;
                    }
                    if(user.from==1) {
                        img += tmp.replace('<img','<img title="来自Android"').replace('$pic.gif', 'phone.png');
                    }else if(user.from==2) {
                        img += tmp.replace('<img','<img title="来自iPhone"').replace('$pic.gif', 'iphone.png');
                    }
                    if(user.identity === 1 || user.identity === 2  || user.identity === 8|| user.identity === 10|| user.identity === 11) {
                        //秀场王后
                        if ((user.identity === 1 || user.identity === 11) && userlevel === 100) {
                            img += tmp.replace('$pic', 'xcwh').replace(':middle;', ':baseline;');
                        }
                        img += tmp.replace('$pic', pagedata.roomtype === jw.Config.roomtype.multimic ? (user.identity === 1 ? 'sz' : user.identity) : user.identity);
                    } else if(user.vipLevel > 79) {
                        var _vl = { 100: 2, 80: 8, 90: 10 };
                        img += tmp.replace('$pic', _vl[user.vipLevel]);
                    }
                    else if(userlevel > 0) {
                        //秀场之王
                        if(userlevel === 101) {
                            img += tmp.replace('$pic', 'xczw').replace(':middle;', ':baseline;');
                        }
                            //秀场王后
                        else if(userlevel === 100) {
                            img += tmp.replace('$pic', 'xcwh').replace(':middle;', ':baseline;');
                        }
                            //粉丝皇冠
                        else if(WebChat.Config.data.fansstar === user.idx) {
                            img += tmp.replace('$pic', 'FsHg');//.replace(':middle;', ':baseline;');
                        }
                            //本场皇冠
                        else if(WebChat.Config.data.livestar === user.idx) {
                            img += tmp.replace('$pic', 'BcHg');
                        }
                        img += tmp.replace('$pic', 'v' + userlevel);
                        if(_resetLogo!=null){
                            img=img.replace('v' + userlevel,WebChat.Config.resetLogo[user.idx].logo);
                        }
                    }
                    //绿卡图标
                    //                    if(user.isGreenCard){
                    //                          img+=temp2.replace('$pic', 'gcard');
                    //                    }
                    var _resetVip=WebChat.Config.resetVip &&WebChat.Config.resetVip[user.idx];
                    if(user.vipLevel > 0 && user.vipLevel < 80) {
                        if(_resetVip!=null)
                        {
                            img+=tmp.replace("$pic",_resetVip.logo);
                        }
                        else if(WebChat.Config.quzidx&&WebChat.Config.quzidx[user.idx])
                        {
                            img+=tmp.replace("$pic",(WebChat.Config.quzidx[user.idx].ico));
                        }
                        else
                        {
                            img += tmp.replace('$pic', 'vip' + ((WebChat.Config.hmjidx&&WebChat.Config.hmjidx[user.idx]) ? '_hmj' : user.vipLevel));
                        }
                    }
                    else
                    {
                        if(_resetVip!=null)
                        {
                            img+=tmp.replace("$pic",_resetVip.logo);
                            
                        }
                        else if(WebChat.Config.quzidx&&WebChat.Config.quzidx[user.idx])
                        {
                            img+=tmp.replace("$pic",(WebChat.Config.quzidx[user.idx].ico));
                        }
                    }
                };
                //守护公聊图标
                if (user.guardtype) {
                    var src = "http://sr.9513.com/Images/guard/" + user.guardtype + ".png";
                    img += '<img style="vertical-align:middle;margin-right:2px;" src="' + src + '" />'
                } else {
                    var current = $("#GuardList li[dataIdx=" + user.cno + "]");
                    if (current.length > 0) {
                        var src = "http://sr.9513.com/Images/guard/" + current.attr("data-Type") + ".png";
                        img += '<img style="vertical-align:middle;margin-right:2px;" src="' + src + '" />'
                    }
                }

                if(needname == null || needname) {
                    if(user.idx == WebChat.Config.data.idx && (needfirst != null && needfirst)) {
                        img = '<a class="user you" href="#" onclick="return false;" hidefocus="true">' + (honorific == null || honorific == false ? '你' : '您') + '</a>';
                    }
                    else {
                        setimg();
                        img += '<a idx="' + user.idx + '" cno="'+user.cno+'" identity="' + user.identity + '" userLevel="' + user.userLevel + '" vipLevel="' + user.vipLevel + '" class="user" href="#"  onclick="' + (contextmenu == null || contextmenu ? 'WebChat.Events.clickUser(this);' : '') + 'return false;"  hidefocus="true">' + user.userName.unescape() + '</a>';
                    }
                }
                else {
                    setimg();
                }
                return img;
            },
            //在用户列表中获取用户JSON
            getUserJsonOnList: function(idx, uname, cur) {
                var player = WebChat.Doms.chatComm.getPlayerInfoByIdx(idx);
                if(player) {
                    return player;
                }
                if(cur == null) {
                    cur = WebChat.Doms.Right.user_list_list.find("ul" + (idx != null ? "[idx='" + idx + "']" : "[uname='" + uname + "']"));
                }
                if(cur.length == 1) {
                    return { idx: parseInt(cur.attr("idx"),10),cno: parseInt(cur.attr("cno"),10), userName: cur.attr("uname"), identity: parseInt(cur.attr("identity"),0), userLevel: parseInt(cur.attr("userLevel"),10), vipLevel: parseInt(cur.attr("vipLevel"),10) };
                }
                else {
                    return { idx: idx, cno: idx, userName: uname, identity: 6, userLevel: 0, vipLevel: 0 };
                }
            },
            //在用户列表中获取用户图片信息
            getChatPicOnList: function(idx, uname) {
                var cur = WebChat.Doms.Right.user_list_list.find("ul" + (idx != null ? "[idx='" + idx + "']" : "[uname='" + uname + "']"));
                var name = '';
                if(cur.length == 1) {
                    name = WebChat.getChatPic(WebChat.getUserJsonOnList(idx, uname, cur));
                }
                else {
                    name = '<a class="user" href="#" ' + (idx != null ? 'idx="' + idx + '"' : '') + ' onclick="return false;" hidefocus="true" >' + uname + '</a>';
                }
                return name;
            },
            //图片自适应
            imgAdaptive: function(obj, width, height) {
                var imageRate = obj.offsetWidth / obj.offsetHeight;
                if(width > 0 && obj.offsetWidth > width) {
                    obj.style.width = width + "px";
                    obj.style.Height = width / imageRate + "px";
                }
                if(height > 0 && obj.offsetHeight > height) {
                    obj.style.width = height * imageRate + "px";
                    obj.style.Height = height + "px";
                }
            },
            //获取表情图片
            getEmotUrl: function(p, v, sys, static) {
                var str = '';
                var _d = '20120419';
                if(v == 52) {
                    _d = '20120813';
                }
                if(sys) {
                    str = WebChat.Config.emot_url + p + '/' + v + (static ? '_s' : '') + '.gif?d=' + _d;
                }
                else {
                    if(p == "a") {
                        var pc = ',0,4,6,20,25,43,';
                        if(pc.indexOf(',' + v + ',') == -1 && v > 0 && v < 57) {
                            str = parseInt(v, 10);
                            str = WebChat.Config.emot_url + p + '/' + str + '.gif?d=' + _d;
                        }
                        else
                            str = '[' + p + '/' + v + ']';
                    }
                    else if(p == "b" && v > 0 && v <= 53) {
                        str = parseInt(v, 10);
                        str = WebChat.Config.emot_url + p + '/' + str + '.gif?d=' + _d;
                    }
                    else if(p=='c'&&v > 0 && v <= 5) {
                        str = parseInt(v, 10);
                        str = WebChat.Config.emot_url + p + '/' + str + '.gif?d=' + _d;
                    }
                    else
                        str = '[' + p + '/' + v + ']';
                }
                return str;
            },
            //获取字体设置代码
            getFontOptions: function() {
                var p = WebChat.Doms.Other.dialog_font_preview;
                var fp = "fontoptions{";
                var co = p.data("tcolor");
                var fsi = p.data("font-size");
                var fw = p.data("font-weight");
                var fs = p.data("font-style");
                var td = p.data("text-decoration");
                if(co && co != "#666666") {
                    fp += "color:" + co;
                }
                if(fsi && fsi != "12px") {
                    if(fp.length > 12)
                        fp += ";";
                    fp += "font-size:" + fsi;
                }
                if(fw && fw != "normal") {
                    if(fp.length > 12)
                        fp += ";";
                    fp += "font-weight:" + fw;
                }
                if(fs && fs != "normal") {
                    if(fp.length > 12)
                        fp += ";";
                    fp += "font-style:" + fs;
                }
                if(td && td != "none") {
                    if(fp.length > 12)
                        fp += ";";
                    fp += "text-decoration:" + td;
                }
                if(fp.length == 12) {
                    fp = "";
                }
                return fp;
            },
            //阻止浏览器的默认行为
            stopDefault: function(e) {
                //阻止默认浏览器动作(W3C)
                if(e && e.preventDefault)
                    e.preventDefault();
                    //IE中阻止函数器默认动作的方式
                else
                    window.event.returnValue = false;
            },
            //获取消息权限
            getMessagePower: function(msg, sender, isqqh) {
                msg = unescape(msg);
                var isself = WebChat.Config.data.idx == sender.idx;
                var result = true;
                if((getStrLength(msg)>10 && sender.identity===7 || sender.identity < 1)) {
                    result = false;
                    if(isself)
                        WebChat.Message.pleaselogin("游客发言不能超出5个字符！");
                }
                    //发言
                else if(msg.length == 0) {
                    result = false;
                    if(isself)
                        WebChat.Message.chat.private.system("发言不能为空！", null, 1);
                }
                else if((sender.identity===3 || sender.identity===4 || sender.identity===6) && sender.vipLevel < 79) {
                    if (sender.userLevel < 1 && msg.length > WebChat.Config.userlengthcontrol) {
                        result = false;
                        if (isself)
                            WebChat.Message.chat.private.system("V1以下用户发言不能超过" + WebChat.Config.userlengthcontrol + "个字！快快升级吧！");
                    } else if (sender.userLevel < 3 && msg.length > WebChat.Config.user2lengthcontrol) {
                        result = false;
                        if (isself)
                            WebChat.Message.chat.private.system("V3以下用户发言不能超过" + WebChat.Config.user2lengthcontrol + "个字！快快升级吧！");
                    }
                    if (sender.userLevel < 5) {
                        var c = msg.replace(/\[([\d\w]+)\/([\d\w]+)\]/g, '').match(new RegExp(WebChat.Config.filter_ad,'gi'));
                        if (c && c.length > 5) {
                            result = false;
                            if (isself) {
                                WebChat.Message.chat.private.system("您的发言中含有过多字母或数字！");
                            }
                        }
                    }
                }
                var str = msg;
                var fsindex = msg.indexOf("fontoptions{");
                if(fsindex > -1) {
                    str = str.substr(0, fsindex);
                }
                fsindex = str.indexOf("autorespond{");
                if(fsindex > -1) {
                    str = str.substr(0, fsindex);
                }
                if(str.length > WebChat.Config.msglengthcontrol) {
                    result = false;
                    if(isself)
                        WebChat.Message.chat.private.system("发言不能超过" + WebChat.Config.msglengthcontrol + "个字！");
                }
                if(result) {
                    //悄悄话
                    if (isqqh != null && isqqh) {
                        if ((sender.identity === 3 || sender.identity === 4 || sender.identity === 6) && sender.userLevel < 3 && sender.vipLevel < 1 && sender.vipLevel < 79) {
                            result = false;
                            if (isself)
                                WebChat.Message.chat.private.system('您的等级不足<a href="' + WebChat.Config.pay_url + '" target="_blank" hidefocus="true">V3</a>，不能发送悄悄话！');
                        }
                    }

                    if (!isself) {
                        //                        if(WebChat.Config.data.userLevel < 3 && WebChat.Config.data.identity!== 1 && WebChat.Config.data.identity!== 2 && WebChat.Config.data.identity!== 8) {
                        //                            var now = (new Date()).getTime();
                        //                            var limit = WebChat.Config.sendlimitinroom;
                        //                            if((now - WebChat.Comm.sendChat.inRoomTime) / 1000 <= limit) {
                        //                                result = false;
                        //                                WebChat.Message.chat.private.system('进入房间' + limit + '秒后才能发言！');
                        //                            }
                        //                        }
                    } else {
                        //字体设置,自动回复
                        if (msg.indexOf('fontoptions{') > -1 || msg.indexOf('autorespond{') > -1) {
                            if ((sender.identity === 3 || sender.identity === 4 || sender.identity === 6) && (sender.vipLevel < 2 || sender.userLevel < 12) && sender.vipLevel < 79) {
                                result = false;
                            }
                        }
                    }
                    msg = msg.replace(/\[([\d\w]+)\/([\d\w]+)\]/g, function() {
                        if (arguments[1] == 'c' && sender.userLevel < 11) {
                            result = false;
                            if (isself) {
                                WebChat.Message.chat.private.system('您的等级未达到知府，暂时不可以使用专属表情哦！');
                            }
                            return '';
                        }
                        return msg;
                    });
                }
                return result;
            },
            //判断鼠标是否在元素区域内
            isInRegion: function(cur, x, y) {
                var offset = cur.offset();
                var left = offset.left;
                var top = offset.top;
                var endTop = top + cur.outerHeight(true);
                var endLeft = left + cur.outerWidth(true);
                return x > left && x < endLeft && y > top && y < endTop;
            },
            //获取本地时间
            getTime: function() {
                var Hours = new Date().getHours();
                var Minutes = new Date().getMinutes();
                if(Hours < 10)
                    Hours = "0" + Hours;
                if(Minutes < 10)
                    Minutes = "0" + Minutes;
                return Hours + ":" + Minutes + " ";
            },
            //包装时间
            PackTime: function(time){
                return '<span class="times">'+time+'</span>';
            }
        },
        //覆盖WebChat
        _WebChat = window.WebChat,
        //覆盖WebChat
        _jw = window.WebChat;


        $.fn.extend({
            //光标位置插入
            insertAtCaret: function(val) {
                var $t = this[0];
                if(document.selection) {
                    this.focus();
                    sel = document.selection.createRange();
                    sel.text = val;
                    this.focus();
                } else
                    if($t.selectionStart || $t.selectionStart == '0') {
                        var startPos = $t.selectionStart;
                        var endPos = $t.selectionEnd;
                        var scrollTop = $t.scrollTop;
                        $t.value = $t.value.substring(0, startPos) + val + $t.value.substring(endPos, $t.value.length);
                        this.focus();
                        $t.selectionStart = startPos + val.length;
                        $t.selectionEnd = startPos + val.length;
                        $t.scrollTop = scrollTop;
                    } else {
                        this.value += val;
                        this.focus();
                    }
                return this;
            },
            //设置光标位置
            setFocus: function(index) {
                return this.each(function() {
                    try {
                        var ctrl = $(this)[0];
                        var pos = index==null?ctrl.value.length:index;
                        ctrl.focus();
                        if(ctrl.setSelectionRange) {
                            ctrl.setSelectionRange(pos, pos);
                        }
                        else if(ctrl.createTextRange) {
                            var range = ctrl.createTextRange();
                            range.collapse(true);
                            range.moveEnd('character', pos);
                            range.moveStart('character', pos);
                            range.select();
                        }
                    } catch(e) { }
                });
            }
        });
        //转换成聊天显示专用字符串（过滤html代码、合成表情）
        String.prototype.toChatViewString = function(islxb, identity, rct, emoth, sendidx) {
            var str = $.trim(this).unescape();
            var fsindex = -1;
            var sty = '';
            //过滤网址
            if(identity == null || (identity!==2 && identity!==8)) {
	            var regexp = new RegExp('((https?|ftp)\:\/\/)?([a-zA-Z0-9_~@-]+[.。．])?[a-zA-Z0-9_~@-]+[.。．](' + WebChat.Config.filter_domain + ')([\:：]\d+)?(/[a-zA-Z0-9\(\):;&\./\?#%=_~-]*)?', "gi");
                str = str.replace(regexp, function() {
//	                try{
//	                    var site = arguments[0].replace(/www.9513.com|www.9513.com/g,'');
//	                    if(site.match(regexp))
//	                    {
//                            return "已过滤网址";
//		                } else {
//		                    return arguments[0];
//	                    }
//		            }catch(e) {
	                    return "已过滤网址";
//	                }
                });
            }
            //敏感词过滤 
            if(identity == null || (identity!==2 && identity!==8)) {
                if(islxb == null || islxb) {
                    fsindex = str.indexOf("fontoptions{");
                    if(fsindex > -1) {
                        sty = str.substr(fsindex + 12);
                        str = str.substr(0, fsindex);
                    }
                    str = str.replace(new RegExp(WebChat.Config.LXB, "gi"), "**");
                    if(fsindex > -1) {
                        str += 'fontoptions{' + sty;
                    }
                }
            }
            //表情
            if((emoth == null || emoth > 0) && str.indexOf('[') > -1) {
                str = str.replace(/\[([\d\w]+)\/([\d\w]+)\]/g, function() {
                    var _s = WebChat.getEmotUrl(arguments[1], arguments[2]);
                    if(_s != arguments[0]) {
                        _s = '<img src="' + _s + '"' + (emoth == null ? ' ' : ' style="height:' + emoth + 'px"') + '/>';
                    }
                    return _s;
                });
            }
            //彩条
            if((rct == null || rct) && str.indexOf('/') > -1) {
                var temp = str;
                for(var i = 0, len = WebChat.Config.ct.length; i < len; i++) {
                    str = str.replace(new RegExp(WebChat.Config.ct[i].k, "i"), WebChat.Config.ct[i].v);
                    if(str != temp) {
                        //发彩条成功                        
                        if(sendidx == WebChat.Config.data.idx) {
                            if(WebChat.Message.quest) {
                                temp = WebChat.Message.quest.getStatus(3);
                                if(temp == null || temp == -4) {
                                    WebChat.Message.quest.DoQuest(3);
                                }
                            }

                            //刷彩条自动关注主播
                            WebChat.Comm.userControl.sendFans.auto();
                        }
                        lastgongliao = null;
                        //过滤频繁发彩条
	                    WebChat.Config.ctuserlist = WebChat.Config.ctuserlist || { };
		                var now = new Date().getTime();
	                    var time = WebChat.Config.ctuserlist[sendidx];
	                    if(time) {
		                    if(now-time<WebChat.Config.colourbarlimit) {
			                    str = '';
		                    }
	                    }
		                WebChat.Config.ctuserlist[sendidx] = now;
	                    if(WebChat.Config.cttimeid!==null) {
		                    clearTimeout(WebChat.Config.cttimeid);
	                    }
	                    WebChat.Config.cttimeid = setTimeout(function() {
		                    WebChat.Config.ctuserlist = { };
	                    }, 20000);
	                    //设置消息是否为彩条或者表情
	                    WebChat.Config.data.isRct=true;
                        break;
                    }
                }
            }
            //字体设置
            fsindex = str.indexOf("fontoptions{");
            if(fsindex > -1) {
                sty = str.substr(fsindex + 12);
                str = '<span style="' + sty + '" >' + str.substr(0, fsindex) + "</span>";
            }
            return str;
        };
        //转换成聊天发送专用字符串（过滤双引号）
        String.prototype.toChatSendString = function() {
            return escape(this.replace(new RegExp('fontoptions\{', 'gm'), 'fontoptions﹛').replace(new RegExp('autorespond\{', 'gm'), 'autorespond﹛'));
        };
        //接收FLASH传入JSON字符并转换
        String.prototype.toJsonString = function() {
            return this;
        };
        //unescape字符串
        String.prototype.unescape = function() {
            var str = unescape(this);
            if(str.indexOf('&') > -1) {
                str = str.replace(/&/g, '&amp;');
            }
            if(str.indexOf('<') > -1) {
                str = str.replace(/</g, '&lt;');
            }
            if(str.indexOf('>') > -1) {
                str = str.replace(/>/g, '&gt;');
            }
            return str;
        };

        //回到首页 
        var godefault = function() {
	        var href = '/';
	        if(window.urlQueryString) {
	            var from = urlQueryString('from',true);
		        if(from=='xl'||from === 'pptv'||from==='tuli') {
		            href += '?from=' + from;
		        }
	        }
            window.location.href = href;
        };
        //获取cookie
        var getCookie = function(c_name, isclient) {
            if(document.cookie.length > 0) {
                var c_start = document.cookie.indexOf(c_name + "=");
                if(c_start != -1) {
                    c_start = c_start + c_name.length + 1;
                    var c_end = document.cookie.indexOf(';', c_start);
                    if(isclient) {
                        var c_end2 = document.cookie.indexOf('&', c_start);
                        if(c_end == -1 || (c_end2 > -1 && c_end > c_end2)) c_end = c_end2;
                    }
                    if(c_end == -1) { c_end = document.cookie.length; }
                    return unescape(document.cookie.substring(c_start, c_end));
                }
            }
            return null;
        };
        //写入cookie
        var setCookie = function(c_name, value, expiredays) {
            var exdate = new Date();
            exdate.setDate(exdate.getDate() + expiredays);
            document.cookie = c_name + "=" + escape(value) + ((expiredays == null) ? "" : ";expires=" + exdate.toGMTString());
        };

        //错误提示
        WebChat.Config.error.msg001 = "拥有VIP的用户才能进入人满房间哦！";
        WebChat.Config.error.msg002 = "号码在其他处登录！";
        WebChat.Config.error.msg003 = "您已经被踢出或被炸出，请稍后再登录！";
        WebChat.Config.error.msg004 = "用户在号码表中不存在！";
        WebChat.Config.error.msg005 = "该房间被锁定，暂时无法访问！";
        WebChat.Config.error.msg006 = "房间不存在！";
        WebChat.Config.error.msg007 = "进入房间失败，请退出房间再重新登录！";
        WebChat.Config.error.msg008 = "该号码被冻结，请联系管理员！";
        WebChat.Config.error.msg101 = "消息发送失败，对方禁止悄悄话！";
        WebChat.Config.error.msg102 = "对方不在房间！";
        WebChat.Config.error.msg103 = "您已经被禁言！";
        WebChat.Config.error.msg201 = "<a href='" + WebChat.Config.pay_url + "' target='_blank' hidefocus='true'>余额不足！</a>";
        WebChat.Config.error.msg202 = "不能送给自己！";
        WebChat.Config.error.msg203 = "用户不存在或该用户已离开房间！";
        WebChat.Config.error.msg204 = "数量为负！";
        WebChat.Config.error.msg205 = "受赠者或者赠送者是游客！";
        WebChat.Config.error.msg206 = "送礼物请求失败！";
        WebChat.Config.error.msg300 = "无权限或该用户已离开房间！";
        WebChat.Config.error.msg301 = "对方是房主，不能禁言！";
        WebChat.Config.error.msg302 = "对方是巡管，不能禁言！";
        WebChat.Config.error.msg303 = "对方是管理员，不能禁言！";
        WebChat.Config.error.msg304 = "对方是vip用户，不能禁言！";
        WebChat.Config.error.msg305 = "对方是榜单用户，不能禁言！";
        WebChat.Config.error.msg306 = "对方已经被禁言！";
        WebChat.Config.error.msg30100 = "对方已经被禁言！";
        WebChat.Config.error.msg500 = "无权限或该用户已离开房间！";
        WebChat.Config.error.msg501 = "对方是房主！";
        WebChat.Config.error.msg502 = "对方是巡管！";
        WebChat.Config.error.msg503 = "对方是管理员！";
        WebChat.Config.error.msg504 = "对方是vip用户！";
        WebChat.Config.error.msg505 = "对方是榜单用户！";
        WebChat.Config.error.msg506 = "对方没有被禁言！";
        WebChat.Config.error.msg50100 = "对方没有被禁言！";
        WebChat.Config.error.msg400 = "无权限或该用户已离开房间！";
        WebChat.Config.error.msg401 = "对方是房主，不能踢出！";
        WebChat.Config.error.msg402 = "对方是巡管，不能踢出！";
        WebChat.Config.error.msg403 = "对方是管理员，不能踢出！";
        WebChat.Config.error.msg404 = "对方是vip用户，不能踢出！";
        WebChat.Config.error.msg405 = "对方是榜单用户，不能踢出！";
        WebChat.Config.error.msg40101 = "可踢人数达到上限！";
        WebChat.Config.error.msg601 = "对方已经是管理员！";
        WebChat.Config.error.msg602 = "管理人员已经满！";
        WebChat.Config.error.msg701 = "无权限或该用户已离开房间！";
        WebChat.Config.error.msg702 = "对方不是管理！";
        WebChat.Config.error.msg801 = "日志发送成功！";
        WebChat.Config.error.msg802 = "日志发送失败！";
        WebChat.Config.error.msg900 = "本房间已禁止公聊！";
        WebChat.Config.error.msg901 = "本房间已允许公聊！";
        WebChat.Config.error.msg1000 = "海报设置失败！";
        WebChat.Config.error.msg1001 = "海报设置成功！";
        WebChat.Config.error.msg1100 = "设置背景失败！";
        WebChat.Config.error.msg1101 = "设置背景成功！";
        WebChat.Config.error.msg1102 = "设置背景失败！";
        WebChat.Config.error.msg1103 = "上传图片超过1M！";
        WebChat.Config.error.msg11020 = "请先选择要上传的图片！";
        WebChat.Config.error.msg11021 = "正在上传图片...";
        WebChat.Config.error.msg11030 = "图片上传完成！";
        WebChat.Config.error.msg11031 = "图片上传失败！";

        return (window.WebChat = window.jw = WebChat);
    })();
})(window)
//flash
/*
 *	web聊天室js版 flash调用接口 by mjw
 */
var liveflashurl={
    clearroominfo:'/ashx/live/ClearRoomInfo.ashx',
    updateroominfo:'/ashx/live/UpdateRoomInfo.ashx',
    livestatistics:'/ashx/live/SetLiveStatistics.ashx',
    createroomurl:'/ashx/live/CreateRoom.ashx',
    advurl:'',
    fuvUrl:'/ashx/InsertTrafficAnalysis.ashx',
    recreatecounturl:'/ashx/live/SetReCreateLive.ashx'
};
var isInstall= false;
var fwebinstalled = true;
var fwebVer, fweb ,fweb2;
//插件是否安装
function isfwebinstalled() {
    return isInstall&&fwebinstalled;
}
function createOcxObj(){
    try{
        fweb=document.getElementById("ShowActiveXCtrl");
    }catch (e) {}
    if(fweb!=null){
        try { 
	        fwebVer = parseInt(fweb.getocxversion());
	        fwebinstalled=fwebVer>=jw.Config.cjversion;
        }catch (e) {
	        fwebinstalled = false;
        }
    }else{
        fwebinstalled = false;
    }    
    jw.Config.cjisnew=fwebinstalled;
}
function ocxIsConnect(){
    var isconnect=true;
    try{
        isconnect=fweb.isconnected();
    }catch(err){
       isconnect=false;
    }
    return isconnect;
}				  
function startLive(livename,id,fmsHost,micid,mxid,videoname,micname){
    mxid=mxid||0;
	videoname = videoname ? videoname.unescape() : '';
	micname = micname ? micname.unescape() : '';
    if(fweb==null)
        createOcxObj();
    if(pagedata.roomtype===jw.Config.roomtype.threemic){
        if(!isfwebinstalled()){
            //alert('建议安装直播插件来达到最佳效果！');
            //window.open('http://sr.9513.com/live/html/installCj.html');
            jw.Message.pleasecj(null,'建议安装直播插件来达到最佳效果！');
            return false;
        }
        SetActiveXLocation(mxid);
    }
    var _mxid=mxid>0?mxid:'';
    document.getElementById("asFrame"+_mxid).className="asframe1";
    var hasOcx=true;
    var cameraid=parseInt(id);
    var newVersion = true;
    try{
      var version = parseInt(fweb.getocxversion());
	}
	catch(ex){newVersion  = false;}

    try{
         //ocx 配置 begin
         //BatchUploadCtrl.CreateIt();
         var vwidth=pagedata.vWidth>0?pagedata.vWidth:320;
         var vheight=pagedata.vHeight>0?pagedata.vHeight:240;
         var vquality=pagedata.vQuality>0?pagedata.vQuality:10;
//         if(mxid>0)
//         {
//            vwidth=176;
//            vheight=144;
//         }
         micid=micid||0;
         fweb.setservparm(fmsHost,livename);
         fweb.setvideoparm(cameraid, vwidth, vheight, 10, vquality);
         fweb.setaudioparm(micid,16,2,44100);

         StartOcx(mxid);
         hasOcx=true;
         //BatchUploadCtrl.longCalc(100,200,scfDisplayProgress);
         //ocx 配置 end
        }catch(err){
        var msg="Error description: "+err.description+",\n可能引起原因有：\n1.COM组件注册失败\n  是否现在下载安装？";
        alert(msg);
        hasOcx=false;

        document.getElementById("asFrame"+_mxid).className="asframe0";
    }
    //alert("有插件与否"+hasOcx);
    return hasOcx;						   
}
function VideoSuccess() {
    alert('VideoSuccess');
}
//开启ocx
function StartOcx(mxid)
{
     fweb.startlive();
     setTimeout(function () {
            //默认开关麦
            ChangecaptureAudio(mxid>0?1:0);
     },3000);
}
//控制插件声音
function ChangecaptureAudio(type) {
    try{
         //默认开关麦
         fweb.closeaudio(type);
     }catch(e){}
}
//插件开关麦克风
function operatemic(opid) {
}
//关闭ocx
function CloseOcx(mxid){
    try{
        mxid=mxid||0;
        if(isInstall){
	        fweb.stoplive();
	    }
        asShowVideo(mxid);
     }catch(err){
	    var msg="Error description: "+err.description+",\n可能引起原因有：\n1.COM组件注册失败\n  是否现在下载安装？";
	    alert(msg);
    }
}
function asShowVideo(mxid){
    document.getElementById("asFrame"+(pagedata.roomtype===jw.Config.roomtype.threemic&&mxid>0?mxid:"")).className="asframe0";
}
//获取视频设置
function getVideoOptions() {
    var vwidth=pagedata.vWidth>0?pagedata.vWidth:320;
    var vheight=pagedata.vHeight>0?pagedata.vHeight:240;
    var vquality=pagedata.vQuality>0?pagedata.vQuality:10;
    return '{"vWidth":'+vwidth+',"vHeight":'+vheight+',"vQuality":85,"fps":10,"bandWidth":20480,"keyframeInterval":8}';
}
//开始直播
function asStartLive(liveid,host) {
    jw.Doms.videoComm.asStartLive(host,liveid);
    startLiveCallBack();
     //直播状态
     $("#zb_live_state").html('<img class="Zb_ic" src="http://sr.9513.com/live/v2.0/images/pixel.gif""><em>正在直播/'+pagedata.anchorlocation+'</em>');
}
//开始播放 4303
function asPlayLive(liveid,host,player,winid) {

    try{
        if(window.asPlayLiveM){
            asPlayLiveM(liveid,host,player,winid);
            
        }else{
            jw.Doms.videoComm.asplaymovie(liveid,host);
            showstopLiveTips(1);
        }
    }catch(e){
        setTimeout(function () {
            asPlayLive(liveid,host,player,winid);
        },500);
    } 
    //直播状态
    $("#zb_live_state").html('<img class="Zb_ic" src="http://sr.9513.com/live/v2.0/images/pixel.gif""><em>正在直播/'+pagedata.anchorlocation+'</em>');
    jw.Doms.Other.alert.dialog('close');
    jw.Config.data.isPlay=1;
    return true;
}
//正在直播
function fmsStartLive() {
  //直播状态
     $("#zb_live_state").html('<img class="Zb_ic" src="http://sr.9513.com/live/v2.0/images/pixel.gif""><em>正在直播/'+pagedata.anchorlocation+'</em>');
    jw.Doms.chatComm.fmsStartLive();
    setAnchorButtons(1);
}
var videoready=false;
//视频准备好了
function asVideoReady() {
    videoready=true;
    //添加FUV数据
    try
    {
        if(pagedata.fromsource==1)
        {
            var str='';
            var _url=window.location.href;
            if(_url.indexOf("?") != -1)
            {
		         var str_p = _url.split("?")[1];
	 	         if(str_p.indexOf("=")!=-1){
		  	        str=str_p.split("=")[1];
		         }
	             $.ajax({
                   type:"GET",
                   url:liveflashurl.fuvUrl+"?p="+str,
                   cache:false,
                   dataType:"json",
                   success:function(json){
                       
                   },
                   error:function(){
                   }    
               });
	        }
        }
    }catch(e){}
}
//停止浏览直播
function closeLive(mxid) {
    try
    {
        if(pagedata.roomtype===jw.Config.roomtype.threemic){
            _getVideoComm(mxid).closeLive();
        }else if(window.closeLiveM){
            closeLiveM(mxid);
        }else if(!isAnchor()){
            jw.Doms.videoComm.closeLive();        
        }
    }catch(e){}
}
//检测自己是否在直播
function checkFlashContectFms() {
    var comm=null;
    if(pagedata.roomtype===jw.Config.roomtype.threemic)
        comm=_getVideoComm(jw.Config.data.mxid);
    else
        comm=jw.Doms.videoComm;
    if(comm){
        try{
            return comm.checkFlashContectFms();
        }catch(e){}
    }
    return false;
}
//获取创建直播地址
function getCreateRoomUrl() {
    return getHttpHost()+liveflashurl.createroomurl;
}

//取得聊天服务端地址
var ip_ISP = "";
function getchatserver()
{    
    var server = pagedata.chat;
    if (ip_ISP != "") {
        var chatList = pagedata.chat.split(";");
        if (ip_ISP.indexOf("电信<br>") < 0 || chatList.length < 2) {
            server = chatList[0] + ";" + chatList[0];
        } else {
            server = chatList[1] + ";" + chatList[1];
        }
    }
    return pagedata.chat;
}
//获取客户端IP信息以及网络运营商等信息

function IPCallBack_Go(json) {
    $.ajax({
        url: 'http://whois.pconline.com.cn/ipJson.jsp',
        dataType: "jsonp",
        jsonp: "IPCallBack",
        success: function (data) {
            ip_ISP = json.addr; //运营商与地址
        }
    });
}

//取得设置海报图片服务器
function getLivePicServ()
{
    return jw.Config.haibaourl;
}
//取得时间戳
function gettm()
{      
    return pagedata.tm;
}
//取得房间号
function getroomidx()
{    
    return pagedata.vroomidx||pagedata.roomidx;
}
//获取pagedata
function getpagedata() {
	return pagedata;
}
//获取房间靓号
function getcroomidx() {
	return pagedata.vroomidx||pagedata.croomidx||pagedata.roomidx;
}
//取得当前主播的靓号
function getanchorcno()
{    
    return getcroomidx();
}
//获取视频广告地址
function getAdvUrl() {
    return null;//liveflashurl.advurl;
}
//获取公聊广告参数
function getAdOptions() {
    var adhide=getCookie('adhide');
    if(adhide==null)
        adhide=1;
    else
        adhide++;
    setCookie('adhide',adhide,jw.Config.data.vipLevel>0?365:1);
    var _left=0;
    if(!isAnchor())
    {
        _left=jw.Doms.Right.talk_tabs.offset().left;
    }
    return {url:liveflashurl.advurl,width:370,height:315,left:_left,top:70,identity:jw.Config.data.identity};
}
//公聊广告不再提示
function setAdhide() {
    setCookie('adhide',4,jw.Config.data.vipLevel>0?365:1);
}
//取得用户信息,以字符串返回
function getCookieStr() {
    var str="";
    var _isanchor=isAnchor();
    if(pagedata.roomtype===jw.Config.roomtype.multimic){
        _isanchor=_isanchor&&!isRoomowner();
    }
    if(_isanchor){
        //非IE禁止直播
        if((window.ActiveXObject===undefined)&&((jw.Config.IEUn&&(!jw.Config.IEUn[pagedata.usersidx])&&pagedata.isofficial)||pagedata.isgame)){
           str="请用IE浏览器进行直播。";
        }
//        //9see禁止直播
//        else if(pagedata.fromsource!==2)
//        { 
//            str="请至我看美女直播间http://show.weibo.com进行直播。";
//        }
        if(str.length>0){
         
            alert(str);
            pagedata.usersidx=0;
	        gourl('/');
            return;
        }
    }
    if(pagedata.usersidx>0&&(pagedata.chaturl==null))
    {
        str="idx="+pagedata.usersidx+"&sidx="+pagedata.usersidx+"&level="+(pagedata.level||0)+"&token="+pagedata.token+"&";
    }
    var ishide=getCookie("user_ishide");
    if(ishide==null||_isanchor)
    {
        ishide='0';
    }
    str+="ishide="+ishide+"&videoid="+(pagedata.vodid>0?pagedata.vodid:"")+"&vodurl="+pagedata.vodurl;
    str+="&fromsource="+(pagedata.fromsource==null?2:pagedata.fromsource)+"&chatflag="+pagedata.chatflag;
    var _geturl=function (_url) {
        var _i=_url.indexOf(pagedata.roomidx);
        if(_i>-1)
        {
            var d=_url.substr(_i+pagedata.roomidx.length,8);
            _url='http://r1.9see.com/'+d+'/'+_url;
        }
        return _url;
    };
    str+='&isreplay='+(pagedata.isreplay||'0')+'&videourl='+(pagedata.videourl?'http://60.191.222.172/media/'+pagedata.videourl:'')+'&chaturl='+(pagedata.chaturl?_geturl(pagedata.chaturl):'')+'&vrootid='+pagedata.vrootid;
    return str+'&';
}
//显示跑道礼物与礼物信息窗
function pdShow(senderName,senderIdx,acceptName,acceptIdx,giftId,num,time,roomidx){
    if((giftId===1004&&jw.Config.hjdidx&&jw.Config.hjdidx[senderIdx]!=null)||giftId===1019)//黄金袋、财神不飞
    {
        return;
    }
    var gift=jw.Config.gift.data[giftId];
     
    var lb_price= gift.price*num;
    if (lb_price >= 50000)
    {
        var g_href='';
        if(getcroomidx()!=roomidx){
            g_href = ' href="/' + acceptIdx + '" target="_blank" '; //原始
            //g_href = ' href="javascript:void(0);" '; //朱海波 2015-04-21
        }
        var _lbmsg = '<div class="times fl">' + (time == null ? "00:00" : time) + '</div><div class="text fl"><a ' + g_href + '><strong>' + senderName.unescape() + '</strong></a>&nbsp;送给&nbsp;<a ' + g_href + '><strong>' + acceptName.unescape() + '</strong></a>&nbsp;' + num + gift.n + gift.name + '</a>&nbsp;';
        _lbmsg += '<img src="http://sr.9513.com/live/images/giftjs/50-50_png/' + giftId + '.png?d=201201203"  width="16px" height="16px">&nbsp;</div>';
          jw.Message.chat.Addlb.append(_lbmsg,true);
    }
    
    var url=jw.Config.gift.giftswfurl+giftId+'.gif?d=20120412'+(gift.version==null?'':'&v='+gift.version);
	var from = window.urlQueryString?urlQueryString('from',true):'';
	if(from==='pptv'){
		from='xl';
	}
	//console.log(senderName, senderIdx, acceptName, acceptIdx, gift.name, giftId, num, time, url, gift.n, from)
    swfobject.getObjectById("pd_as").pdShow(senderName,senderIdx,acceptName,acceptIdx,gift.name,giftId,num,time,url,gift.n,from);
    
    //烟花提示
    if(roomidx&&giftId===701)
    {    
        senderName=senderName.unescape();
	    var isthisroom = roomidx === getcroomidx();
        if(!isthisroom)
        {
            url = '<span style="color:#ff0000"><a href="#" onclick="return false;">' + senderName + '</a>为' + acceptIdx + '房间所有用户绽放了一束烟花，' + acceptIdx + '房间顿时星光四射！<a href="/' + acceptIdx + '" target="_blank" hidefocus="true">>>去看看</a></span>';
            
            jw.Message.chat.public.system(url,time);
        }
        if(isthisroom&&jw.Config.data.identity===7)
        {
            if(pagedata.fromsource===2)
                gift='<a href="http://weibo.com/signup/signup.php?entry=vshow&r='+window.location.href+'" target="_blank" hidefocus="true">注册</a>';
            else
                gift='<a hidefocus="true" href="#" onclick="jw.Message.pleasereg();return false;">注册</a>';
            url='很遗憾，由于您未登录不能得到'+senderName+'点燃烟花赠送的星币，赶快'+gift+'或<a href="#" onclick="jw.Message.pleaselogin();return false;" hidefocus="true">登录</a>吧，获得星币，与主播进行交流！';
            jw.Message.chat.private.system(url,time);
        }
    }
}

//设置房间
function roomSet(){
    //jw.Message.roomset();
}
//房间公告
function roomTalk(){
    jw.Message.roomaffice();
}
//转移观众
function moveViews(){
    jw.Message.moveuser();
}
//自动播放录象
function playMovie(){
    jw.Comm.playMovie.send();
}
//开关公聊
function stopTalk(){
    jw.Message.confirm("您确定要"+(pagedata.pubchat=="1"?"关闭":"开启")+"公聊吗？",function(){
         jw.Comm.adminControl.sendisForbid.data.state=(pagedata.pubchat == "1" ? 0: 1);
         jw.Comm.adminControl.sendisForbid.send(jw.Comm.adminControl.sendisForbid.data);
    },null,"开关公聊");
}
//隐藏礼物展示
function hideshowgiftconfirm() {
    jw.Events.showGift.screenShow.hide();
}
//获取展示礼物FLASH宽度
function getshowgiftwidth() {
    var _w=$(window).width();
    if(jw.Config.data.identity===(pagedata.roomtype===jw.Config.roomtype.multimic?11:1)||jw.Config.data.mxid>-1)
    {
        _w=_w-jw.Doms.Left.left.width()-(_w-jw.Doms.all.width())/2;
    }
    return _w;
}
//获取小喇叭宽度
function gethornwidth() {
    return $(window).width();
}
//是否主播
function isAnchor() {
    if(pagedata.roomtype===jw.Config.roomtype.multimic)
    {
        return window.getAnchorInfo?(pagedata.usersidx!==pagedata.roomidx&&!!getAnchorInfo(pagedata.usersidx)):false;
    }
    else
        return pagedata.usersidx===pagedata.roomidx;
}
//是否室主
function isRoomowner() {
    return pagedata.usersidx===pagedata.roomidx;
}
//是否是游戏房间
function isGameroom() {
    return pagedata.isofficial&&pagedata.isgame==1;
}
//设置海报
function setImage()
{
    jw.Message.setImage();
}
//关闭海报设置
function closeSetHaibao() {
    jw.Doms.Other.dialog_haibao.hide();
}
//设置海报结果
function setHaibaoSuccess(result) {
    jw.Message.error(10,result);
    jw.Doms.Other.dialog_haibao.hide();
    
    ClearRoomInfo();
}
//清除memcached中的roominfo
var clearroominfo=null;
function ClearRoomInfo() {
    if(isRoomowner())
    {
        //删除Memcached
        $.ajax({
            type:'get',
            url:liveflashurl.clearroominfo+'?roomidx='+getcroomidx(),
            cache:false,
            timeout:30000
        });
    }
}
//更新memcached中的roominfo
var updateroominfo=null;
function UpdateRoomInfo(columnName,val) {
    if(isRoomowner())
    {
        columnName=escape(columnName);
        val=escape(val);
        //更新Memcached
        $.ajax({
            type:'get',
            url:liveflashurl.updateroominfo+'?roomidx='+getcroomidx()+'&columnName='+columnName+'&val='+val,
            cache:false,
            timeout:30000
        });
    }
}
//设置房间背景
function setBgimage()
{
    jw.Message.setBgPic();
}
//设置房间背景结果
function setBgPicInfo(result) {
    jw.Message.error(11,result);
}
//设置房间背景关闭
function setBgPicClose() {
    jw.Doms.Other.dialog_bgpic.hide();
}
//设置房间背景
function setBackGround_new(url) {
    jw.Doms.Other.dialog_bgpic.hide();
    document.body.style.background = "url('" +url+ "') 0 0 repeat #ffffff fixed";
    pagedata.bgimg=url;
    
    UpdateRoomInfo('bgimage',url);
}
function getBgImageSetHost()
{
    return jw.Config.bgimagesethost;
}
function getXmlUrl(){
   return getXML();
}
function getGiftUrl(){
   return jw.Config.gift.giftswfurl;
}

function getHttpHost()
{
     var vhost = "http://"+location.host;
     return vhost;
}

function getPayUrl()
{
     var vhost = "http://"+location.host;
     return vhost+jw.Config.pay_url;
}
//停止直播按钮事件
function asStopLive(){
    window.asStopLiveM?asStopLiveM():SLconfirm();
}
function SLconfirm(){
    jw.Message.confirm("您确定要停止直播吗？",function(){
        dostopLive();
    },null,"停止直播");
}
//停止直播
function dostopLive() {
    jw.Comm.adminControl.sendstopLiveInfo.send(jw.Comm.adminControl.sendstopLiveInfo.data);
    setAnchorButtons();
    //直播状态
    $("#zb_live_state").html('<img class="Zb_ic noZb_ic" src="http://sr.9513.com/live/v2.0/images/pixel.gif""><em>已停播/'+pagedata.anchorlocation+'</em>');
    //停播后移除赞信息展示
    $(".how_zan").hide();
    jw.Config.data.isPlay=0;
}
//跳转
function gourl(url,isopen) {
	if (window.urlQueryString) {
		var from = urlQueryString('from', 1);
		if (from === 'xl'|| from==='tuli') {
			if (!~url.indexOf('?')) {
				url += '?from=' + from;
			} else {
				url += '&from=' + from;
			}
			isopen = false;
		}
	}
	if (isopen) {
		window.open(url);
	} else {
		window.location.href = url;
	}
}

//返回礼物XML地址给FLASH
function getXML() {
    return jw.Config.gift.flashurl;
}
//显示创建直播室窗口
function showCreateLive() {
    jw.Message.createlive();
}
//创建失败
function showCreateFalse() {
    jw.Comm.adminControl.reSetLive.send();
    setAnchorButtons();
}
//隐藏显示主播按钮
function setAnchorButtons(isliveing) {
    if(isliveing)
    {
        jw.Doms.Other.btnstoplive.show();
        if(pagedata.roomtype!==jw.Config.roomtype.multimic){
            jw.Doms.Other.btntemplate&&jw.Doms.Other.btntemplate.hide();
        }
    }
    else
    {
        jw.Doms.Other.btnstoplive.hide();
        if(pagedata.roomtype!==jw.Config.roomtype.multimic){
            jw.Doms.Other.btnviewpwd.hide();
            jw.Doms.Other.btntemplate&&jw.Doms.Other.btntemplate.show();
        }
        jw.Doms.Other.btnswap&&jw.Doms.Other.btnswap.hide();
    }
}
//欢迎
var welcome=function () {
    var msg='';
    if(pagedata.chaturl)
    {
        msg='<a href="/'+getcroomidx()+'" target="_blank">当前为录像模式，如需观看直播，请去直播间！</a>';
        jw.Message.chat.private.system(msg);
    }
    else
    {
        msg = '<div class="jiaoyou_button" style="text-align:center;height:35px;width:95%;background-color: #FF9933;color:#FFFFFF;font-size: 14px;line-height: 32px;">主播给你发悄悄话了，请<a href="#" hidefocus=\"true\" href="#" onclick="jw.Message.' + (from === 'xl' || from==='tuli' ? 'pleaselogin()' : 'pleasereg()') + ';return false;">注册登录</a>查看</div>';
		jw.Doms.Right.private.find("li[id='CC630706-5681-4C97-9F2E-B11F5B9469CE']").after(msg);
    }
};
//登录成功获取房间信息
function  showRoomInfo(json) {
    //新手引导
    if(pagedata.usersidx==0&&pagedata.fromsource!==2)
        initHelp();
    //连接服务器成功判断粉丝关系
    if(pagedata.roomtype!==jw.Config.roomtype.multimic)
        window.loadWbRel&&loadWbRel();
    
    var uidx=json.nowPlayer.idx;
    jw.Config.data.idx=uidx;
    jw.Config.data.cno=json.nowPlayer.cno;
    jw.Config.data.identity=json.nowPlayer.identity;
    jw.Config.data.userLevel=json.nowPlayer.userLevel;
    jw.Config.data.vipLevel=json.nowPlayer.vipLevel;
    jw.Config.data.userName=json.nowPlayer.userName.unescape();
    jw.Config.data.anchorLevel=json.anchorLevel;
    jw.Comm.sendChat.inRoomTime=(new Date()).getTime();
    jw.Config.data.isGreenCard=json.nowPlayer.isGreenCard;
    //故障提交按钮
    if(pagedata.isofficial&&(json.nowPlayer.identity==1||json.nowPlayer.identity==2||json.nowPlayer.identity==10)&&$('#btngztj').length==0) {
	    var a = '<a id="btngztj" href="http://bug.9513.com/bugmanage/agentbug.aspx?reguserid=' + pagedata.usersidx + '&siteid=75&roomid=' + (pagedata.vroomidx || pagedata.roomidx) + '&ipstr=' + getchatserver() + '" target="_blank">';
	    if (pagedata.fromsource === 2) {
		    $('#room_topbar [id!="ysliadd"]:first').before('<li>' + a + '<img src="http://sr.9513.com/live/images/gztj.png" /></a></li>');
	    } else {
		    $('#loginin .inner').append(a + '故障提交</a>');
	    }
    }
	//隐身按钮控制
    if(((json.nowPlayer.vipLevel>1&&json.nowPlayer.vipLevel<80)||json.nowPlayer.identity==2||json.nowPlayer.identity==10)&&!isAnchor()){
        //var ysliadd=$("#ysliadd");
         if($("#btnsethide").length<=0){
            //return;
        
          $("#nickname_icons").prev().before('<a id="btnsethide" style="color:#ff0000" href="#" onclick="setHide();return false;" ishide="'+json.nowPlayer.ishide+'"  hidefocus="true">'+(json.nowPlayer.ishide?'当前隐身':'当前显身')+'</a>');
        }
        //if(pagedata.fromsource!==2)
        //ysliadd.after('<li class="line">|</li>');
    }
    //公告
    if(typeof(json.roomNotice) != "undefined")
    {
        if(pagedata.chaturl)
            jw.Message.chat.private.system('<a href="/'+getcroomidx()+'" target="_blank">当前为录像模式，如需观看直播，请去直播间！</a>');   
        else
        {
            var _url=null;
            var msg=json.roomNotice.unescape().replace(/url\:\S+/g,function () {
                    var arg=arguments[0];
                    if(arg)
                    {
                        _url=arg.substring(4);
                        return '';
                    }
                    else
                        return '';
            }).toChatViewString(false);
            jw.Message.chat.private.system(msg,null,0,_url);
        }
    }
    //欢迎信息
    if (jw.Config.data.identity===7&&pagedata.chaturl==null) {
        if(jw.Doms.Right.private.find(".jiaoyou_button").length==0)
        {
           welcome();
       }
    }
    
    //设置是否有用户权限
    set_usercontrol(json.nowPlayer);
    
    //超管拥有查询IP权限
    if(json.nowPlayer.identity!=2)
    {
        jw.Doms.Other.contextmenu.find('#cxipdz').parents("li").remove();
    }
    
    //jw.Message.chat.public.clear();
    
    //新手发言提示
    if(pagedata.usersidx>0&&!isAnchor()&&pagedata.fromsource==1){
        newUserTips(jw.Config.data.userLevel,0);
        UserInfoReadyCallBack();
    }
    if(pagedata.roomtype===jw.Config.roomtype.single){
        if(json.flag.toString()=="0"){
            $("#zb_live_state").html('<img class="Zb_ic noZb_ic" src="http://sr.9513.com/live/v2.0/images/pixel.gif""><em>已停播/'+pagedata.anchorlocation+'</em>');
        }else{
            $("#zb_live_state").html('<img class="Zb_ic" src="http://sr.9513.com/live/v2.0/images/pixel.gif""><em>正在直播/'+pagedata.anchorlocation+'</em>');
        }
        //0无直播，1公开直播，2付费直播、3私密直播 
        switch(json.flag.toString())
        {
            case "0":
                if(isAnchor()){
                    return;
                }
                jw.Config.cjisnew=true;            
                if(pagedata.vodid>0){
                    try
                    {
                        jw.Doms.videoComm.asplayRecord();
                    }catch(e){}
                }else if(pagedata.roomtype===jw.Config.roomtype.single){
                    showstopLive();
                }
                
            break;
            case "2":    
                //非管理、主播需要判断当前房间是否收费
                if(isAnchor()||json.nowPlayer.identity<4||json.nowPlayer.identity==10){
                    return;
                }
                if (jw.Config.data.identity===7)
                    jw.Message.pleaselogin("游客不能进入付费房间");
                else
                    jw.Message.pleasepay(json.money);
            break;
            case "3":
                //非管理、主播需要判断当前房间是否加密
                if(isAnchor()||json.nowPlayer.identity<4||json.nowPlayer.identity==10){
                    return;
                }
                jw.Message.inputpassword();
            break;
        }
        
    }
}
//设置是否有用户权限
function set_usercontrol(player) {
    var _id=player.identity;
    var _v=player.vipLevel;
    var _u=player.userLevel;
    //主播、管理、超管、巡管、副室主、黄P、紫P、黑P、财主
    if(_id==1||_id==11||_id==2||_id==3||_id==9||_id==10||(_v>0&&_v<80)||_u>99)
        jw.Config.usercontrol=1;
    else
        jw.Config.usercontrol=0;
    jw.Config.data.identity=_id;
    
    if(window.set_usercontrol3){
        set_usercontrol3();
    }
}
//显示挂机人数
function showguaNum(num){
    jw.Config.onlineviewer+=num;
    jw.Doms.Right.user_tab_viewer.html(jw.Config.onlineviewer);
    jw.Doms.Right.user_tab_viewer2.html(jw.Config.onlineviewer);
}
//用户进入
function showAddPlayerlist(json) {
    jw.Doms.Right.user_list_list.find("#user_loading,#nextpage").remove();
    //console.log(json);
    //添加入用户列表    
    jw.Events.userList.add(json);
    playList[json.player.idx] = json.player;//讲用户存入用户哈希表
    //json.opid==1020 新进用户，否则原有用户
    if(json.opid!=1020)
    {
       //更新在线人数
        updateOnlineNumber&&updateOnlineNumber(1,json.player.idx,(json.player.identity===1||json.player.identity===3||json.player.identity===9||json.player.identity===11));
    }
    
    //判断是否有更多用户没有显示
	switch (pagedata.roomversion) {
	    case '3.1.1':
			json.ismore = jw.Config.data.user_jsonList.ismore;
			break;
		default:
			break;
	}
	if(typeof(json.ismore)!="undefined"&&json.ismore)
    {   
	    jw.Doms.Right.user_list_list.append('<ul ><li id="nextpage" onclick="jw.Events.userList.getMoreList(this)" pageindex="' + (json.pageindex ? json.pageindex : 0) + '"><img src="http://sr.9513.com/live/v2.0/images/nextpage.png" /></li></ul>');
    }
}
//清空列表
function clearPlayerlist() {
    jw.Doms.Right.user_list.find("ul").empty();
}
//用户列表加载
function showAddPlayerlists(json) {
    jw.Doms.Right.user_list_list.find("#user_loading,#nextpage").remove();
    
    //添加入用户列表    
    jw.Events.userList.addList(json.user);
        
    if(typeof(json.ismore)!="undefined"&&json.ismore)
    {   
        jw.Doms.Right.user_list_list.append('<ul id="nextpage" onclick="jw.Events.userList.getMoreList(this)" pageindex="'+(json.pageindex?json.pageindex:0)+'"><li><img src="http://sr.9513.com/live/v2.0/images/nextpage.png" /></li></ul>');
    }
}
//用户退出
function showPlayerExit(json){
    //普通用户exPlayer..游客exitPlayer
    json.exPlayer=json.player||json.exPlayer||json.exitPlayer;
    
    ////更新在线人数
    updateOnlineNumber&&updateOnlineNumber(0,json.exPlayer.idx);
    
    //用户列表中删除用户
    //jw.Events.userList.remove(jw.Doms.Right.user_list.find("div[id!='listmic'] ul[idx='" + json.exPlayer.idx + "']"));
    jw.Events.userList.remove(jw.Doms.Right.user_list.find("ul[idx='" + json.exPlayer.idx + "']"));
    //挂机不提示离开
    if(json.isg) {
	    return;
    }
    //用户退出提示
    jw.Events.userList.showPlayerExitTip(json);
}
//显示在线人数
function showOnlineNumber(viewer,manager,micqueue) {
    viewer=(viewer<0?0:viewer);
    jw.Config.onlineviewer=viewer;
    jw.Doms.Right.user_tab_viewer.html(viewer);
    jw.Doms.Right.user_tab_viewer2.html(viewer);
    if(manager!=null){
        manager=(manager<0?0:manager);
        jw.Config.onlineadmin=manager;
        jw.Doms.Right.user_tab_admin.html(manager);
    }
    if(viewer==0)
        micqueue=0;
    if(micqueue!=null&&window.updateMicQueueCont)
    {
        updateMicQueueCont(micqueue,true);
    }
}
//显示搜索用户结果
function showSearchPlayerlistInfo(json) {
    jw.Events.userList.showSearchResult(json);
}
//登录失败
function showLoginResult (result) {
  jw.Message.error(0,result);
}
//礼物列表
function ShowGiftList(json) {
       
    jw.Events.giftList.add(json);
}
//显示公聊
var lastgongliao='';
function showMsg(json,islocal) {
    if(!islocal)
    {
        if(json.sendPlayer.idx==jw.Config.data.idx||(!jw.getMessagePower(json.Msg,json.sendPlayer)))
        return;
    }
    //默认聊天信息非表情或彩条
    jw.Config.data.isRct=false;
    var msg =json.Msg.toChatViewString(true,json.sendPlayer.identity,true,null,json.sendPlayer.idx);
	if(msg.length===0) return;
    
     if(json.sendPlayer.idx==10000){
        if(pagedata.fromsource===1){
            var str = msg.split('|');
		    var tong = {300:{id:1,num:1},15000:{id:2,num:50},12000:{id:112,num:2},1500:{id:1,num:5},600000:{id:1001,num:1}};
	        var yin = {300:{id:1,num:1},9000:{id:4,num:5},30000:{id:3,num:100},3000:{id:21,num:5},6000:{id:2,num:20},1200000:{id:1020,num:1}};
	        var jin = {15000:{id:3,num:50},5400:{id:4,num:3},1500:{id:1,num:5},600000:{id:1001,num:1},1800000:{id:1006,num:1}};
		   
		    var userTxt='<a hidefocus="true" onclick="WebChat.Events.clickUser(this);return false;" href="#" class="user" viplevel="0" userlevel="0" identity="6" idx="'+str[4]+'">'+json.sendPlayer.userName.unescape()+'</a>';
            if(str[0]=="6") {
			        var beansCount=parseInt(str[3]);
		            var sendSmall=function(money){
		                    var  gift = jw.Config.gift.data[21];
			                var msgstr = '恭喜'+userTxt+'玩'+str[1]+'，获得'+(money/100)+gift.n+gift.name;
                            if(money>=50000){
			                     msgstr+='<a  href="/webgame" target="_blank"> >>我也要玩</a>';
			                }
                            var giftimg = '<img src="'+jw.Config.gift.bigurl + '21.gif?d=20120412">';
                            msgstr+=giftimg;
                            jw.Message.chat.public.system(msgstr);
		            };
		            var sendBig=function(money){
		                 var gift = jw.Config.gift.data[1001];
			             var msgstr = '恭喜'+userTxt+'玩'+str[1]+'，获得'+(money/100000)+gift.n+gift.name;
			             msgstr+='<a  href="/webgame" target="_blank"> >>我也要玩</a><img src="'+jw.Config.gift.bigurl + '1001.gif?d=201301141346">';
			             jw.Message.chat.public.system(msgstr);
		            };
			        if(beansCount<100000){
			            sendSmall(beansCount);
			        }
			        else
			        {
			             if(beansCount%100000==0)
			             {
			                sendBig(beansCount);
			             }
			             else
			             {
			                var num=parseInt(beansCount%100000);
			                sendSmall(num);
			                sendBig(beansCount-num);
			             }
			       }
		     } 
		     else if(str[0]=="14")
		     {   
		        //游戏豆计数
		        if(str[4]==jw.Config.data.idx.toString()){
		            if(jw.Config.data.PlaneMoney){
		                jw.Config.data.PlaneMoney=jw.Config.data.PlaneMoney+parseInt(str[3]);
		            }
		            else
		            {
		                jw.Config.data.PlaneMoney=parseInt(str[3]);
		            }
		        }
		         var msgstr='';
		         var strPlane;
		         var  hammerType=str[2];
		         switch(hammerType)
		         {
		            case "1":
		                  strPlane=tong[str[3]];
		            break;
		            case "2":
		                  strPlane=yin[str[3]];
		            break;
		            case "3":
		                  strPlane=jin[str[3]];
		            break;
		         }
		         if(strPlane&&strPlane.id){
		              var gift = jw.Config.gift.data[strPlane.id];
			          msgstr = '恭喜'+userTxt+'玩'+str[1]+'获得'+strPlane.num+gift.n+gift.name;
			          var img = '<img src="'+jw.Config.gift.bigurl + strPlane.id + '.gif?d=201301141346">';
			          var img_s= '<img width="16px" height="16px" src="'+jw.Config.gift.bigurl + strPlane.id + '.gif?d=201301141346">';
		              if(parseInt(str[3])>=100000){
		                  jw.Message.chat.Addlb.system(msgstr+img_s);
			              msgstr+='<a href="#" onclick="HitPlane(0); return false;"> >>我也要玩</a>';
			          }     
			          msgstr += img;
		              jw.Message.chat.public.system(msgstr);
		        }
		   }
        }
        return;
    }
    //获取汉字长度
    var c_length=json.Msg.unescape().getChineseCharLength();
    msg=jw.getChatPic(json.sendPlayer,false)+'说：'+msg;
    
    //判断是否在直播，直播添加赞按钮(只在ok&9see,我看美女直播间不添加)
    var btnStr=AddPraiseBotton(json.sendPlayer.idx,json.sendPlayer.userName.unescape(),c_length,jw.Config.data.isRct,json.sendPlayer.userLevel,json.sendPlayer.isGreenCard,$.trim(json.Msg).unescape());
    msg=msg+btnStr;
    if(msg==lastgongliao)
    {
        if(json.sendPlayer.idx==pagedata.usersidx)
        {
            jw.Message.chat.private.system("禁止重复发言！");
        }
        return;
    }
    lastgongliao=msg;
    msg = WebChat.PackTime(json.time) + msg;
    jw.Message.chat.public.append(msg);
    
    if(json.sendPlayer.idx==pagedata.usersidx)
    {
        if(stid!=null)
        {
            clearTimeout(stid);
        }
        lastqiaoqiaohua='';
        //同步到微博
        SyncInfor(json.Msg);
    }
}
//公聊失败
function showFalseChatAll(json) {
    showChatFalse(3);
}

//显示私聊信息
var lastsiliao='';
function showChatToOne(json,islocal) {
    if(!islocal)
    {
        if(json.sendPlayer.idx==jw.Config.data.idx||(!jw.getMessagePower(json.sedInfo,json.sendPlayer)))
        return;
    }
    //默认聊天信息非表情或彩条
    jw.Config.data.isRct=false;
    var msg=json.sedInfo.toChatViewString(true,json.sendPlayer.identity);
    
    //获取汉字长度
    var c_length=json.sedInfo.unescape().getChineseCharLength();
    
    var str='';
    var sendname=json.sendPlayer.userName.unescape();
    
    str=jw.getChatPic(json.sendPlayer,true)+'对'+jw.getChatPic(json.acceptPlayer,true)+'说：';
    str+=msg;
    if(lastsiliao==str)
    {
        if(json.sendPlayer.idx==pagedata.usersidx)
        {
            jw.Message.chat.private.system("禁止重复发言！");
        }
        return;
    }
    lastsiliao=str;
    str=WebChat.PackTime(json.time)+str;
    
    var isautorespond=str.indexOf('autorespond{')>-1;
    if(isautorespond)
    {
        str=str.replace('autorespond{','');
    }
    
    //判断是否为主播，是主播就添加赞按钮(只在ok&9see,我看美女直播间不添加)
    var btnStr=AddPraiseBotton(json.sendPlayer.idx,json.sendPlayer.userName.unescape(),c_length,jw.Config.data.isRct,json.sendPlayer.userLevel,json.sendPlayer.isGreenCard,$.trim(json.sedInfo).unescape());
    str=str+btnStr;
    
    if(json.acceptPlayer.idx==pagedata.usersidx||json.sendPlayer.idx==pagedata.usersidx)
    {
        if(json.acceptPlayer.idx==pagedata.usersidx)
        {
            //回复任务
            if(!isautorespond)
            {
                //自动回复
                autorespond(json.sendPlayer.idx,sendname);
            }
            
            //代理提示消息
            if(json.acceptPlayer.identity==8){
                if(newMessageRemind.show)
                {
                    newMessageRemind.show();
                }
            }
        }
        else
        {
            if(stid!=null)
            {
                clearTimeout(stid);
            }
            lastqiaoqiaohua='';
            //同步到微博
            SyncInfor(json.sedInfo);
        }
        jw.Message.chat.private.append(str);
    }
    else
    {
        jw.Message.chat.public.append(str);
    }
     
}
//私聊失败
function showChatFalse(result) {
  if(result==3)
  {
    jw.Message.alert("您已经被禁言！");
  }
  jw.Message.error(1,result);
}
//显示悄悄话
var lastqiaoqiaohua='';
function showChatQiao(json,islocal) {
    if(!islocal)
    {
        if(json.sendPlayer.idx==jw.Config.data.idx||(!jw.getMessagePower(json.sedInfo,json.sendPlayer,true)))
        return;
    }
    var msg=json.sedInfo.toChatViewString(true,json.sendPlayer.identity);
    
    var sendname=json.sendPlayer.userName.unescape();
    str=jw.getChatPic(json.sendPlayer,true)+'对'+jw.getChatPic(json.acceptPlayer,true)+'悄悄的说：'+msg;
    
    if(lastqiaoqiaohua==str)
    {
        if(json.sendPlayer.idx==pagedata.usersidx)
        {
            jw.Message.chat.private.system("禁止重复发言！");
        }
        return;
    }
    lastqiaoqiaohua=str;
    str=json.time+str;
    
    var isautorespond=str.indexOf('autorespond{')>-1;
    if(isautorespond)
    {
        str=str.replace('autorespond{','');
    }
    jw.Message.chat.private.append(str);
    //自动回复
    if(json.acceptPlayer.idx==pagedata.usersidx){
        if(!isautorespond)
        {
            autorespond(json.sendPlayer.idx,sendname);
        }
    }
    else
    {
        if(stid!=null)
        {
            clearTimeout(stid);
        }
        lastqiaoqiaohua='';
        //同步到微博
        SyncInfor(json.sedInfo);
    }
    
    //代理提示消息
    if(json.acceptPlayer.idx==pagedata.usersidx&&json.acceptPlayer.identity==8){    
        if(newMessageRemind.show)
        {
            newMessageRemind.show();
        }
    }
}
//显示送礼物信息
function showGift(json){
    if(json.roomidx!=(pagedata.vroomidx||pagedata.roomidx))return;
	var sendidx = json.sendPlayer ? json.sendPlayer.idx : json.sendidx;
	var acceptIdx = json.acceptPlayer ? json.acceptPlayer.idx : json.acceptIdx;
    if(json.sendGiftidx===1004&&jw.Config.hjdidx&&jw.Config.hjdidx[sendidx]!=null)return;
    var acceptisAnchor=pagedata.roomtype===jw.Config.roomtype.multimic?(!!getAnchorInfo(acceptIdx)):acceptIdx==pagedata.roomidx;
    
    var sendisSelf=sendidx===jw.Config.data.idx;
	var acceptisSelf = acceptIdx == jw.Config.data.idx;
    var _isAnchor=isAnchor();
    
    //获取送礼物和接收礼物人信息-李彪 2013.1.5 
    var send_player=json.sendPlayer||jw.getUserJsonOnList(sendidx,json.sendName);
    var accept_player=json.acceptPlayer||jw.getUserJsonOnList(acceptIdx,json.acceptName);
    var send_namewithpic=jw.getChatPic(send_player);
    var accept_namewithpic=jw.getChatPic(accept_player);
	var sendName = (json.sendPlayer?json.sendPlayer.userName:json.sendName).unescape();
	var acceptName = (json.acceptPlayer?json.acceptPlayer.userName:json.sendName).unescape();
    
    var gift= null;
    //如果接收礼物人是主播,更新礼物列表
    if(acceptisAnchor)
    {
        //有点击过礼物列表才添加
        if (jw.Doms.Right.talk_gift_list) {
            if ($.data(jw.Doms.Right.talk_gift_list, 'get' + acceptIdx) !== undefined) {
                gift = { sendName: sendName, giftidx: json.sendGiftidx, sendNum: json.giftNum, idx: sendidx, toidx: acceptIdx };
                jw.Events.giftList.add(gift);
            }
        }
        if(sendisSelf)
        {
            //刷礼物自动关注主播
            jw.Comm.userControl.sendFans.auto();
        }
    }
    //红包 除自己和主播外都都不能看到
    if(json.sendGiftidx==250&&acceptIdx!=jw.Config.data.idx&&(!sendisSelf)&&sendidx!=0)
        return;
            
    gift=jw.Config.gift.data[json.sendGiftidx];   
    var giftname=gift.n+gift.name;
    
    var msg=WebChat.PackTime(json.time)+send_namewithpic+'送给'+accept_namewithpic+'&nbsp;'+json.giftNumE+giftname+'<img src="'+jw.Config.gift.bigurl+json.sendGiftidx+'.gif?d=20120412'+(gift.version==null?'':'&v='+gift.version)+'" />';
    /*在此添加私聊框礼物信息提示，2012-12-21*/
    if(acceptisSelf&&json.giftNum>=99){
        var _p_msg='';
        if(acceptisAnchor)
        {    
            var zf_msg=json.time+sendName+'送给'+acceptName+json.giftNum+giftname;
            _p_msg+='<a href="#" onclick="zf_giftMsg(\''+zf_msg+'\'); return false;" >转</a>';
        }
        _p_msg+=json.time+'<span class="system">【系统消息】'+send_namewithpic+'赠送给您&nbsp;'+json.giftNum+giftname+'<img width="16px" height="16px" src="'+WebChat.Config.gift.smallurl+json.sendGiftidx+'.png?d=20120412'+(gift.version==null?'':'&v='+gift.version)+'" />&nbsp;<a href="#" onclick="IM.addFriend('+sendidx+');return false">加为好友</a></span>';
        jw.Message.chat.private.append(_p_msg);
    }
    
    if((gift.price*json.giftNum)>=50000&&(gift.price*json.giftNum)<100000) {
	    if (json.sendGiftidx != 250 && json.sendGiftidx != 707) {
		    var _lbmsg='<a><strong>'+sendName+'</strong>&nbsp;送给&nbsp;<strong>'+acceptName+'</strong> &nbsp;'+json.giftNum+giftname+'</a>&nbsp;';
		    _lbmsg+='<img src="http://sr.9513.com/live/images/giftjs/50-50/'+json.sendGiftidx+'.jpg?d=201301051103" width="16px" height="16px">&nbsp;'+(json.time==null?"00:00":json.time);
		    jw.Message.chat.Addlb.append(_lbmsg,false);
	    }
    }
    if(sendisSelf&&jw.Message.quest){
        var lstatus=jw.Message.quest.getStatus(4);
        if(json.sendGiftidx!=250&&json.sendGiftidx!=707&&(lstatus==null||lstatus==-4)){//免费礼物不计入任务
            jw.Message.quest.DoQuest(4,null,json.giftNum>5?5:json.giftNum);
        }
    }
    //收到礼物价值100000以上自动发私信
    if(acceptisAnchor&&_isAnchor&&(gift.price*json.giftNum>99999))
    {
        jw.Comm.userControl.sendSixin.data.toidx=sendidx;
        jw.Comm.userControl.sendSixin.data.msg='非常感谢你的礼物，我很喜欢，请继续支持我哦~';
        jw.Comm.userControl.sendSixin.send(jw.Comm.userControl.sendSixin.data);
    }
   
    if(json.sendGiftidx==250&&json.giftNum==300&&acceptisAnchor&&(_isAnchor||sendisSelf))
    {
       showChatToOne({time:jw.getTime(),sedInfo:'谢谢你送我红包，希望你能在我的主播间玩的开心哦！',acceptPlayer:jw.getUserJsonOnList(sendidx),sendPlayer:jw.getUserJsonOnList(pagedata.currentidx||pagedata.roomidx)},true);
    }
	//收到礼物提示
    var clear = function(iscleartimeout) {
	    if(iscleartimeout&&jw.Doms.Other.confirm.autosid) {
		    clearTimeout(jw.Doms.Other.confirm.autosid);
		    jw.Doms.Other.confirm.autosid = null;
	    }
	    jw.Doms.Other.dialog_showgifttips.remove();
        jw.Doms.Other.dialog_showgifttips = null;
    };
	var showsendgifttips = function() {
		if(pagedata.usersidx&&acceptisSelf&&!jw.Config.gift.showgifttips) {
			if(jw.Doms.Other.dialog_showgifttips) {
				clear(1);
			}
			var tipmsg=json.time+send_namewithpic+'送给'+jw.getChatPic(accept_player, true)+'&nbsp;'+json.giftNum+giftname+'<img src="'+jw.Config.gift.bigurl+json.sendGiftidx+'.gif?d=20120412'+(gift.version==null?'':'&v='+gift.version)+'" />';
			var tipshtml='<div style="z-index:888;overflow:hidden;" class="xsrw dialog clearfix"><div class="popBox" style="width:415px;"><a href="#" class="dclose"></a><div class="bgTop" ><div class="popCont"><h1>提示</h1>';
            tipshtml+='<div class="box_main"><div style="text-align: center;">'+tipmsg+'</div></div>';
            tipshtml+='<p class="foot"><a href="#" class="W_btn_e"><span>确定</span></a><a href="#" class="W_btn_f"><span>不再提示</span></a></p></div></div></div></div>';
			jw.Doms.Other.dialog_showgifttips = $(tipshtml);
			jw.Doms.Other.dialog_showgifttips.appendTo(jw.Doms.body);
			jw.Doms.Other.dialog_showgifttips.find('.dclose').click(function () {
			    clear(1);
				return false;
		    });
			jw.Doms.Other.dialog_showgifttips.find('.W_btn_e').click(function () {
			    clear(1);
				return false;
		    });
			jw.Doms.Other.dialog_showgifttips.find('.W_btn_f').click(function () {
			    jw.Config.gift.showgifttips = true;
			    clear(1);
				return false;
		    });
		    jw.Doms.Other.confirm.autosid=setTimeout(function() {
				clear(0);
				return false;
		    }, 3000);
		    
	    }
	};

	//判断是否展示礼物效果
    if(jw.Config.gift.showcount.indexOf(','+json.giftNum+',')>-1||gift.istx)
    {
        jw.Message.chat.public.append(msg);
	    showsendgifttips();
	    
        if(json.sendGiftidx!=1004&&json.sendGiftidx!=1019)//黄金带、财神不展示
        {
            if(json.sendGiftidx==250&&acceptisSelf&&_isAnchor)//红包，主播不展示
            {
                return;
            }
            //是否是特效礼物
            var type=(gift.istx?1:0);
            //礼物展示
            jw.Events.showGift.screenShow.show(json.sendGiftidx,json.giftNum,type,gift.price,sendName,gift.version);  
        }
    }
    else
    {
	    if(!acceptisAnchor) {
		    showsendgifttips();
	    }
        if((!jw.Config.gift.showgift)||json.sendGiftidx==250||json.sendGiftidx==707||json.sendGiftidx==149)
        {
            jw.Message.chat.public.append(msg);
            return;
        }
        
        json.picsendname=send_namewithpic;
        json.picacceptname=accept_namewithpic;
        
        //插入待刷礼物列表
        jw.Events.giftList.addGiveList(json);

        //启动刷礼物
        jw.Events.brushGift.start();

        //延时停止刷礼物
        jw.Events.brushGift.stop(false);
    }
}

//更新礼物列表
function showupdataGift(json) {
}
//更新余额
function showUserMoney(num) {

    //得币提示
     try{
        if(jw.Doms.Other.moneyTip&&jw.Config.data.money){
            var _offset =  jw.Config.moneyTipOffset;
            var tipnum=parseInt(num,10)-parseInt(jw.Config.data.money,10);
            if(tipnum>0){
                jw.Doms.Other.moneyTip.show().stop().css({left:_offset.left-25,top:_offset.top+15,opacity:1}).html("+"+tipnum).animate({opacity:'toggle',top:(_offset.top-15)},'slow');
            }
 	    }
 	}catch(e){}
     jw.Config.data.money = parseInt(num, 10);
     if (!isNaN(num)) {
         jw.Doms.Left.money.html(num);
         if (jw.Doms.Left.money2)
             jw.Doms.Left.money2.html(num);
     }
}
//发送礼物失败
function  showFlaseSendGift(result) {
    jw.Message.error(2,result);
	if(result==1) {
		updateUserBalance();
	}
}
//发送禁言消息
function showforbidSuccess(json) {
    jw.Message.chat.public.system(jw.getChatPic(json.toPlayer)+'被'+jw.getChatPic(json.opPlayer)+'禁言！',json.time);
}
//禁言失败信息
function showforbidFalse(result) {
    jw.Message.error(3,result);
}
//恢复发言信息
function showresetSuccess(json) {
    jw.Message.chat.public.system(jw.getChatPic(json.toPlayer)+'被'+jw.getChatPic(json.opPlayer)+'恢复发言！',json.time);
}
//恢复发言失败信息
function showresetFalse(result) {
    jw.Message.error(5,result);
}
//踢人成功信息
function showoutSuccess(json) {
    if(json.toPlayer.idx==jw.Config.data.idx)
    {
        jw.Message.alert("您已被"+jw.getChatPic(json.opPlayer)+"踢出房间！",function(){gourl('/');}, function(){gourl('/');}, null, null, true);
        jw.Doms.Other.alert.find("a").click(function () {
            return false;
        });
    }
    jw.Message.chat.public.system(jw.getChatPic(json.opPlayer)+'踢出了'+jw.getChatPic(json.toPlayer)+'。',json.time);
}
//踢人失败信息
function showoutFalse(result){
    jw.Message.error(4,result);
}
//添加管理成功
function showUpManagerSuccess(json) { 
    if(json.toPlayer.idx==pagedata.usersidx)
    {
        set_usercontrol(json.toPlayer);
    }
    jw.Message.chat.public.system(jw.getChatPic(json.toPlayer)+'被'+jw.getChatPic(json.opPlayer)+'提升为房间管理员！',json.time);
}
//添加管理失败信息
function showUpManagerFalse(result) {
    jw.Message.error(6,result);
}
//删除管理成功
function showDownManagerSuccess (json) {  
    if(json.toPlayer.idx==pagedata.usersidx)
    {    
        set_usercontrol(json.toPlayer);
    }
    jw.Message.chat.public.system(jw.getChatPic(json.toPlayer)+'被'+jw.getChatPic(json.opPlayer)+'降为普通会员！',json.time);
}
//删除管理失败信息
function showdownManagerFlase(result) {
    jw.Message.error(7,result);
}
//停止直播信息
function showstopLive(idx) {
    jw.Config.data.isPlay=0;
   //直播状态
    $("#zb_live_state").html('<img class="Zb_ic noZb_ic" src="http://sr.9513.com/live/v2.0/images/pixel.gif""><em>已停播/'+pagedata.anchorlocation+'</em>');
    if(!isAnchor())
    {
        var from='';
        if(pagedata.fromsource!==2)
            from=urlQueryString("from");
        if(from.length==0)
        {
            if(pagedata.roomtype===jw.Config.roomtype.multimic)
            {
                if(idx===pagedata.currentidx)
                    jw.Message.confirm('该房间主播已经去休息啦，您可以去其他的美女主播间逛逛哦！', function () {
                        gourl('/go' + getcroomidx());
                    }, null, null, null, true, '随便逛逛', '取消');
            }
            else
            {
                jw.Message.confirm('该房间主播已经去休息啦，您可以去其他的美女主播间逛逛哦！', function () {
                    gourl('/go' + getcroomidx());
                }, null, null, null, true, '随便逛逛', '取消');
                showstopLiveTips();
            }
        }
    }
}
//停播提示
function showstopLiveTips(onlyclear) {
    //直播状态
    $("#zb_live_state").html('<img class="Zb_ic noZb_ic" src="http://sr.9513.com/live/v2.0/images/pixel.gif""><em>已停播/'+pagedata.anchorlocation+'</em>');
    if(window.stopliveid)
    {
        clearTimeout(window.stopliveid);
        window.stopliveid=null;
    }
    if(onlyclear)return;
    
    window.stopliveid=setTimeout(function () {
        var dom=jw.Doms.Right.user_list_list.find("ul[idx='"+pagedata.roomidx+"']");
        if(dom.length===1)
        {
            return;
        }
        jw.Message.confirm('该房间主播已经去休息啦，您可以去其他的美女主播间逛逛哦！',function(){
	        gourl('/go'+getcroomidx());
        },null, null, null,true,'随便逛逛','取消');
    },300000);
}
//转移观众信息
function showCopyPlayer(json) {
    if(json.opidx==pagedata.usersidx)
    jw.Message.alert("转移邀请发送成功！");
    else
    jw.Message.alert("主播邀请大家去房间"+json.toidx+"，点击确定转移房间！",function(){gourl('/'+json.toidx);});
}
//转移观众失败
function showCopyPlayerFalse() {
    jw.Message.alert("转移观众失败！");
}
//公告发送成功
function showMsgList(msg){
    jw.Message.chat.private.system(msg.toJsonString().toChatViewString(false),null,0);
    
    UpdateRoomInfo("gongGao",msg);
}
//公告发送失败信息
function showMsgListFalse() {
    jw.Message.alert("公告发送失败！");
}
//发送小喇叭成功，发送小喇叭html拼接处
function showLaBa(json) {
       
    //var idx='';
    var _url='';
    var hd_game=0;
    if(json.sendidx==10000)//系统喇叭
    {
        json.sendMsg=json.sendMsg.unescape().replace(/url\:\S+/g,function () {
        var arg=arguments[0];
        if(arg)
        {
            _url='href="'+arg.substring(4)+'" target="_blank"';
            return '';
        }
        else
            return '';
        });
        //凿金蛋通知
	    var index = json.sendMsg.indexOf('hitegg:');
	    if(index>-1) {
		    var msg = json.sendMsg.substring(7).split('|');
		    if (msg[3] !== 'success1')
			    return;
		    var egg = { 1: '纹蛋', 2: '木蛋', 3: '瓷蛋', 4: '铜蛋', 5: '银蛋', 6: '金蛋', 7: '福蛋', 8: '禄蛋', 9: '寿蛋', 10: '金鸡' };
		    var egg_msg= '凿到'+egg[msg[4]]+',';
		    var msgstr = '恭喜{0}' + unescape(msg[1]) + '{1}在“凿金蛋游戏”中，{2}获得' + msg[5] + '星币';
		    json.time = msg[2];
		    jw.Message.chat.public.system(msgstr.replace('{0}', '<a hidefocus="true" onclick="return false;" href="#this" class="user" >').replace('{1}', '</a>').replace('{2}',egg_msg) + '<a onclick="HitEgg(0);return false;" href="#this" target="_blank"> >>我也要玩</a>');
		    json.sendMsg = msgstr.replace('{0}', '').replace('{1}', '').replace('{2}', '');
	    }
	    //海底大冒险通知
	    var index_hd=json.sendMsg.indexOf('game:');
	    if(index_hd>-1){
	        if(pagedata.fromsource==1){
	            hd_game=1;
	        }
	        var hd_msg="恭喜{0}在“海底大冒险”中，获得{1}";
	        var _json=$.parseJSON(json.sendMsg.replace('game:',''));
	         var num_s=parseInt(_json.point%100000);
             var num_b=_json.point-num_s; 
             if(num_b/100000<10)return;
             var _msg=(num_s>0?(num_s/50)+"朵玫瑰和":"")+(num_b/100000)+"辆兰博基尼";
	        json.sendMsg=hd_msg.replace('{0}',_json.screename.unescape()).replace('{1}',_msg);
	    }
    }
    //普通用户
    var str=json.sendMsg.unescape();
    var rmindex=str.indexOf("roomidx{");
    if(rmindex>-1)
    {    
        
        _url='href="'+getHttpHost()+'/'+str.substring(rmindex+8)+'" target="_blank"';
        if(str.substring(rmindex+8)==getcroomidx())
        {
            _url='';
        }
        json.sendMsg=str.substring(0,rmindex);
    }
    var _msg = '';


    //系统消息
    if (json.sendidx == 10000) {
        if (_url.length > 0) {
            _msg = '<a ' + _url + '>' + (json.sendidx == 10000 ? '' : (json.sendName.unescape() + '&nbsp;&nbsp;说：')) + json.sendMsg.toChatViewString(true, (json.sendidx == 10000 ? 2 : 6), false) + '  ' + $.trim(json.time) + '</a>';

        } else {
            var _on_c = '';
            if (hd_game) {
                _on_c = 'href="#" onclick="checkWebgame();return false;"';
            }
            _msg = '<a style="text-decoration: none;" ' + _on_c + '>' + (json.sendidx == 10000 ? '' : (json.sendName.unescape() + '&nbsp;&nbsp;说：')) + json.sendMsg.toChatViewString(true, (json.sendidx == 10000 ? 2 : 6), false) + '  ' + $.trim(json.time) + '</a>';
        }
       jw.Message.chat.Addlb.system(_msg);
    }
    else
    {
        _msg = '<a href="/' + json.roomcno + '" target="_blank">' + $.trim(json.time) + "&nbsp;&nbsp;" + json.sendMsg.toChatViewString(true, (json.sendidx == 10000 ? 2 : 6), false) + '</a><a href="javascript:void(0)" class="lbName">（' + json.sendName.unescape() + '）</a>' //+ WebChat.PackTime($.trim(json.time));
        //console.log(json)
        jw.Message.chat.Addlb.Airing(_msg); //发送喇叭(广播)消息
    }
}
//显示房主禁止公聊信息
function showChatForbid(result) {
    pagedata.pubchat=result.toString();
    document.getElementById("a_pubchat").innerHTML = "公聊"+(pagedata.pubchat=="1"?"×":"√");
    
    jw.Message.error(9,result);
    
    UpdateRoomInfo('pubchat',result.toString());
}
//显示房间状态信息
function showRoomStatus(json) {
    jw.Message.chat.private.system("直播状态："+((json.isForbidChat==1||json.isForbidChat)?"直播中":"已关闭")+" 公聊："+((json.isRoomClose=="1")?"开启":"关闭"));
}
//显示付款成功
function showPayMoneySuccess () {
    jw.Message.chat.private.system("您已成功付款"+jw.Comm.userControl.sendPayMoney.data.roomPay+"币！");
    jw.Doms.Other.confirm.dialog("destroy");
}
//显示余额不足
function showNotEnoughMoney(isopen) {
    jw.Message.alert("您的余额不足，请充值！",function(){
        gourl(jw.Config.pay_url,isopen);
    },function(){
        gourl(jw.Config.pay_url,isopen);
    });
}
//显示输入密码
function showInputPassWord() {
    jw.Message.inputpassword();
}
//密码错误
function showFalsePassWord(){
    jw.Message.inputpassword("密码错误，请重新输入密码！");
}
//显示房间设置信息 6300
function showRoomSet(json) {
    var _paimai=pagedata.roomtype===jw.Config.roomtype.threemic&&json.paimai!=null;
    if(isRoomowner())
    {
        jw.Doms.Right.private.find("[class='system']:contains('【系统消息】用户进出信息：')").parent().parent().remove();
        var msg="用户进出信息："+((json.outslt=="1")?"打开":"关闭");//"房间状态："+((json.roomslt=="1")?"关闭":"打开")+
        if(_paimai)
        {
            msg+=" | 自由排麦："+((json.paimai=="1")?"打开":"关闭");
            $("#btnzipaimai").html("自由排麦"+(json.paimai == "1"?"√":"×"));
        }
        jw.Message.chat.private.system(msg);
    }
    jw.Comm.adminControl.sendRoomSet.data.roomslt=json.roomslt;
    jw.Comm.adminControl.sendRoomSet.data.outslt=json.outslt;
    
    if(_paimai)
    {
        jw.Comm.adminControl.sendRoomSet.data.paimai=json.paimai;
    }
}
//显示消息
function ShowMsgBox(msg) {
    jw.Message.alert(msg.unescape());
}
//flash在私聊框系统提示
function ShowPrivateMsg(msg,href) {
    if(href!=null)
    {
        msg='<a href="'+href+'" target="_blank" hidefocus="true">'+msg+'</a>';
    }
    if (msg.indexOf("连接服务器成功") > -1 && jw.Doms.Right.talk_gift_list)
    {
        jw.Doms.Right.talk_gift_list.empty();
    }
    jw.Message.chat.private.system(msg);
}
//自动回复
var stid=null;//防止双方自动回复造成服务器压力过大
function autorespond(toidx,toname) {
    lastqiaoqiaohua='';
    jw.Comm.sendChat.lastmsg='';
    if(jw.Config.autorespond.status!=1)
    {
        return;
    }
    if(stid!=null)
    {
        clearTimeout(stid);
    }
    stid=setTimeout(function () {
        if(jw.Config.autorespond.status==1)
        {
            jw.Comm.sendChat.data.roomidx = pagedata.roomidx;
            jw.Comm.sendChat.data.msg=jw.Config.autorespond.msg.replace("$target",toname);
            jw.Comm.sendChat.data.default_toidx=jw.Comm.sendChat.data.toidx;
            jw.Comm.sendChat.data.toidx=toidx;
            jw.Comm.sendChat.sendChatQiao(jw.Comm.sendChat.data,true);
            lastqiaoqiaohua='';
            jw.Comm.sendChat.lastmsg='';
            jw.Comm.sendChat.data.toidx=jw.Comm.sendChat.data.default_toidx;
        }
    },5000);
}
//视频框点击关注
function asGuanzhuClick() {
    if(pagedata.usersidx ==0)
    {   
          jw.Message.pleaselogin("游客不能关注主播");
          return;
    }
    //jw.Comm.userControl.sendFans.send({type:1,toidx:(pagedata.currentidx||pagedata.roomidx)});
	wb_attention_Operation(1, pagedata.currentidx || pagedata.roomidx);
    //FollowMm();
}
//视频框点击分享
function asShareClick() {
    if(pagedata.usersidx ==0)
    {   
          jw.Message.pleaselogin("游客不能分享");
          return;
    }
    pleaseShare();
}
//弹出分享框
function pleaseShare(title) {
    title=title||'有什么新鲜事分享到我的微博';
    $("#sharewei").dialog({title:title,autoOpen:true,width:"500",height:"210",close:function(){
            $("#sharewei").dialog("close");$("#txtshare").val("");},load:function () {
            shareContent();
          }
    });
}
//消息提示
var newMessageRemind={
    _step: 0,
    _title: document.title,
    _timer: null,
    //显示新消息提示
    show:function(){
            //窗口获取焦点时清除消息提示
            $(window).focus(function () { newMessageRemind.clear(); });
            
            newMessageRemind.clear();
            
            var temps = newMessageRemind._title.replace("【　　　　　　】", "").replace("【您有新的消息】", "");
            newMessageRemind._timer = setTimeout(function() {
                newMessageRemind.show();
                newMessageRemind._step++;
                if (newMessageRemind._step == 3) { newMessageRemind._step = 1 };
                if (newMessageRemind._step == 1) { document.title = "【　　　　　　】" + temps };
                if (newMessageRemind._step == 2) { document.title = "【您有新的消息】" + temps };
            }, 800);
            return [newMessageRemind._timer, newMessageRemind._title];
       
    },
    //取消新消息提示
    clear: function(){
        if(newMessageRemind._timer!=null)
        {
            clearTimeout(newMessageRemind._timer);
        }
        document.title = newMessageRemind._title;
    }
};
//设置显隐身
function setHide() {
 
    var ishide=$("#btnsethide").attr("ishide");//?($("#btnsethide").attr("ishide")):"0";//getCookie("user_ishide");//getCookie("user_ishide")==null?"1":getCookie("user_ishide");
	ishide = ishide === 'true';
    if(jw.Config.data.identity==2&&(getCookie("user_ishide")==null))
    {
        ishide=true;
    }
    jw.Message.confirm("您确定要"+(ishide?"显身":"隐身")+"吗？",function(){
        jw.Comm.userControl.sendSetHide.data.ishide=(ishide?0:1);
        jw.Comm.userControl.sendSetHide.send(jw.Comm.userControl.sendSetHide.data);
            
        $("#btnsethide").html("当前"+(ishide?"显身":"隐身"));
        setCookie("user_ishide", (ishide ? "0" : "1"), 30);
    });
}
//隐身设置返回
function showhide(json,player) {
	if (json.idx === pagedata.usersidx) {
		if (jw.Config.data.identity === (pagedata.roomtype === jw.Config.roomtype.multimic ? 11 : 1))
			return;
		$("#btnsethide").html("当前" + (json.ishide ? "隐身" : "显身")).attr("ishide",(json.ishide ? "true" : "false"));
		setCookie("user_ishide", (json.ishide ? "1" : "0"), 30);
		if (json.ishide) {
			jw.Message.chat.private.system('您已成功隐身！', json.time);
			if (jw.Config.data.identity !== 2 && jw.Config.data.identity !== 10)
				jw.Config.usercontrol = 0;
		} else {
			jw.Config.usercontrol = 1;
			jw.Message.chat.private.system('您已成功显身！', json.time);
		}
	} else if (json.ishide && player.identity !== 2 && jw.Config.data.identity !== 10) {
		jw.Message.chat.private.system('有位同学悄悄溜进房间啦！', json.time);
	}
	if (json.ishide) {
		jw.Doms.Right.user_list.find("div[id!='listmic'] ul[idx='" + json.idx + "']").addClass('hide');
	} else {
		jw.Doms.Right.user_list.find("div[id!='listmic'] ul[idx='" + json.idx + "']").removeClass('hide');
	}

}

/************************/
//获取秀场之王&秀场王后
function getKingQueen(){
    return {king:0,queen:0};
}

//插入直播用户体验数据
function setLiveStatistics(json) {
    try{
        var _json=null;
        for(var i=0,len=json.length;i<len;i++)
        {
            _json=json[i];
            if(_json.cdisconnect==0&&_json.vdisconnect==0&&_json.vloadtime==0)
            {
                _json.liveid='';
            }
            if(_json.liveid.length>0&&_json.idx.indexOf('-')==-1)
            {
                $.ajax({
                    cache:false,
                    url:liveflashurl.livestatistics+'?roomidx='+_json.roomid+'&liveid='+_json.liveid+'&sidx='+_json.idx+'&chatdisconnect='+_json.cdisconnect+'&videodisconnect='+_json.vdisconnect+'&videoloadtime='+_json.vloadtime+'&videoip='+_json.videoip+'&chatip='+_json.chatip            
                });
            }
        }
     }catch(e){}
}

//幸运礼物
function showLuckyGift(json) {
    json.player = json.player || {
        idx: json.idx,
        identity: 6,
        userName: json.nickName,
        userLevel: json.userlevel,
        vipLevel: json.viplevel
    };

    if (!json.player.cno) {
        json.player = jw.getUserJsonOnList(json.idx) || json.player;
    }

    var gift = jw.Config.gift.data[json.giftid];
    var name = jw.getChatPic(json.player, true, true, true);
    var isself = json.player.idx == jw.Config.data.idx;
    //console.log('showLuckyGift. multi:%d, num_500:%d, isself:%s', json.multi, json.num_500, isself)
    //console.log(json)
    var _lburl;//喇叭链接
    if (json.multi != null) {
        json.money = gift.price * json.multi * json.num_500;
        json.multiss = json.multi + '倍大奖' + json.num_500 + '次，获得' + json.money + '星*币！';
        _lburl = 'href="/' + json.roomid + '" target="_blank"';
        var _lbmsg = '<a ' + _lburl + ' hidefocus="true">恭喜<span style="color:#ff0000">' + json.nickName.unescape() + '</span>喜中“' + gift.name + '”' + json.multiss + '</a>';
        jw.Message.chat.Addlb.system(_lbmsg, 1);
        if (isself) {
            jw.Config.data.money = parseInt(jw.Config.data.money, 10) + parseInt(json.money, 10);
            showUserMoney(jw.Config.data.money);
        }
    }
    /*  
    if (json.multi != null && json.multi >= 0) {
        json.money = gift.price * json.multi * json.num_500;
        json.multiss = json.multi + '倍大奖' + json.num_500 + '次，获得' + json.money + '星*币！';
        _lburl = 'href="/' + json.roomid + '" target="_blank"';
        var _lbmsg = '<a ' + _lburl + ' hidefocus="true">恭喜<span style="color:#ff0000">' + json.nickName.unescape() + '</span>喜中“' + gift.name + '”' + json.multiss + '</a>';
        jw.Message.chat.Addlb.system(_lbmsg);
    } else if (json.multiss != null) {
        json.multiss = json.multiss.unescape();
    }
    var msg = '<span style="color:#ff0000">恭喜' + name + '喜中“' + gift.name + '”' + (json.multiss ? json.multiss : "") + (json.roomid != getcroomidx() ? '<a href="/' + json.cno + '" target="_blank" hidefocus="true">>>去看看</a>' : '') + '</span>';
   
    if (isself) {
        jw.Message.chat.private.system(msg, json.time);
        if (isself) {
            jw.Config.data.money = parseInt(jw.Config.data.money, 10) + parseInt(json.money, 10);
            showUserMoney(jw.Config.data.money);
        }
    } else if (json.roomid == getcroomidx()) {
        jw.Message.chat.private.system(msg, json.time);
    }
    */
}
//更新库存、提示库存不足
function showUserKC(json) {
    if(json.enough)
    {
        //更新库存
        if(jw.Config.gift.sended!==null)
        {
            jw.Config.gift.sended(json.giftid,json.num,'update');
        }
    }
    else
    {
        var msg="您的库存不足！";//现在就玩<a href=\"#\" onclick='palyqqdz();return false' hidefocus='true'>气球宝藏</a>
        jw.Message.chat.private.system(msg,json.time);
    }
}

//飞屏发送成功
function flyText(json) {
    jw.Events.showGift.screenShow.showFlyText(json);
}
//炸弹成功
function bombPlayer(opPlayer,toPlayer,time,code) {
    var msg=toPlayer.userName+'被'+opPlayer.userName+'炸出房间啦!';
    
    if(code==7002)
        flyText({roomid:pagedata.roomidx,sendIdx:10000,opid:0,position:150,size:30,color:0,content:msg,sendName:'',time:time});
    else
    {
        msg=jw.getChatPic(toPlayer,true)+'被'+jw.getChatPic(opPlayer)+'炸出房间啦!';
        
        if(toPlayer.idx==jw.Config.data.idx)
        {
            jw.Message.alert(msg,function(){gourl('/');}, function(){gourl('/');}, null, null, true);
            jw.Doms.Other.alert.find("a").click(function () {return false;});
        }
        else
            jw.Message.chat.public.system(msg,time);
    }
}
//炸弹失败(没权限)
function bombPlayerNoAccess(identity) {
    jw.Message.alert('对方拥有顶级防御，您不能炸他哦！');
}
//炸弹失败
function bombPlayerFalse(opPlayer,toPlayer,time,bombid) {
    var msg='';
    if(toPlayer.identity==1||toPlayer.identity==2||toPlayer.identity==8||toPlayer.identity==10)
    {
        msg='对方拥有顶级防御，您不能炸他哦！';
    }
    else if(toPlayer.vipLevel>2)
    {
        msg='对不起，对方的防御能力太强，请使用黑色炸弹！';
    }
    else if(bombid==704&&toPlayer.vipLevel>1)//黄色炸弹
    {
        msg='对不起，对方的防御能力太强，请使用紫色炸弹！';
    }
    if(msg.length>0)
    jw.Message.alert(msg);
}
//炸弹失败
function showBombLimit(){
    jw.Message.alert('对不起，该用户今天已经被炸出房间5次，不能再次被炸出房间！');
}
//显示分到的星币
function showAssignedMoney(json) {

    if((json.opPlayer.idx==jw.Config.data.idx)&&(json.giftid==701)){
            return;
    }
    var gift=jw.Config.gift.data[json.giftid];
    var msg=jw.getChatPic(json.opPlayer)+'点'+gift.name+'您已经获得'+json.money+'星币';
    showUserMoney(parseInt(json.money,10)+parseInt(jw.Config.data.money,10));
    jw.Message.chat.private.system(msg,json.time);
}
//微博加粉结果
function showSendFansResult(type,result) {
    var screename=pagedata.currentidx?getAnchorInfo(pagedata.currentidx).screename:pagedata.anchorscreename;
    switch(parseInt(result,10))
    {
        case -2:
            jw.Message.alert('您关注的人数已达到上限！');return;
            break;
        case -3:
            jw.Message.alert('您已经是'+screename+'的普通粉丝！');return;
            break;
        case -4:
            jw.Message.alert('您已经是'+screename+'的高级粉丝！');return;
            break;
        case -6:
            jw.Message.alert(screename+'在您的黑名单里！');return;
            break;
        case -8:
            jw.Message.alert('您已被'+screename+'加入黑名单！');return;
            break;
        default:break;
    }
    if(type===1||type===2)
    {
        if(result===1&&pagedata.currentidx===pagedata.currentvidx)
        {
            jw.Config.data.isfans=1;
            window.bindgz&&bindgz();
        }
    }
    else if(type===3)
    {
        if(result===1&&pagedata.currentidx===pagedata.currentvidx)
        {
            jw.Config.data.isfans=0;
            window.bindgz&&bindgz();
        }
    }
}

function getRoomType(){
    return pagedata.roomtype||0;
}
//flash回调函数准备好了
function asCallBackReady(){
    try {
        if (jw.Config.data.user_jsonList) {
            jw.Doms.chatComm.sendUserList(jw.Config.data.user_jsonList.user);
            jw.Doms.chatComm.sendAdminList(jw.Config.data.user_jsonList.admin);
        }
    }catch(e){}
}
 
//更新在线人数
function updateOnlineNumber(type,idx,isadmin) {
	switch (pagedata.roomversion) {
	    case '3.1.1':
		case '3.1.2':
			break;
		default:
			return;
	}
	if (type === 0) {
		jw.Config.onlineviewer && jw.Config.onlineviewer--;
		if (isadmin || WebChat.Doms.Right.user_list_admin.find('ul[idx="' + idx + '"]').length) {
			jw.Config.onlineadmin && jw.Config.onlineadmin--;
		}
	} else {
		jw.Config.onlineviewer++;
		if (isadmin || WebChat.Doms.Right.user_list_admin.find('ul[idx="' + idx + '"]').length) {
			jw.Config.onlineadmin++;
		}
	}
	showOnlineNumber(jw.Config.onlineviewer, jw.Config.onlineadmin);
}

//刷新房间数据
function loadDataList(timer){
    setTimeout(function(){
        $.ajax({
            cache:false,
            url:'http://api.9513.com/userlist/getdatalist.ashx?i='+getroomidx(),
            dataType:'jsonp',
            timeout:2000,
            success:function(data){
                if(data){
                    pagedata.datalist=data;
                    _page_loadUserList(true);
                    asCallBackReady();
                }
//                timer=timer*2;
//                if(timer>=60000)
//                {
//                  timer =60000;
//                }
                loadDataList(timer);
            },
            error:function(){
                loadDataList(timer);
            }
        });
    },timer);
}
//获取身份
function getUserIdentity_http(player){
    if(player){
        if(player.idx<0){
            return 7;
        }
        var identity=6;
        if(player.idx===pagedata.roomidx){
            identity=1;
        }else if(pagedata.roomtype===jw.Config.roomtype.multimic&&getAnchorInfo(player.idx)){
            identity=11;
        }else if(player.vipLevel===100){
            identity=2;
        }else if(player.vipLevel===90){
            identity=10;
        }else if(player.vipLevel===80){
            identity=8;
        }
        if(identity!==6)
            return identity;
        var admin=jw.Doms.Right.user_list_admin.find('ul[idx="'+player.idx+'"]');
        if(admin.length){
            identity=parseInt(admin.attr('identity'),10);
        }else if(player.vipLevel>0){
            identity=4;
        }
        return identity;
    }else{
        return jw.Config.data.identity;
    }
}

//用户第一次送礼物，提示主播 
var _remove_sendGiftTips=function(domID){
          $("#"+domID).remove();
};
var _back_msgs=function(idx,toidx,name,type,domID){
  if(type==0){
        var _msg={"roomidx":pagedata.roomidx,"toidx":idx,"msg":"谢谢啦~"};
        jw.Comm.sendChat.sendMsgToOne(_msg);
  }
  else{
	   var _data = {"accpetidx":idx,"giftidx":85,"gifttype":0,"giftnum":1,"sendType":0};
       jw.Comm.sendGift.send(_data);
  }
   _remove_sendGiftTips(domID);
   return false;
};
function user_FirstSendGift(json){
     var _tipDoms=$("#talk_list_0").find(".s_tip");
     if(_tipDoms.length>=5){
         _tipDoms.eq(0).remove();
     }
     var _tip_giftboxID='_tip'+(json.sendidx+"_"+json.acceptIdx);

 var _first_sendHtml='<div class="s_tip" id="'+_tip_giftboxID+'"><div class="popBox"><a href="#" class="popShut" onclick="_remove_sendGiftTips(\''+_tip_giftboxID+'\'); return false;"></a>';
     _first_sendHtml+='<div class="bgTop"><div class="popCont"><p>小编提醒：'+json.sendName.unescape()+'第一次给您送礼物哦~是否回应？</p>';
     _first_sendHtml+='<p style="text-align:center;"><a href="#" onclick="_back_msgs('+json.sendidx+','+json.acceptIdx+',\''+json.sendName.unescape()+'\',0,\''+_tip_giftboxID+'\');return false;">说声谢谢</a>';
     _first_sendHtml+='<em>|</em><a href="#" onclick="_back_msgs('+json.sendidx+','+json.acceptIdx+',\''+json.sendName.unescape()+'\',1,\''+_tip_giftboxID+'\');return false;">回个谢谢你礼物</a></p></div></div></div></div>';
     $("#chatlogs").after(_first_sendHtml);
     setTimeout(function(){
       _remove_sendGiftTips(_tip_giftboxID);
     },10000);
}  
/*发微博*/
var zf_giftMsg=function(msg){
    if(window.wxwb){
       wxwb.data.publish({text:msg},function(data){
            if(data!=null){
                jw.Message.alert("发送成功！");
            }else{
                jw.Message.alert("发送失败！");
            }
       });
    }
    return false;
};
//更新余额 砸飞机游戏专用
function updateUserBalance() {
	try {
		jw.Doms.chatComm.updataUserMoney();
	} catch(e) {}
}
//获取在线人数
function getOnlineviewer(){
	return jw.Config.onlineviewer;
}
//判断是否添加赞按钮(sendIdx：发送者IDX，sendName:发送者昵称，c_length：汉字长度，isRct：?彩条，identity：等级，isGreenCard：是否绿卡，Msg：消息内容)
function AddPraiseBotton(sendIdx,sendName,c_length,isRct,userLevel,isGreenCard,Msg){
    var _msg='';
    if(pagedata.fromsource==1&&(jw.Config.data.isPlay&&jw.Config.data.isPlay==1)&&isAnchor()&&sendIdx!=pagedata.roomidx&&(jw.Config.data.zanNum&&jw.Config.data.zanNum>0)){
        var _k=((jw.Config.data.UnableZanList&&jw.Config.data.UnableZanList.indexOf(sendIdx)<0)||jw.Config.data.UnableZanList==undefined)&&(userLevel==0||isGreenCard);
        if(!isRct&&_k&&c_length>=3){
            //_msg='&nbsp;<a href="#" isc="0" onclick="sendPraise('+sendIdx+',\''+sendName+'\',\''+pagedata.chat+'\',\''+Msg+'\','+isGreenCard+',this);return false;"><img src="http://sr.9513.com/v3.0/images/zan_btn.png"/></a>';
        }
    }
    return _msg;
}
//发送'赞'信息
function sendPraise(userId,name,server,msg,card,obj){
    
    if(jw.Config.data.isPlay!=1){
        jw.Message.chat.private.system('请开播后在亲亲他吧！');
        return false;
    }
    if(!jw.Config.data.zanNum||jw.Config.data.zanNum<=0){
        jw.Message.chat.private.system(jw.Config.data.zanNum<=0?'您的亲亲已经用完了哦，明天再亲亲他吧！':'您还未领取亲亲');
        return false;
    }
    if(pagedata.fromsource!=1){
         return false;
    }
    var _unImg='http://sr.9513.com/v3.0/images/unzan_btn.png';
    if($(obj).hasClass("disable")||$(obj).attr("isc")=="1"){
        return false;
    }
    $(obj).attr("isc","1");
    $.ajax({
          type:"Post",
          url:"/Ashx/SendPraise.ashx",
          cache:false,
          data:{uid:userId,uname:name,server:server,Msg:msg,card:card},
          success:function(result){
              if(result=='1'){
                $(obj).html('<img src="'+_unImg+'"/>').attr("class","disable");
                jw.Config.data.zanNum=jw.Config.data.zanNum-1;
                jw.Doms.Other.zanBtn=$(".how_zan").find("em").html(jw.Config.data.zanNum);
              } 
              else if(result=='0'||result=='-4'||result=='-3'){
                jw.Message.chat.private.system(result=='0'?'您已亲亲他满十次，改天再亲亲他吧！':(result=='-4')?'他今天已经被亲亲50次了哦，换其他人试试吧':'您今天的亲亲已经送完了，明天再试试送吧！');
                if(jw.Config.data.UnableZanList==undefined){
                   jw.Config.data.UnableZanList=userId.toString();
                }
                else if(jw.Config.data.UnableZanList.indexOf(userId)<0){
                    jw.Config.data.UnableZanList=jw.Config.data.UnableZanList.concat('|'+userId);
                } 
              }
          },
          error:function(){
              
          }    
     });
}
//显示系统消息
function showSystemMsg(json,type){
     //赞提示处理
     if(json.unescape().indexOf('praise:')>-1&&pagedata.fromsource==1){
            var _json=eval('('+json.unescape().replace('praise:','')+')');
             if(_json['idx']==pagedata.usersidx){
                jw.Message.chat.private.system('您的话很赞，主播亲了您一口，赢得'+(_json['card']==true?30:10)+'个星币');
                updateUserBalance();
                showGouDaZhuBo(1);
            }
            else{
                var _msg='['+_json['uname']+'说的：'+_json['msg'].toChatViewString(true,null,true,null,_json['idx'])+'] 说的很不错哦，获得主播一个亲亲，赢得'+(_json['card']==true?30:10)+'星币！';
                jw.Message.chat.public.system(_msg);
            }
      }
}
//检查字符串中汉字的长度是否符合条件
String.prototype.getChineseCharLength=function(){
	var count = 0;
    for (var i=0; i<this.length; i++)
    {
        var c = this.charCodeAt(i);
		if(c>= 0x4E00 && c<= 0x9FA5){
			count++;
		}
//		if(count>=3)
//			 break;
    }
	return count;//>=3?true:false;
};
//发送重播消息
var ReSendCreateLiveid;
function ReSendCreateLive() {
	if(ReSendCreateLiveid) {
		clearTimeout(ReSendCreateLiveid);
		ReSendCreateLiveid = undefined;
	}
	CloseOcx();
	var msg = '{"roomidx":"';
	msg += jw.Config.data.roomidx;
	msg += '","result":';
	msg += 1;
	msg += '}';
	WebChat.Doms.chatComm.sendstopLiveInfo(msg);
	ReSendCreateLiveid=setTimeout(function() {
		jw.Comm.adminControl.sendCreateLive.send(jw.Comm.adminControl.sendCreateLive.data);
		//重播计数
		if (liveflashurl.recreatecounturl) {
			$.ajax({
				cache: false,
				url: liveflashurl.recreatecounturl,
				data: 'sidx=' + jw.Config.data.roomidx
			});
		}
	}, 2000);
}


var animatList = []; //动画队列

//加入队列
function AddanimatList(path,flashName)
{
    if (animatList.length == 0) { //队列是否有值
        animatList.push({ key: path, value: flashName });//加入队列
        PlayCarFlash(flashName);//播放动画
    } else {
        animatList.push({ key: path, value: flashName });//加入队列
    }
}

//播放动画   参数：动画存放文件夹，flash名称，宽，高
function PlayFlash(path, flashName, width, height,top,left) {
    var guid = WebChat.getGuid();//获取一个GUID
    var carUrl = "http://www.9513.com/flash/" + path + "/" + flashName + ".swf?guid=" + guid;//座驾路径
    var flashHtml = $('<div id="wai_'+guid+'"><span id="' + guid + '" class="flash_' + path + '"></span></div>');
    flashHtml.css({ "top": top, "left": left, "position": "absolute", "pointer-events": "none" })
    $("#userEnterEffectID").append(flashHtml);//插入flash

    var opObjectParams = {}; //flash参数
    opObjectParams.quality = "high"
    opObjectParams.wmode = "transparent";//设置透明
    opObjectParams.menu = "false"; //设置不需要菜单
    opObjectParams.FlashVars = "guid=" + guid;
    opObjectParams.allowScriptAccess = "always"
    swfobject.embedSWF(carUrl, guid, width, height, "9.0.0", "expressInstall.swf", null, opObjectParams);
    $("#userEnterEffectID").show();
    //设置动画10秒后关闭，防止不存在的flash占用过长的时间，堆积起来对页面不好  朱海波  2015-04-29
    setTimeout(function () { CloseUserEnterEffect({ guid: guid }); }, 10000);
}

//播放车动画
function PlayCarFlash(effectid) {
    PlayFlash('car', effectid, 650, 400,120,100);
}

//播放守护动画
function PlayGuardFlash(guardTypeInt) {
    PlayFlash('Guard', guardtype[guardTypeInt], 1200, 600,120,100);
}



//用户进场特效(用户座驾特效)（1028）
function userEnterEffect(player, useridx, effectid, effectname, time) {
    //console.log(player, useridx, effectid, effectname, time);
    if(useridx<=0) return;
    if (effectid && effectname) {
        //聊天窗口显示座驾
        var msg = (time == null ? WebChat.getTime() : time) + '<span class="system">【系统消息】' + jw.getChatPic(player, false) + '开着<span style="color:red;">' + effectname.unescape() + '</span>进入房间</span>';
        jw.Message.chat.public.append(msg);
        AddanimatList("car", effectid);
    }
}


//播放下一个动画
function PlayNextFlash() {
    animatList.shift();//移除一个队列
    if (animatList.length > 0) {
        switch (animatList[0].key) {
            default:
                PlayCarFlash(animatList[0].value);//播放队列中下一个动画
        }
    }
}

//flash播放完成后的关闭
function CloseUserEnterEffect(json) {
    //console.log(json)
    if ($("#" + json.guid).length > 0) {
        $("#" + json.guid).hide();
        $("#" + json.guid).remove();
        $("#wai_" + json.guid).hide();
        $("#wai_" + json.guid).remove();
    }
    PlayNextFlash();//播放下一个动画
}



//---------------守护开始------------------------

var guardtype = ["","gold","silver"];//守护类型
//开通或者续期守护的回调
//guardcno: 10023 guardtype: 1 online: 1 onlinenum: 4 rid: 800001033 totalnum: 7
function buyGuardAck(json) {
    if(json==null) return;
    //console.log(json);
    getGuardUserInfo(json.guardcno, json.online, json.guardtype, json.onlinenum, json.totalnum);
    PlayGuardFlash(json.guardtype);
    //AddanimatList("Guard", guardtype[json.guardtype]);//守护动画加入队列
}
//守护列表
var guardList = {};
var guardNum = 0; //总守护数
var guardOnlineNum = 0; //当前在线守护数

//守护列表
function showAddGuardlist(json) {
    if (!json.guard) return false;
    //console.log(json);
    getGuardUserInfo(json.guard.cno, json.guard.online, json.guard.guardtype);
    
}
//获取守护的个人信息，并自己增加在线总数与守护总数
function getGuardUserInfo(useridx, online, guardtype, onlinenum, totalnum)
{
    $.ajax({
        cache: false,
        url: '/Ashx/memberinfo.ashx',
        data: { useridx: useridx },
        dataType: 'json',
        success: function (data) {
            //console.log(data);
            if (data.nickname) { //有数据时
                var cssName = online?"Online":"NoOnline"
                var html = '<li dataIdx="' + data.cno + '" data-Type="' + guardtype + '" dataName="' + data.screename + '" data-online="' + online + '" class="' + cssName + '"><img src="' + data.PicUrl + '" class="headImg" /></li>';
                var current = $("#GuardList li[dataIdx=" + data.cno + "]");
                if (current.length > 0) {
                    current.replaceWith(html);
                } else {
                   
                    $("#GuardList").append(html);
                    guardNum++;
                }
                guardList["key_" + data.cno] = data;
                
                /*
                if (onlinenum) //在线守护数
                    guardOnlineNum = onlinenum;
                    */
                if (totalnum)//总守护数
                    guardNum = totalnum;

                $("#guardNum").html(guardNum);//更新守护总人数
                $("#guardOnlineNum").html($("#GuardList li.Online").length);//更新在线人数
                
                //排序
                var paixu = $("#GuardList li").toArray();//排序
                paixu = paixu.sort(function (a, b) {
                    var aonline = $(a).attr("data-online");
                    var bonline = $(b).attr("data-online");
                    if (bonline - aonline != 0)
                        return bonline - aonline;

                    var atype = $(a).attr("data-Type");
                    var btype = $(b).attr("data-Type");
                    return atype - btype;

                });
                $("#GuardList").html(paixu);
                
            }
        }
    });
}
    //-------------守护结束--------------------------

//--------------------------舞台 抛物线 开始---------------------------
function paoLine(imgSrc)
{
    //生成道具抛物线初始位置
    var cssleft = { "position": "absolute", "top": "800px", "left": "0", "z-index": "99999999" };//道具初始位置左边
    var cssRight = { "position": "absolute", "top": "800px", "right": "0", "z-index": "99999999" };//道具初始位置左边
    var nn = GetRandomNum(1, 2);
    var css = nn == 1 ? cssleft : cssRight;

    var guid = WebChat.getGuid();//获取一个guid
    var item = $('<div id="' + guid + '" class="pwx_item"><img src="' + imgSrc + '" /></div>').css(css)
    WebChat.Doms.Left.left.append(item);//在开始区域插入道具
    //生成终点top
    var ztop = GetRandomNum(-50, -80);
    //console.log(ztop);
    var zd = $('<i></i>').css({ "left": GetRandomNum(0, 483) + "px", "top": ztop + "px" });
    WebChat.Doms.AtEnd.append(zd);//在结束区域插入道具
    var offsetStart = item.offset();//起点
    var offset = zd.offset();//终点
    var maxleft = WebChat.Doms.AtEnd.offset().left + WebChat.Doms.AtEnd.width();//最大左边
    var zdleft = offset.left > maxleft ? maxleft : offset.left;//终点位置不能超出轨道
    item.fly({
        start: {
            left: offsetStart.left,  //开始位置（必填）#fly元素会被设置成position: fixed
            top: offsetStart.top  //开始位置（必填）
        },
        end: {
            left: zdleft,
            top: offset.top,
            //抛物线完成后留在页面上的图片大小
            width: item.width(), height: item.height()
        },
        vertex_Rtop: 100,
        speed: vertex_speed,
        onEnd: function (newguid) { //匿名函数，防止guid重复
            setTimeout(function () { $("#" + newguid).remove() }, 11000);//定时消失
        }(guid)
    });
}
//--------------------------舞台 抛物线 结束---------------------------

//----------------------免费花开始-----------------------------
var flowersNum = 0;
//用户花数量刷新
function genFreeFlower(json) {
    if (json.freeflowernum!=undefined) {
        flowersNum = json.freeflowernum;
        $("#flowersNum").html(flowersNum);
        $("#flowersBtn").attr("title", "已累计" + flowersNum + "朵人气花，点击送给主播一朵。")
    }
}

//主播得到的花数量刷新
var current = 0;//当前送的第N朵免费花数量
function sendFreeFlowerAck(json) {
    //console.log(json);
    $("#zb_flowers_num").html(json.total_num);//刷新主播花的数量
    for (var i = 0; i < json.send_num;i++)
    {
        /**/
        current++;
        var msg = '<div class="times fl">' + WebChat.PackTime(WebChat.getTime()) + "</div>";
        msg += '<div class="text fl">' + jw.getChatPic(playList[json.send_id], false) + '&nbsp;送给&nbsp;' + jw.getChatPic(playList[json.recv_id], false) + '第' + current + "朵人气花";
        msg += '&nbsp;</div>';
        WebChat.Message.chat.Addlb.append(msg);
        paoLine("http://sr.9513.com/live/v3.1.6/images/zbj_flowers.png");
        
    }
}

//送花给主播
function sendFreeFlowerGiveZB() {
    if (flowersNum > 0) {
        var _data = { "accpetidx": pagedata.anchoridx, "giftidx": 150, "gifttype": 0, "giftnum": 1, "sendType": 0 };
        jw.Comm.sendGift.send(_data);
    }
}


//----------------------免费花结束--------------------------

//---------------------抢沙发开始---------------------------

SeatJson = [0,0,0,0,0,0]; //当前沙发数据当前抢的第几次
//抢沙发
function sendRobSeat(seatId) { //参数:seatId需要强的沙发的Id
    if (SeatJson[seatId] == 0)
        SeatJson[seatId] = 1;
        var _data = { "accpetidx": seatId, "giftidx": 151, "gifttype": 0, "giftnum": SeatJson[seatId], "sendType": 0 };
        jw.Comm.sendGift.send(_data);
    
}

//抢沙发回调
function sitSofaAck(json)
{
    //console.log(json)
    switch (json.ret) {
        case 0:
            SeatJson[json.sofaid] = json.value / 100+1;
            $.ajax({
                cache: true,
                url: '/Ashx/memberinfo.ashx',
                data: { useridx: json.uid },
                dataType: 'json',
                success: function (data) {
                    //console.log(data);
                    if (data.nickname) { //有数据时
                        var html = '<img src="' + data.PicUrl + '" /><span>' + data.screename + '</span>';
                        var num = json.sofaid + 1;
                        var parentSeat = $(".seat" + num);
                        var SeatHead = parentSeat.find(".seatHead");
                        if (SeatHead.length > 0) {
                            SeatHead.html(html);
                        } else {
                            html = '<div class="seatHead">' + html + '</div>';
                            parentSeat.append(html);
                        }
                    }
                }
            });
            break;
        case -3:
            jw.Message.alert("抢沙发使用的币不足！");
            break;
        case 1:
            break;
            jw.Message.alert("您没有足够的币了！");
        case 4: //沙发到期
            var num = json.sofaid + 1;
            var parentSeat = $(".seat" + num);
            parentSeat.find(".seatHead").remove();//移除
            SeatJson[json.sofaid] = 1; //沙发归0
            break;
        default:
            console.log(json);
            break;
    }
}

//---------------------抢沙发结束---------------------------

//---------------------系统消息轮询开始-------------------------------
var systemInfo_n = 0; //当前需要显示的系统消息索引
var systemData = []; //系统消息数据
//获取系统消息
function LookSystemMessage()
{
    $.ajax({
        cache: true,
        url: '/Ashx/GetSysInfoList.ashx',
        dataType: 'json',
        success: function (data) {
            if (data.length > 0) {
                systemData = data;
                sendSystemMessage();
                setInterval(sendSystemMessage, 1000 * 60 * 5);//5分钟执行一次
            }
        }
    });
}

//发送系统消息
function sendSystemMessage()
{
    var url = systemData[systemInfo_n].url;
    if (url.indexOf("http:") < 0)
        url = "http://" + url;
    var msg = '&nbsp;&nbsp;<a href="' + url + '" target="_blank">' + systemData[systemInfo_n].content + '</a>';
    jw.Message.chat.Addlb.system(msg, 0);
    systemInfo_n++;
    if (systemInfo_n >= systemData.length)
    {
        systemInfo_n = 0;
    }
}



//-----------------------系统消息轮询结束-----------------------------






    //用户自己进入房间
    function showSelfEnter(json){
        //处理进入提示
        json.isadd=1;
        jw.Events.userList.showPlayerAddTip(json);
    }

    //自定义协议(11110:更新抢座列表,11100:抢完座收到的消息)
    function showUserDefinedProtocol(command,json) {
    
        if(command==null||json==null||pagedata.fromsource!=1||(urlQueryString('from',true).length>0&&pagedata.usersidx<=0)) return;
        //抢座
        if(json.activityType==1){
            if(json.roomidx!=pagedata.roomidx) return; 
            var _json=$.parseJSON(json.msg.unescape());
            var _sendninfo,_showinfo;
            _sendninfo=_json.sendinfo||{};
            _showinfo=_json.showinfo||{};
            switch(command){
                case 11110:
                    //if(pagedata.usersidx<=0) return;
                    /*
                    if (getSeatListData)
                        getSeatListData(_showinfo);*/
                    break;
                case 11100:
                    if(_sendninfo.from_nickname&&_sendninfo.target_nickname){
                        jw.Message.chat.public.system(jw.getChatPicOnList(_sendninfo.fromid,_sendninfo.from_nickname)+'抢了'+jw.getChatPicOnList(_sendninfo.targetid,_sendninfo.target_nickname)+'的座位');
                        //if(pagedata.usersidx<=0) return;
                        if(_sendninfo.targetid==pagedata.usersidx&&_sendninfo.fromid!=pagedata.usersidx){
                            jw.Message.alert('您的座位已经被"'+_sendninfo.from_nickname+'"抢啦');
                        }
                        showGrabGif(_sendninfo.index);
                    }else{
                        jw.Message.chat.public.system('恭喜'+jw.getChatPicOnList(_sendninfo.fromid,_sendninfo.from_nickname)+'成功抢到1个座位');
                    }
                    //if(pagedata.usersidx<=0) return;
                    //getSeatListData(_showinfo);
                    if(isAnchor()){
                        updateUserBalance();
                    }
                    break;
            }
        }
    }
    //public
    function GetByteLen(a, b) {
        var c = 0; for (var i = 0; i < a.length; i++) {
            if (this.charCodeAt(i) >= 0x4E00 && this.charCodeAt(i) <= 0x9FA5) { c += 2 } else { c += 1 }
        } return c > b
    } String.prototype.bytelength = function () {
        var a = 0; for (var i = 0; i < this.length; i++) {
            if (this.charCodeAt(i) >= 0x4E00 && this.charCodeAt(i) <= 0x9FA5) { a += 2 } else { a += 1 }
        } return a
    }; String.prototype.subbytestr = function (a, b) {
        var d = this; var e = 0; var f = 0; if (this.length > a && d.length > b) {
            for (var i = a; i < b; i++) { var c = d.charCodeAt(i); if (c >= 0x4E00 && c <= 0x9FA5) { f++ } else { e++ } } b = (b - a) * 2; if (f) { b -= (e + f) } d = d.substring(a, b)
        } return d.toString()
    };
    //获取用户的经验，人气，财富等基本信息
    var getmemberexpenseurl = '/ashx/member/getmemberexpense.ashx';
    var getGradeBar = function (b, c) {
        if (b.sidx == null) { return }
        var d = '<img src="http://sr.9513.com/live/images/loading.gif" />';

        if (b.fhid) { $("#" + b.fhid).addClass("loading") }
        if (b.zbid) { $("#" + b.zbid).addClass("loading") }
        if (b.rqid) { $("#" + b.rqid).addClass("loading") }
        
        $.ajax({
            type: 'GET',
            url: getmemberexpenseurl,
            cache: false,
            timeout: 15000,
            async: (b.async != null ? b.async : true),
            data: 'sidx=' + b.sidx + (b.needlevel ? '&needlevel=1' : '') + (b.needownbill ? '&needownbill=1' : '') + (b.isrealtime ? '&isrealtime=1' : ''),
            dataType: 'json',
            success: function (a) {
                setBarData(b, a, c);
                if (b.success != null && $.isFunction(b.success))
                { b.success(a) }
                if (b.fhid) { $("#" + b.fhid).removeClass("loading") }
                if (b.zbid) { $("#" + b.zbid).removeClass("loading") }
                if (b.rqid) { $("#" + b.rqid).removeClass("loading") }
            }, error: function () { getGradeBar(b, c) }
        })
    };
    var setBarData = function (a, b, c) {
        if (a.fhid != null) {
            if (b == null) {
                $("#" + a.fhid).html('')
            } else {
                a.grade = b.usergrade;
                a.exM = b.expensemoney;
                $("#" + a.fhid).html(getBar({ role: 'fh', grade: a.grade, exM: a.exM, curwidth: a.curwidth, nextimg: a.nextimg }, c))
            }
        }
        if (a.zbid != null) {
            if (b == null) {
                $("#" + a.zbid).html('')
            } else {
                a.grade = b.singergrade;
                a.exM = b.receivemoney;
                //获取主播等级经验相关信息
                var data = getBar({ role: 'zb', grade: a.grade, exM: a.exM, curwidth: a.curwidth, nextimg: a.nextimg }, c);
                $("#" + a.zbid).find("em").css("width", data.bar);
                $("#" + a.zbid).find("span").html("主播升级还需要" + data.mustCoin + "星币");
            }
        }
        if (a.rqid != null) {
            if (b == null) {
                $("#" + a.rqid).html("")
            } else {
                a.grade = b.popularity;
                $("#" + a.rqid).html(rqBar({ role: 'rq', grade: a.grade, curwidth: a.curwidth }, c))
            }
        }
    };
    var getBar = function (a, b) {
        a.role = a.role == null ? "fh" : a.role;
        a.nextimg = a.nextimg == null ? true : a.nextimg;
        a.grade = a.grade == null ? 0 : a.grade; a.exM = a.exM == null ? 0 : a.exM;
        var c = "http://sr.9513.com/live/v2.0/images/face/";
        var e = parseInt(a.grade) + 1; var f = null; var g = 0; var h = 0; var i = 0; var d = '';
        if (a.role == "fh") {
            f = [5000, 10000, 20000, 40000, 100000, 150000, 300000, 500000, 800000, 1200000, 2000000, 3000000, 4000000, 6000000, 8000000, 10000000, 15000000, 20000000, 30000000, 50000000, 80000000, 100000000, 150000000, 200000000, 250000000, 300000000, 500000000, 800000000];
            d = "z";
            i = f.length
        } else {
            f = [10000, 50000, 150000, 300000, 500000, 1000000, 2000000, 3500000, 5000000, 7000000, 10000000, 15000000, 20000000, 40000000, 55000000, 70000000, 90000000, 110000000, 150000000, 200000000, 250000000, 350000000, 450000000, 500000000, 550000000, 600000000, 650000000, 700000000, 750000000, 800000000, 850000000, 900000000, 950000000, 1000000000, 1050000000, 1100000000, 1150000000, 1200000000, 1250000000, 1300000000];
            d = "z";
            i = f.length;
            g = a.grade > 29;
            h = e > 29
        }
        if (a.curwidth == null) {
            if (a.role == "fh") {
                var j = null; if (a.grade < 11) {
                    j = "40"
                } else if (a.grade > 10 && a.grade < 23) {
                    j = "50"
                } else if (a.grade > 22 && a.grade < 26) {
                    j = "56"
                } else { j = "66" } j += "px"; a.curwidth = j
            } else { a.curwidth = "auto" }
        }
        
       
        //获取主播等级相关Json信息(总星币，升级需要的星币)
        if (a.role == "zb") {
            var data = {};
            data.totalCoin = f[a.grade]; //总共需要多少星币
            data.HaveCoin = a.exM;    //主播当前拥有的星币
            data.mustCoin = data.totalCoin - a.exM;//升级还需要的星币
            var n = a.grade > 0 ? f[a.grade - 1] : 0; //上一级需要的星币
            
            data.bar = ((a.exM - n) / (data.totalCoin - n)) * 100 + "%";//进度条的百分比
            $("#zb_level").html('<img src="' + c + d + a.grade + '.gif?d=20121203"/>' + pagedata.anchorscreename + '(' + getanchorcno() + ')');
            return data;
        } else {
            $("#zb_level").html('<img src="' + c + d + a.grade + '.gif?d=20121203"/>' + pagedata.anchorscreename + '(' + getanchorcno() + ')');
            var k = '<div class="left" style="width:' + a.curwidth + ';text-align:right;" ><img src="' + c + d + a.grade + '.gif?d=20120222" title="\u5F53\u524D\u7EA7\u522B"' + (g || h ? ' class="exbar' + (g ? '2' : '1') + '"' : '') + ' /></div>';
            if (b.newbar) {
                if (b.isfull) {
                    k = '<td width="40" align="right">' + (a.role == "fh" ? "\u5BCC\u8C6A\uFF1A" : "\u4E3B\u64AD\uFF1A") + '</td>'
                } else {
                    k = '<td width="63" align="left">' + (a.role == "fh" ? "\u5BCC\u8C6A\u7B49\u7EA7\uFF1A" : "\u4E3B\u64AD\u7B49\u7EA7\uFF1A") + '</td>'
                }
                k += '<td align="right" style="' + (a.role == "fh" ? "" : "width: 61px;") + ' text-align: center;"><img src="' + c + d + a.grade + '.gif?d=20121203"/></td>'
            }
            if (a.grade < i) {
                var l = f[a.grade]; var n = a.grade > 0 ? f[a.grade - 1] : 0; var o = l - a.exM;
                var p = parseInt(70.0 * (a.exM - n) / (l - n));
                var m = a.role == "fh" ? "\u9001\u51FA" : "\u6536\u5230";
                if (b.newbar) {
                    k += '<td width="70"><div title="\u5347\u7EA7\u8FD8\u9700' + m + o + '\u661f\u5e01" class="level_wk" ><em style="width:' + p + 'px"></em></div></td>';
                    if (a.nextimg && b.isfull) {
                        k += '<td algin="center" width="70"><img  src="' + c + d + e + '.gif?d=20120222" title="\u4E0B\u4E00\u7EA7\u522B" /></td>'
                    }
                } else {
                    k += '<div title="\u5347\u7EA7\u8FD8\u9700' + m + o + '\u661f\u5e01" class="exbar left ' + (g || h ? 'exbar3' : '') + '" ><span style="width:' + p + 'px"></span></div>';
                    if (a.nextimg) {
                        k += '<div class="left"><img class="black' + (g || h ? ' exbar4' : '') + '" src="' + c + d + e + '.gif?d=20120222" title="\u4E0B\u4E00\u7EA7\u522B" /></div>'
                    }
                }
            }
            return k;
        }
    };
    var rqBar = function (a, b) {
        var c = [0, 1000000, 5000000, 10000000];
        var e = "http://sr.9513.com/live/v2.0/images/face/";
        var d = "r";
        var f = a.grade == null ? 0 : a.grade;
        if (a.Increment == null) {
            $("#rqDabar").attr("rqdata", f)
        } else {
            var g = $("#rqDabar").attr("rqdata");
            f = parseInt(g) + a.Increment;
            f = f > 10000000 ? 10000000 : f;
            $("#rqDabar").attr("rqdata", f)
        }
        var h = 0;
        if (f < 1000000) {
            h = 1
        }
        else if (f < 5000000) {
            h = 2
        }
        else if (f <= 10000000) {
            h = 3
        } else { 
            h = 3
        }
        var i = c[h];
        var j = c[h - 1];
        var k = 70.0 * (f - j) / (i - j);
        var l = '';
        if (b.newbar) {
            if (b.isfull) {
                l = '<td width="40" align="right">\u4EBA\u6C14\uFF1A</td>'
            } else {
                l = '<td width="54" align="left">\u4EBA\u6C14\u503C\uFF1A</td>'
            }
            l += '<td style="text-align: center;"><img src="' + e + d + h + '.png?d=20120222" title="\u5F53\u524D\u7EA7\u522B" /></td>';
            if (i - f >= 0) {
                l += '<td width="70"><div title="\u5347\u7EA7\u8FD8\u9700' + (i - f) + '\u4EBA\u6C14" class="level_wk" ><em style="width:' + k + 'px"></em></div></td>';
                if (b.isfull) { l += '<td algin="center" width="70"><span class="rq">' + f + '</span></td>' }
            }
        } else {
            l = '<div class="left" style="width:' + a.curwidth + ';text-align:right;" ><img src="' + e + d + h + '.png?d=20120222" title="\u5F53\u524D\u7EA7\u522B" /></div>';
            if (i - f >= 0) {
                l += '<div title="\u5347\u7EA7\u8FD8\u9700' + (i - f) + '\u4EBA\u6C14" class="exbar left" ><span style="width:' + k + 'px"></span></div><span class="rq">' + f + '</span>'
            }
        }
        return l
    };
    var getCookie = function (a, b) {
        if (document.cookie.length > 0) {
            c_start = document.cookie.indexOf(a + "=");
            if (c_start != -1) {
                c_start = c_start + a.length + 1;
                var c = document.cookie.indexOf(';', c_start);
                if (b) {
                    var d = document.cookie.indexOf('&', c_start);
                    if (c == -1 || (d > -1 && c > d))
                        c = d
                }
                if (c == -1) {
                    c = document.cookie.length
                }
                return unescape(document.cookie.substring(c_start, c))
            }
        } return null
    };
    var setCookie = function (a, b, c) { var d = new Date(); d.setDate(d.getDate() + c); document.cookie = a + "=" + escape(b) + ((c == null) ? "" : ";expires=" + d.toGMTString()) };
    //pagelive
    var pageliveurl={
        ships:'/ajax/ships.aspx',
        publish:'/ajax/publish.aspx',
        getbqrank:'/ashx/rank/getbqrank.ashx',
        getroomfans:'/ashx/rank/getroomfans.ashx',
        getroomfanslive:'/ashx/rank/getroomfanslive.ashx',
        getfavorites:'/ashx/live/getfavorites.ashx',
        getuserinroom7d:'/ashx/live/getuserinroom7d.ashx',
        getflashcount:'/ashx/member/getflashcount.ashx',
        getgiftkc:'/ashx/live/getgiftkc.ashx',
        qqbzjs:'http://sr.9513.com/live/v3.1.5/js/weishow.live.qqbz.min.js?d=201401071112',
        questjs:'http://sr.9513.com/live/v3.1.4/js/weishow.live.quest.min.js?d=201309231324',
        getgiftstar:'/ashx/rank/getrankgiftstar.ashx',
        getactivitydata:'/ashx/live/getactivitydata.ashx',
        getsysinfo:'/ashx/live/getsysInfo.ashx',
        gettodaypraise:'/Ashx/getTodayPraise.ashx',
        getdashan:'/Ashx/GetDaShanNum.ashx'
    };


    //与视频加载无关，暂时不知道做什么用的
    function init() { 
    
        var _isanchor=isAnchor();
        var _isroomowner=isRoomowner();
        if(_isanchor||_isroomowner)
        {  
            //单麦加载主播直播提示
            if(pagedata.roomtype==jw.Config.roomtype.single)
            {
                //直播状态
                $("#zb_live_state").html('<img class="Zb_ic noZb_ic" src="http://sr.9513.com/live/v2.0/images/pixel.gif""><em>已停播/'+pagedata.anchorlocation+'</em>');
            }
            var roomzhu = document.getElementById("room_zhu");
            var str = "";
            str += "<a id='btnstoplive' style='display:none;' href='#' onclick='asStopLive();return false;' hidefocus='true'>停止主播</a>";
            if(window.getbtnswap){
                str+=getbtnswap();
            }
            if(_isroomowner){
                //str += "<a href='#' onclick='roomSet();return false;' hidefocus='true'>设置房间</a>";
                str += "<a href='#' onclick='roomTalk();return false;' hidefocus='true'>房间公告</a>";
                if(pagedata.roomtype!==jw.Config.roomtype.multimic){
                    str += "<a href='#' onclick='moveViews();return false;' hidefocus='true'>转移观众</a>";
                }

            
                str += "<a href='#'  onclick='setImage();return false;' hidefocus='true'>设置海报</a>";
                /*新房间没有背景
                str += "<a href='#'  onclick='setBgimage();return false;' hidefocus='true'>设置房间背景</a>";
                */

                //            if(pagedata.fromsource===2)
                //                str += "<a id='btntemplate' href='#'  onclick='return false;' hidefocus='true'>设置房间模板</a>";
                str += "<a id='btnviewpwd'  style='display:none; href='#' onclick='jw.Message.showpassword();return false;' hidefocus='true'>查看房间密码</a>";
                str += "<a id='a_pubchat' href='#' onclick='stopTalk();return false;' hidefocus='true'>公聊"+(pagedata.pubchat=="1"?"×":"√")+"</a>";
                //            str += "<li><a id='a_showgift' href='#' onclick='hideshowgift();return false;' hidefocus='true'>礼物展示√</a></li>";
                if(window.getbtnzipaimai){
                    str += getbtnzipaimai();
                }
            }
            str += "<div class='clearit'></div>";
            roomzhu.innerHTML = str;
            roomzhu.style.display = "";

            $(roomzhu).find("li").hover(function(){
                $(this).addClass("texton");
            },function(){
                $(this).removeClass("texton");
            });
            //停止直播按钮DOM
            jw.Doms.Other.btnstoplive = jw.Doms.doc.find("#btnstoplive");
        
            if(_isroomowner){
                //查看房间密码按钮DOM
                jw.Doms.Other.btnviewpwd = jw.Doms.doc.find("#btnviewpwd");
            }
        }
        //创建插件
        if(isInstall||_isanchor)
        {
            createOcxObj();
        }
    
        //显示房间、主播信息
        setInfo();

        //获取库存礼物
        jw.Config.gift.load=getGiftKc;

        //绑定页面卸载事件
        bindunload();
	
        //设置超管
        var level = getCookie('level', 1);
        if(level&&level=='100') {
            jw.Config.data.identity = 2;
        }
    }
    function setBackGround(){
        if(arguments.length>0)
        {
            pagedata.bgimg = arguments[0].toString();
        }
        var background = (pagedata.bgimg == "" ? "http://sr.9513.com/live/css/skin/css/1/"+pagedata.skin+"/images/bg.jpg" : pagedata.bgimg);
        var rep='repeat';     
        var pos="0 0";   
        if(pagedata.bgimg.length==0)
        {
            pos="center top";
            rep='no-repeat';
        }
        jw.Doms.body.css({"background-image":"url('" +background+ "')","background-repeat":rep,"background-position":pos});
    }
    function loadBQRank(idx){
        var BQRank=$("#BQRank");
        if(BQRank.length==0)
            return;
        BQRank.html('<img src="'+jw.Config.loadingimg+'" /> 排名数据加载中...');
        var Rank_html="";
        $.ajax({
            type:"GET",
            url:pageliveurl.getbqrank+"?sidx="+(idx||pagedata.roomidx),
            cache:false,
            dataType:"json",
            success:function(json){
                if(json!=null && json.length>0)
                {
                    var _json=null;
                    for(var i=0,len=json.length;i<len;i++)
                    {
                        if(i>2) break;
                        _json=json[i];
                        Rank_html+='<li '+(i==0?"class='nomargin'":"")+'><img src="'+_json.pic_url+'" width="22" height="22" alt="'+_json.gift_name+'" title="'+_json.gift_name+'" /> <p>'+_json.ranknum+'名</p></li>';
                    }  
                }
                else
                    Rank_html='<span>暂无排名数据</span>';
                BQRank.html(Rank_html);    
            },
            error:function(){
                BQRank.html('数据加载失败，请<a href="#" onclick="loadBQRank();return false;" hidefocus="true">重试</a>'); 
            }    
        });
    }
    function loadRoomFans(type,idx){
        var fansel=$("#roomfans"+type);
        if(fansel.length==0)
            return;
        if(pagedata.roomtype!==jw.Config.roomtype.multimic&&type==1&&fansel.data("data")!=null)
        {
            return;
        }
        if(type==1)
        {
            jw.Config.data.fansstar=undefined;
        }
        else
        {
            jw.Config.data.livestar=undefined;
        }
        fansel.html('<div class="list_box"><img src="'+jw.Config.loadingimg+'" /> 粉丝数据加载中...</div>');
        var html='';
        $.ajax({
            type:"GET",
            url:(type==1?pageliveurl.getroomfans:pageliveurl.getroomfanslive)+"?roomidx="+(idx||pagedata.roomidx),
            cache:false,
            dataType:"text",
            success:function(json){
                if(json==null||json==''||json.toString()=='[object XMLDocument]')
                {
                    fansel.html('<div class="list_box"></div>');
                    return;
                }
                json=eval('('+json+')');
                if(json!=null&&type==0){
                    $("#roomfans0_div").show();
                }
                if(json!=null)
                {
                    var _json=null;
                    for(var i=0,len=json.length;i<len;i++)
                    {
                        _json=json[i];
                        var picurl=_json.picurl.length>0?_json.picurl:pagedata.nophoto;
                        var name=_json.screename.bytelength()>14?_json.screename.subbytestr(0,7)+'...':_json.screename;
                        html+='<div class="'+(i<3?'l_b_on ':'')+'list_box">';
                        html+='<ul><li class="room_w75"><ul><li class="room_w67 '+(i==0?'fans_p_k '+(type==1?'fs':'fs2'):'fans_p_b')+'">';
                        if(i>0)
                        {
                            html+=(i+1);
                        }
                        html+='</li></ul></li><li class="room_w210"><ul><li class="room_w115 fans_t_b"><img width="50" height="50" src="'+picurl+'" onerror="this.src=\''+pagedata.nophoto+'\'" ></li><li class="fans_u_b"><p>';
                        if(_json.userlevel>0)
                        {
                            html+='<img src="http://sr.9513.com/live/v2.0/images/face/v'+_json.userlevel+'.gif?v=2.0" /><br/>';
                        }
                        html+='<span title="'+_json.screename+'">'+name+'</span></p></li></ul></li><li class="fans_x_b room_w170"><h3>'+_json.sumdounum+'</h3><p>'+getStar(_json.sumdounum)+'</p></li><br class="clearit"></ul></div>';
                
                        if(i==0)
                        {
                            if(type==1)
                            {
                                jw.Config.data.fansstar=parseInt(_json.idx,10);
                            }
                            else
                            {
                                jw.Config.data.livestar=parseInt(_json.idx,10);
                            
                                if(fansel.data("data")!=null)
                                {
                                    var a=jw.getChatPicOnList(_json.sidx,_json.screename);
                                    jw.Message.chat.public.system('祝贺'+a+'成为本场直播的超级粉丝啦！');
                                }
                            }
                        }
                    }
                
                    fansel.data("data",1);
                }
                fansel.html(html); 
            
            },error:function(e){
                fansel.html('<div class="list_box">数据加载失败，请<a href="#" onclick="loadRoomFans('+type+','+(!idx?'null':idx)+');return false;" hidefocus="true">重试</a></div>');
            }    
        });
    }
    function getStar(sumdounum){
        if(sumdounum==null)
        {
            return "";
        }
        var m=1000000;
        var sm=parseInt(sumdounum/m);
        var count=sm>5?5:sm;
  
        var html='';
        var sr='http://sr.9513.com/live/images/star';
        for(var i=0;i<count;i++)
        {
            html+='<img width="23" height="22" src="'+sr+'.gif">';
        }
        if(count<5&&(sumdounum%m>=m/2))
        {
            count++;
            html+='<img width="23" height="22" src="'+sr+'_half.gif">';
        }
        for(var i=1;i<6-count;i++)
        {
            html+='<img width="23" height="22" src="'+sr+'_empty.gif">';
        }
        return html;
    }
    //start 随便看看
    function intiBrowsing(){
        var favorites_show= $("#browsing_favorites_show");
        var room_show=$("#browsing_room_show");
        var browsing_more=$("#browsing_more");
    
        $("#browsing_favorites").click(function () {
            $(this).parent().addClass("okli").siblings().removeClass("okli");
            favorites_show.show();
            room_show.hide();
            if(favorites_show.data("Favorites")==null)
            {
                loadFavorites();
            }
            browsing_more.attr("href","/myFavorite.aspx").show();
            return false;
        });
        $("#browsing_room").click(function () {
            $(this).parent().addClass("okli").siblings().removeClass("okli");
            room_show.show();
            favorites_show.hide();
            if(room_show.data("UserInRoom24H")==null)
            {
                loadUserInRoom24H();
            }
            browsing_more.attr("href","/room").hide();
            return false;
        });
        $("#browsing_favorites").click();
    }
    function loadFavorites() {
        var show=$("#browsing_favorites_show");
        show.html('<li name="browsing_loading"><img src="'+jw.Config.loadingimg+'" />数据加载中...</li>');
        $.ajax({
            type:"post",
            dataType:"json",
            url:pageliveurl.getfavorites,
            cache:false,
            success:function (json) {
                show.data("Favorites","1");
                if(json==null||json.length==0)
                {
                    $("#browsing_room").click();
                    show.html("没有收藏房间");
                    return;
                }
                append_browsing_show(json,"browsing_favorites_show");
            },error:function () {
                show.html('数据加载失败，请<a href="#" onclick="loadFavorites();return false;" hidefocus="true">重试</a>');
            }
        });
    }
    function loadUserInRoom24H(){
        var show=$("#browsing_room_show");
        show.html('<li name="browsing_loading"><img src="'+jw.Config.loadingimg+'" />数据加载中...</li>');
        $.ajax({
            type:"post",
            dataType:"json",
            url:pageliveurl.getuserinroom7d,
            cache:false,
            success:function (json) {
                show.data("UserInRoom24H","1");
                if(json==null||json.length==0)
                {
                    show.html("没有浏览记录");
                    return;
                }
                append_browsing_show(json,"browsing_room_show");
            },
            error:function (e) {
                show.html('数据加载失败，请<a href="#" onclick="loadUserInRoom24H();return false;" hidefocus="true">重试</a>');
            }
        });
    }
    function append_browsing_show(json,id) {  
        var html="";
        var _json=null;
        var isfav=id==='browsing_favorites_show';
        for(var i=0,len=json.length;i<json.length;i++)
        {
            var online="";
            _json=json[i];
            if(_json.live_stat&&_json.live_stat=="1")
            {
                if(_json.onlinenum)
                {
                    online=_json.onlinenum+"人";
                }
            }
            else
            {
                online="直播未开始";
            }
            var roomname=_json.roomname.bytelength()>10?_json.roomname.subbytestr(0,5)+'...':_json.roomname;
            html+='<div class="user_pic_b"><div class="pic"><a hidefocus="true" href="/'+_json.roomidx+'"><img src="'+(_json.haibaourl.length==0?pagedata.nophoto:_json.haibaourl)+'" height="60" width="60" onerror="this.src=\''+pagedata.nophoto+'\';" /></a></div>';
            html+='<div class="txt" style="height:30px;"><a hidefocus="true" href="/'+_json.roomidx+'" title="'+_json.roomname+'">'+roomname+'</a></div>';              
            html+='<div class="txt">'+online+'</div></div>';
        
            if(isfav&&_json.roomidx===getcroomidx())
                jw.Config.favorite.isadd=true;
        }
        $("#"+id).html(html);
    }
    //end 随便看看


    //同步到微博
    var SyncInfor=function(txtmsg){    
    };

    //初始化ActiveX控件
    function initActiveX(mxid){
        if(window.ActiveXObject===undefined||pagedata.usersidx==0)
            return;

        var _w=428;
        var _h=316;
        var _mxid=mxid>0?mxid:'';
        var _initax = function () {

            try
            {
                Invoke = new ActiveXObject("MFACTIVEX.MFActiveXCtrl.2");
                Invoke = null;
                isInstall = true;
            }
            catch(e){}
        };

        var _write = function () {
            document.write('<OBJECT ID="ShowActiveXCtrl' + _mxid + '" CLASSID="clsid:EB657E3D-85F6-4809-AFCE-BA9A5DE7979C" width="' + _w + '" height="' + _h + '"></OBJECT>');
        };

        if(isAnchor()) {
            _write();
            _initax();
        } else if(pagedata.roomtype===jw.Config.roomtype.threemic) {
            if(mxid>0)
            {
                _w=214;
                _h=158;
            }
            if(!isInstall)
            {
                _initax();
            }
            if(isInstall)
            {
                _write(true);
            }
        }
        _initax=null;
        _write=null;
    }
    //初始化注册、登录、海报、背景设置
    function initRegLoginHaibaoBgpic(){
        var e='';
        if(pagedata.usersidx===0){
            //var reg_login_html='<div id="dialog-reg" title="请注册" style="display: none;"><div class="center"><iframe src="about:blank" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" height="429" width="100%"></iframe></div></div>';
            e='<div id="dialog-login" title="请登录" style="display: none;">';
            e+='<div><iframe frameborder="0" scrolling="no" marginheight="0" marginwidth="0" height="130" width="100%" src="about:blank" ></iframe></div></div>';                  
            document.write(e);   
        } else if(isRoomowner()) {
            //设置海报
            e='<div id="dialog_haibao" class="dialog" style="width:330;height:448px;"></div>';
                    
            //设置房间背景
            e+='<div id="dialog_bgpic" class="dialog" style="width:431px;height:179px;"></div>';
        
            //设置房间模板
            e+='<div id="dialog_templates" style="display: none"></div>';
                            
            document.write(e);
        }   
    }

    //取随机数
    function GetRandomNum(Min, Max) {
        var Range = Max - Min;
        var Rand = Math.random();
        return (Min + Math.round(Rand * Range));
    }

    //取字符串长度
    function getStrLength(str) {
        var cArr = str.match(/[^\x00-\xff]/ig);
        return str.length + (cArr == null ? 0 : cArr.length);
    }



    var clickerror=function(msg){
        $("#shmessage").html(msg);
        $("#shmessage").show();
    
    };

    var clickeve=function(){
        var shareco=$("#txtshare").val();
        if(shareco!=""){
            shareco=shareco+"(分享自@我看美女直播间官方微博)";
            $.ajax({
                type:"post",
                url:pageliveurl.publish,
                cache:false,
                data:"saytext="+shareco+"&t="+(new Date()).getTime(),
                success:function(data){
                    if(data=="true"){
                        //setCookie("weishow_room_isshare","1",3);
                        //发布成功
                        $("#txtshare").val("");
                        $("#sharewei").dialog("close");
                        $("#csspp").html("分享成功！");
                        popshare();
                    
                    }else if(data=="yfalse"){
                        $("#csspp").html("重复分享啦,不可以哦,您再说点什么吧！");
                        popshare();
                    }
                }
            })
        }else{
            $("#csspp").html("请您说点儿什么吧！");
            popshare();
        }
        return false;
    };

    ///分享提交事件
    var shareclick=function(){
        $("#btnshare").click(function () {
            clickeve();
        });
    };
    //分享框加载事件
    var shareContent=function(){
        if(!jw.Config.livetxtboxshare)return;
        var roomname=pagedata.currentidx?getAnchorInfo(pagedata.currentidx).screename:pagedata.roomname;
        var atxtboxarray=jw.Config.livetxtboxshare;
        var ap=parseInt(atxtboxarray.length*Math.random());
        var txtboxmessage=atxtboxarray[ap];
        txtboxmessage=txtboxmessage.replace("{0}",roomname);
        txtboxmessage=txtboxmessage.replace("{1}",location.href+" ");
        if(txtboxmessage!=""){
            $("#txtshare").val(txtboxmessage).setFocus();
        }else{
            $("#txtshare").val(roomname+"已经开始直播啦，赶快来观看吧"+location.href+" ").setFocus();
        }
    
    };
    ///弹出提示框
    var popshare=function(){
        $("#csspp").dialog({title:'友情提示',autoOpen:true,width:"280",height:"160",close:function(){
            $("#csspp").dialog("close");
        },load:function(){
            setTimeout(function(){
                $("#csspp").dialog("close");
            },2000);
        }
        });
    };
    //弹出关注框
    var vfollow=function(){
        if(jw.Doms.Other.dialog_guanzhu==null||jw.Doms.Other.dialog_guanzhu.length==0)
        {
            jw.Doms.Other.dialog_guanzhu=$('<div id="dialog_guanzhu" style="display:none"><div><iframe id="dialog_guanzhu_iframe" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" height="140" width="100%" src="about:blank" ></iframe></div></div>');
            jw.Doms.body.append(jw.Doms.Other.dialog_guanzhu);
        }
        if(jw.Doms.Other.dialog_guanzhu.dialog("iscreated"))
        {
            jw.Doms.Other.dialog_guanzhu.dialog("open");
            return;
        }
        jw.Doms.Other.dialog_guanzhu.dialog({
            title:'温馨提示',
            draggable:true,
            autoOpen:true,
            modal: true,
            width: 340,
            close:function(){
                jw.Config.share.isshare=true;
                setCookie("weishow_room_isgz","1",3);
                jw.Doms.Other.dialog_guanzhu.dialog("distory");
            }
        });
        jw.Doms.Other.dialog_guanzhu.find('#dialog_guanzhu_iframe').attr("src",'/vfollow.aspx');
    };

    //开灯
    var  turnLightsOn=function (cur,offimg,background_bak) {
        if(background_bak!=null)
        {
            jw.Doms.body.css("background-color",background_bak);
        }
        setBackGround();
        /*if(offimg==null)
        offimg='http://sr.9513.com/live/images/off.png';
        cur.attr("src",offimg);*/
    };

    //绑定页面卸载事件
    var bindunload=function () {
        var _unload=function () {
            try
            {
                jw.Doms.chatComm.closeChat();
                jw.Doms.videoComm.closeLive();
            }catch(e){}
        };
        if(window.addEventListener)
            window.addEventListener("beforeunload", _unload);
        else
            window.attachEvent("onbeforeunload", _unload);
        $(window).unload(_unload);
    };

    //绑定关灯/开灯按钮事件
    var bindLightoff=function () {

        $("#btnLightoff").click(function () {
            var background_bak = '';
            //var t=$("#btnLightoff").attr("t");  //0 关灯，1 开灯
            /*
            var cur=$(this).find("img");
            var offimg="http://sr.9513.com/live/images/off.png";
            if(cur.attr("src").indexOf(offimg)>-1)
            {
                background_bak=jw.Doms.body.css("background-color");
                jw.Doms.body.css('background','#000000');
                cur.attr("src","http://sr.9513.com/live/images/on.png")
            }
            else
            {
                turnLightsOn(cur,offimg,background_bak);
            }    */
            if(jw.Config.lightstate==1){
                turnLightsOn(background_bak);
                //$("#btnLightoff").attr("style","background-position:-40px -78px;");
                $("#btnLightoff").removeClass("i2").addClass("i2on");
                jw.Config.lightstate=0;
            }
            else
            {
                background_bak=jw.Doms.body.css("background-color");
                jw.Doms.body.css('background','#000000');
                //$("#btnLightoff").attr("style",""); 
                $("#btnLightoff").removeClass("i2on").addClass("i2");
                jw.Config.lightstate=1;
            
            }
            return false;
        });
    };

    //初始化随便看看
    var bindSbgg=function () {
        $("#btnsbgg").click(function(e){
            if(pagedata.usersidx==0){
                jw.Message.pleaselogin();
                return false;
            }
            var cur=$(this);
            var offset= cur.offset();
            var width=400;
            var _top=offset.top+cur.height();
            var _left=offset.left-(width/2);
        
            $("#dialog-browsing").dialog({title:'<ul><li><a id="browsing_favorites" href="#" hidefocus=\"true\">房间收藏</a>&nbsp;&nbsp;<a id="browsing_room" href="#" hidefocus=\"true\">最近浏览的房间</a></li></ul><div class="clearit"></div>',
                autoOpen:true,autoscroll:false,autoresize:false,width:width,position:[_left,_top],draggable:(!isAnchor()||!$.browser.msie),load:intiBrowsing});
        
            return false;
        });
    };

    //绑定显示礼物按钮
    var bindShowGift=function () {

        var btnshowgift=$('#btnshowgift').click(function () {
            if(pagedata.usersidx==0){
                jw.Message.pleaselogin();
                return false;
            }
            jw.Message.confirm("您确定要"+(jw.Config.gift.showgift?"关闭":"开启")+"礼物特效吗？"+(jw.Config.gift.showgift?"（只对自己有效）":""),function(){
	
                hideshowgiftconfirm();
                jw.Events.showGift.rightShow.largeShow.hide();
                jw.Events.showGift.rightShow.normalShow.hide();
                if(jw.Config.gift.showgift)
                {

                    $('#btnshowgift').removeClass("i1").addClass("i1on");
                    $('#btnshowgift').attr("title","开启礼物特效");
                    $('#btnshowgift').focus().blur();
                    //$('#btnshowgift').attr("style","background-position:-40px -104px;").attr("title","开启礼物特效");
                    $('#btnshowgift').html("开启<br>动效");
                }
                else
                {
                    $('#btnshowgift').removeClass("i1on").addClass("i1");
                    $('#btnshowgift').attr("title","关闭礼物特效");
                    $('#btnshowgift').focus().blur();
                    $('#btnshowgift').html("关闭<br>动效");
                    //$('#btnshowgift').attr("style","").attr("title","关闭礼物特效");
                }
                jw.Config.gift.showgift=!jw.Config.gift.showgift;
                //btnshowgift.html('<img src="http://sr.9513.com/live/images/pb_icon'+(jw.Config.gift.showgift?0:1)+'.png" />');
            },null,"开关礼物展示");
            return false;
        });
    };

    //绑定排行榜按钮事件
    var bindrankclick=function () {
        //本场粉丝排行榜按钮事件
        $("#bcfs_a").click(function () {
            $(this).find('h2').addClass('on');
            $("#cjfs_a").find('h2').removeClass('on');
            $("#roomfans0").show();
            $("#roomfans1").hide();
        });
        //超级粉丝排行榜按钮事件
        $("#cjfs_a").click(function () {
            $(this).find('h2').addClass('on');
            $("#bcfs_a").find('h2').removeClass('on');
            $("#roomfans0").hide();
            $("#roomfans1").show();
        });
    };

    //检查插件
    var checkcj=function () {
        if(window.ActiveXObject!==undefined) {
            if (pagedata.usersidx == 0) {
                return;
            }
            var _update = function() {
                jw.Message.pleasecj(null, null, true, false);
            };
            if (pagedata.isofficial && isAnchor() && !isfwebinstalled()) {
                _update();
            } else if (pagedata.roomtype === jw.Config.roomtype.threemic && isInstall && !fwebinstalled) {
                _update();
            }
        }
    };

    //初始化每日任务
    var binquest=function () {
        //加载任务
        if(pageliveurl.questjs.length>0)
        {  
            if(pagedata.chaturl==null)
            {
                $.getScript(pageliveurl.questjs, function() {
                    jw.Message.quest.init();

                    setTimeout(function () {
                        if (jw.Config.data.userLevel >= 11) {
                            if (jw.Message.quest.autoopenid != null) {
                                clearTimeout(jw.Message.quest.autoopenid);
                                jw.Message.quest.autoopenid = null;
                            }
                        }
                    },20000);
                });
            }
        }
    
        $(window).scrollTop(pagedata.fromsource!=2?100:130);
    };

    /****************气球宝藏strat***********************/
    var initGetKcData=function () {
        dbGetKcData(true,function (json) {
            jw.Config.gift.kcdata=json;
            initKcData();
        });
    };
    //获取礼物库存
    var getGiftKc=function (dom) {
        if(dom.next().length!==0)
            return;
        dom=dom.find('li');
        dom.addClass("disabled"); //禁止使用其他没有的库存物品
        dom.hide();
        if(pagedata.usersidx==0)
        {
            //dom.jcarousel("size",0);
            return;
        }
        dom.parent().prepend("<li id='kc_loading_img'><img src='"+jw.Config.loadingimg+"' />库存加载中...</li>");
        _doLoadKcjs(initGetKcData);    
        return false;
    };
    var _doLoadKcjs=function (fun) {
        if(!jw.Config.gift.sended)
        {
            $.getScript(pageliveurl.qqbzjs, function(){
                if(fun)
                    fun();
            });
        }
        else
        {
            if(fun)
                fun();
        }
    };
    /****************气球宝藏end***********************/
    //获取上期礼物之星数据
    var loadGiftStarResult=function () {
        if(pagedata.GiftStarResult)
            showGiftStarResult();
        else
            $.ajax({
                url:pageliveurl.getgiftstar,
                dataType:'json',
                cache:false,
                timeout:30000,
                success:function (json) {
                    if(json==null)
                    {
                        return;
                    }
                    //根据礼物数量由大到小排序
                    json=json.sort(function compare(a,b){return b.num-a.num;});
                    pagedata.GiftStarResult=json;
                    showGiftStarResult();
                } 
            });
    };
    //显示上期礼物之星图标
    var showGiftStarResult=function () {
        if(!jw.Config.gift.data) return;
        var num=0;
        var x=22;
        var giftid=0;
        var gift;
        var _json;
        var len=pagedata.GiftStarResult.length;
        for(var i=0;i<len;i++)
        {
      
            _json=pagedata.GiftStarResult[i];
            giftid=_json.gift_id;
            gift=jw.Config.gift.data[giftid];
            if(!gift)continue;
            var giftnmae=jw.Config.gift.data[giftid].name;
            if(_json.sidx==(pagedata.currentidx||pagedata.roomidx))
            {
                jw.Comm.setIcon.send(num*x+2,2,'http://sr.9513.com/live/images/rank/star'+giftid+'.png?d=v3',null,giftnmae+'之星');
                num++;
            }
            if(!jw.Config.gyygnns[_json.sidx])
            {
                jw.Config.gyygnns[_json.sidx]={id:'j_g'+giftid,msg:'热烈欢迎<span color="#ff0000">'+giftnmae+'之星</span>$u进入房间！'};
            }
        }
        if(pagedata.fromsource==1)
        {
            $.ajax({
                url:"/ashx/RankWeek.ashx?interval=1&ts="+(new Date()),
                type:"GET",
                success:function(data){
                    if(data==null||data==''||data.toString()=='[object XMLDocument]')
                    {
                        return;
                    }
                    var edata = eval('(' +data+ ')');
                    for(var k=0;k<edata.length;k++)
                    {
                        _json=edata[k];
                        giftid=_json.gift_id;
                        var giftname=_json.gift_name;
                        if(_json.idx==(pagedata.currentidx||pagedata.roomidx))
                        {
                            jw.Comm.setIcon.send(num*x+2,2,'http://sr.9513.com/live/images/rank/star'+giftid+'.png?d=201307241606',null,giftname+'红人榜');
                            num++;
                        }
                    }        
                }
            });
        }
        if(pagedata.roomtype!==jw.Config.roomtype.multimic)
            pagedata.GiftStarResult=null;
    };
    //关注 begin
    //关注操作 type:类型，zidx:主播ID
    var wb_attention_Operation = function(type, zidx) {

        if (pagedata.usersidx <= 0) {
            jw.Message.pleaselogin();
            return false;
        }
        return false;
    };


    //更新关注按钮内容 0：未关注，1：已关注
    var load_gzhtml = function(type) {
        var from = urlQueryString('from',true);
        if (from==='xl'||from==='pptv'||from==='tuli') {
            return;
        }
        var wb_zbidx = pagedata.roomidx;
        if (pagedata.roomtype == jw.Config.roomtype.multimic) {
            wb_zbidx =(pagedata.currentidx==0?pagedata.roomidx:pagedata.currentidx);
            if(pagedata.currentvidx){
                wb_zbidx=pagedata.currentvidx;
            }
        }
        if (pagedata.roomtype == jw.Config.roomtype.single) {
            if (type == 0) {
                $("#zb_info").append('<span class="favorite" style="right:-11px;"><a href="#" id="btnztfs" onclick="wb_attention_Operation(1,' + getanchorcno() + ');  return false;">+关注</a></span>');
            }
            else {
                $("#zb_info").append('<span class="favorite">已关注</span><span class="cancel_fav"><a href="#" onclick="wb_attention_Operation(2,' + getanchorcno() + '); return false;">取消</a></span>');
            }
        }
        else {
            if (type == 0) {
                $("#btnguanzhu").html('<span style="color:#FFFFFF;">+点此关注我</span>');
                $("#btnguanzhu").unbind("click").bind("click", function() {

                    wb_attention_Operation(1, wb_zbidx);
                    return false;
                });
            }
            else {
                $("#btnguanzhu").html('<span style="color:#FFFFFF;">-取消关注</span>');
                $("#btnguanzhu").unbind("click").bind("click", function() {
                    wb_attention_Operation(2, wb_zbidx);
                    return false;
                });
            }
        }
    };

    //页面加载完成判断用户和主播关系 idx：用户ID，zidx：主播ID
    var room_fansCheck = function(idx, zidx) {
        if (pagedata.usersidx <= 0) {
            //load_gzhtml(0);
            return;
        }
        if(isAnchor()){
            if(pagedata.roomtype ===jw.Config.roomtype.multimic)
            {
                if(pagedata.usersidx==pagedata.currentvidx){
                    return;
                }
            }
            else{
                return;
            }
        }
    };

    //关注 end

    //得币提示Dom
    var moneyTip=function(){
        var _offset = jw.Doms.Left.money.offset();
        var left= _offset.left +20;
        var top = _offset.top+(pagedata.fromsource===2?32:0);
        jw.Config.moneyTipOffset={left:left,top:top};
        jw.Doms.Other.moneyTip=$('<em id="moneyTip" class="mt'+pagedata.skin+'" style="top:'+top+'px;left:'+left+'px;" ></em>');
        jw.Doms.body.append(jw.Doms.Other.moneyTip);
    
        //游戏Tip
        /*
        if(pagedata.fromsource==1){
            var _g_offset=$("#talk_tab li").eq(2).offset();
            jw.Doms.Other.greenCardTip=$('<div id="greenCardTip" style="top:'+(_g_offset.top-17)+'px;left:'+(_g_offset.left+10)+'px;position:absolute;" ><img src="http://sr.9513.com/v3.0/images/new.png"/></div>');
            jw.Doms.body.append(jw.Doms.Other.greenCardTip);
        }*/
    };
    //顶部信息管理
    var loadtopBar=function(){
        $.getScript('http://sr.9513.com/v3.0/js/loadtopevents.js?d=201309121505', function(){
            //loadModifyNickname($("#nickname_icons"));
            //loadManageCenter($("#manage_icons"));       
        });  
    };
    var top_setContent=function(){
        var _setsClose=function(){
            setst_id=setTimeout(function(){
                $("#set_content").hide(); 
            },500);
        };
        $("#btn_sets").hover(function(){
            var   setst_id=setst_id?null:setst_id;
            if(setst_id!=null){
                clearTimeout(setst_id);
            } 
            $("#set_content").show();
        },function(){
            _setsClose();
        }).click(function () {
            return false;
        });
        $("#set_content").hover(function(){
            if(setst_id){
                clearTimeout(setst_id);
            } 
            $("#set_content").show();
         
        },function(){
            _setsClose();
        }).find('a').click(function(){
            $("#set_content").hide();
        });
    };
    var setTopUrl=function (roomidx) {
        if (pagedata.fromsource != 1) {
            return;
        }
        var _utl_d = '/user/dynamic.aspx?roomid=' + roomidx + '&cno=' + getcroomidx();
        var _utl_v = '/user/video/list.aspx?roomid=' + roomidx + '&cno=' + getcroomidx();
        var _utl_p = '/user/Photo/list.aspx?roomid=' + roomidx + '&cno=' + getcroomidx();
        var gourl1 = $("#go_url1");
        var gourl2 = $("#go_url2");
        var gourl3 = $("#go_url3");
        gourl1.attr("href", _utl_d);
        gourl2.attr("href", _utl_v);
        gourl3.attr("href", _utl_p);
    };
    //页面加载完毕后执行
    $(function(){
        
        //加载上期礼物之星图片
        loadGiftStarResult();
        
        //分享按钮事件
        shareclick();
        
        //绑定随便看看按钮事件
        bindSbgg();
        
        //绑定礼物展示按钮事件
        bindShowGift();
        
        //绑定关灯/开灯按钮事件
        bindLightoff();        
        
        //绑定排行榜按钮
        bindrankclick();    
        
        
        //初始化每日任务
        //binquest();
        
        //（延迟两秒加载）
        setTimeout(function(){
            if(pagedata.roomtype!==jw.Config.roomtype.multimic){
                //加载本期排名
                loadBQRank();
                //加载超级粉丝榜
                loadRoomFans(1);
                
                setTimeout(function () {
                    //加载本场直播排行榜
                    loadRoomFans(0);
                    //K歌活动
                    //loadKG2012Result();
                },10000);
            }
            //加载当前直播粉丝榜
            setInterval(function () {
                loadRoomFans(0,pagedata.currentvidx);
            },180000);
        
            setTimeout(function () {
                //显示广告
                jw.Events.showGift.screenShow.showAdv();
            },2000);
            
            //加载系统消息
            //loadSysInfo();
        },2000);
        
        //插件安装提示
        checkcj();
        
        //得币提示
        moneyTip();

        if(pagedata.usersidx>0){
            //顶部信息管理
            loadtopBar();
        }
       
        setTopUrl(pagedata.roomidx);
        if(pagedata.roomtype===jw.Config.roomtype.multimic){
            var _fans_idx=pagedata.currentidx==0?pagedata.roomidx:pagedata.currentidx;
            room_fansCheck(pagedata.usersidx,_fans_idx);
        }
        else
        {
            room_fansCheck(pagedata.usersidx,pagedata.roomidx);
        }
        
        top_setContent();
	       
        //显示搭讪主播数量
        if(pagedata.usersidx>0&&!isAnchor()&&pagedata.fromsource==1){
            showGouDaZhuBo();
        }
	  
	    
        updateTM(true);
	    
	    
    });

    //室主、主播开播事件
    var startLiveCallBack=function(player){
        jw.Config.data.isPlay=1;
        if(pagedata.roomtype===jw.Config.roomtype.single){
            setPraise();
        }else if(pagedata.roomtype===jw.Config.roomtype.threemic){
            setPraise(); 
        }else if(pagedata.roomtype===jw.Config.roomtype.multimic){
        
        }
    };

    var loadCSS=function(url){
        window.cssloaded=window.cssloaded||{};
        if(window.cssloaded[url])return;
        window.cssloaded[url]=1;
        var css=document.createElement("link");
        css.setAttribute("rel", "stylesheet");
        css.setAttribute("type", "text/css");
        css.setAttribute("href", url);
        document.getElementsByTagName('head')[0].appendChild(css);
    };
    //更新时间
    function updateTM(first){
        if(!first){
            pagedata.tm=parseInt(pagedata.tm)+2000;
        }
        setTimeout(updateTM,2000);
    }

    //开播后获取赞数量
    var setPraise=function(){
        if(pagedata.fromsource!=1){
            return;
        }
        $.ajax({
            type:"GET",
            url:pageliveurl.gettodaypraise,
            timeout:1500,
            cache:false,
            success:function(data){
                if(data!=null&&data!='-1'&&!isNaN(parseInt(data))){ 
                    //赞展示信息 
                    jw.Doms.Other.zanBtn=$(".how_zan");
                    var _offset = jw.Doms.Right.public.offset();
                    jw.Config.data.zanNum=data;
                    jw.Doms.Other.zanBtn.css({ left: _offset.left + jw.Doms.Right.public.width() - 100, top: _offset.top + 30 }).show().find("em").html(data);
                    jw.Doms.Other.zanBtn.hide(); //朱海波  2015-04-16 隐藏亲亲相关信息
                }
            },
            error:function(textStatus){
                if(textStatus.statusText=='timeout'){
                    setPraise();
                } 
            }    
        });
    };
    //用户提示
    var newUserTips = function (level, type) {
        /*新手提示，暂时取消
        var iShow=getCookie("newuserTips");
        if(level==0&&type==0&&iShow==null){
            var _offset=jw.Doms.Right.public.offset();
            var _left=_offset.left-58;
            var _top=(_offset.top+322)+(pagedata.roomtype===jw.Config.roomtype.threemic?16:0);
            var _tips='<div id="u_tips" onclick="$(this).animate({opacity: \'hide\'}, 500);return false;" class="tips_box_bottom" style="left:'+_left+'px;top:'+_top+'px;z-index:99;"><a class=""><p class="n1">在这里，与主播搭讪聊天，有机会获得主播亲亲，来与主播互动吧！</p><p class="n1">在这里，与主播搭讪聊天，有机会获得主播亲亲，来与主播互动吧！</p><p class="n2">如发言：“美女，你好漂亮！”<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;“好喜欢你唱歌,再来一首吧”</p></a></div>';
            jw.Doms.body.append(_tips);
            setCookie("newuserTips",1,30);
            setTimeout(function(){$("#u_tips").hide();},30000);
        }
        */
    };
    //搭讪提示
    var showDaShanText=function(isAuto){
        if(pagedata.usersidx>0){
            var _info='<img src="http://sr.9513.com/live/v2.0/images/face'+(isAuto?'2':'')+'.png?v=1">'+(isAuto?'哇塞，主播亲了您一口，恭喜您成功搭讪到第'+jw.Config.data.daShanNum+'位主播，再接再厉哦~':'亲，不错哦！已获得'+jw.Config.data.daShanNum+'位主播的青睐，搭讪无底线，发言让更多的主播亲亲你吧!');
            var isT=(jw.Config.data.daShanNum&&jw.Config.data.daShanNum==5);
            if(isT){
                _info='您已搭讪到五位主播，更多主播在此等你的到来，收藏网页立刻与主播们互动！';
            }
            var _btn=isT?'<a href="#" onclick="AddBrowserFavorites(\'daShanInfo\');return false;">确定收藏</a>':'<a href="#" onclick="$(\'#daShanInfo\').animate({opacity: \'hide\'}, 500);return false;">确定</a>';
            if($("#daShanInfo").length>0){
                $("#daShanInfo").find("p").html(_info);
                $("#daShanInfo").find("a").replaceWith(_btn);
            }else{
                var _offset_ds = $("#dashanBtn").offset();
                var _left_ds= _offset_ds.left-300;
                var _top_ds=_offset_ds.top-10; 
                var _dashan='<div class="tips_box" id="daShanInfo" style="left:'+_left_ds+'px;top:'+_top_ds+'px;z-index:99;"><p>'+_info+'</p>'+_btn+'</div>';
                jw.Doms.body.append(_dashan);
            }
            setTimeout(function(){$("#daShanInfo").show();},500);
        }
    };
    //用户勾搭主播信息展示
    var showGouDaZhuBo=function(type){
        $.ajax({
            type:"GET",
            url:pageliveurl.getdashan,
            timeout:1500,
            cache:false,
            success:function(data){
                if(data!=null&&data>0){ 
                    //搭讪展示信息   
                    if($("#dashanBtn").length>0){
                        $("#dashanBtn").find("strong").html(data);
                        if(jw.Config.data.daShanNum<data&&data<=5){
                            jw.Config.data.daShanNum=data;
                            showDaShanText(true);
                            $("#daShanInfo").animate({opacity: 'show'}, 500);
                        }
                    }else{
                        var _offset = jw.Doms.Right.public.offset();
                        var _left= _offset.left + jw.Doms.Right.public.width() - 100;
                        var _top=_offset.top+30;
                        var _html='<p class="how_zan ico_dashan" id="dashanBtn" style="left:'+_left+'px;top:'+_top+'px;display:block;position:absolute;"><a href="/User/help/praisehelp.aspx" target="_blank" ><img src="http://sr.9513.com/live/v2.0/images/pixel.gif" style="border:none;"><span>搭讪主播<strong>'+data+'</strong>位</span></a></p>';
                        jw.Doms.body.append(_html);
                        jw.Config.data.daShanNum=data;
                        if(type){
                            showDaShanText(true);
                            $("#daShanInfo").animate({opacity: 'show'}, 500);
                        }
                        $("#dashanBtn a").hover(function(){
                            if(window.hidedashan){
                                clearTimeout(window.hidedashan);
                                window.hidedashan = null;
                            }
                            showDaShanText(false);
                            
                        },function(){                 
                            window.hidedashan=setTimeout(function(){$("#daShanInfo").hide();},1000);
                        });
                    }
                      
                    jw.Config.data.daShanNum=data;
                      
                }
            },
            error:function(textStatus){
                if(textStatus.statusText=='timeout'){
                    showGouDaZhuBo();
                } 
            }    
        });
    };
    //添加到收藏夹
    var AddBrowserFavorites=function() {
        $("#daShanInfo").hide();
        var url =document.location;   
        var title = pagedata.roomname;   
        if($.browser.msie){
            if($.browser.version<=7){
                window.external.AddFavorite(url, title);
            }else{
                window.external.AddToFavoritesBar(url,title,title);
            }
        }
        else if(window.opera&&window.print){ 
            var mark = document.createElement('a'); 
            mark.setAttribute('rel','sidebar'); 
            mark.setAttribute('href',url); 
            mark.setAttribute('title',title); 
            mark.click(); 
            return true;
        }
        else{
            jw.Message.alert("浏览器不支持，请使用Ctrl+D进行手动收藏！");
        }
        return false;
    };

