/**
 *
 * Copyright (c) 2009 May(qq104010230)
 * http://www.winwill.com
 * http://www.winwill.com/jquery/jscroll.html
 * admin@winwill.com
 */
/*--------------------------------------------------------------------------------------------------*/
//侦听元素大小被改变事件
(function ($, h, c) { var a = $([]), e = $.resize = $.extend($.resize, {}), i, k = "setTimeout", j = "resize", d = j + "-special-event", b = "delay", f = "throttleWindow"; e[b] = 250; e[f] = true; $.event.special[j] = { setup: function () { if (!e[f] && this[k]) { return false } var l = $(this); a = a.add(l); $.data(this, d, { w: l.width(), h: l.height() }); if (a.length === 1) { g() } }, teardown: function () { if (!e[f] && this[k]) { return false } var l = $(this); a = a.not(l); l.removeData(d); if (!a.length) { clearTimeout(i) } }, add: function (l) { if (!e[f] && this[k]) { return false } var n; function m(s, o, p) { var q = $(this), r = $.data(this, d); r.w = o !== c ? o : q.width(); r.h = p !== c ? p : q.height(); n.apply(this, arguments) } if ($.isFunction(l)) { n = l; return m } else { n = l.handler; l.handler = m } } }; function g() { i = h[k](function () { a.each(function () { var n = $(this), m = n.width(), l = n.height(), o = $.data(this, d); if (m !== o.w || l !== o.h) { n.trigger(j, [o.w = m, o.h = l]) } }); g() }, e[b]) } })(jQuery, this);

$.fn.extend({//添加滚轮事件//by jun
    mousewheel: function (Func) {
        return this.each(function () {
            var _self = this;
            _self.D = 0;//滚动方向
            if ($.browser.msie || $.browser.safari) {
                _self.onmousewheel = function () { _self.D = event.wheelDelta; event.returnValue = false; Func && Func.call(_self); };
            } else {
                _self.addEventListener("DOMMouseScroll", function (e) {
                    _self.D = e.detail > 0 ? -1 : 1;
                    e.preventDefault();
                    Func && Func.call(_self);
                }, false);
            }
        });
    }
});
$.fn.extend({
    jscroll: function (j) {
        return this.each(function () {
            j = j || {}
            j.Bar = j.Bar || {};//2级对象
            j.Btn = j.Btn || {};//2级对象
            j.Bar.Bg = j.Bar.Bg || {};//3级对象
            j.Bar.Bd = j.Bar.Bd || {};//3级对象
            j.Bar.Tb = j.Bar.Tb || {};//3级对象
            j.Bar.Tb.TPos = j.Bar.Tb.TPos || {}; //4级对象
            j.Bar.Tb.BPos = j.Bar.Tb.BPos || {}; //4级对象
            j.Btn.uBg = j.Btn.uBg || {};//3级对象
            j.Btn.dBg = j.Btn.dBg || {};//3级对象

            var jun = {
                W: "15px"
						, bodyElement: "#bodyElement" //具体的主体内容元素选择器文本
						, BgUrl: ""
						, Bg: "#efefef"
						, Bar: {
						    Pos: "up"  //滚动条
								, Bd: { bd: true, Out: "#b5b5b5", Hover: "#ccc" }  //滚动条边框
								, Bg: { Out: "#fff", Hover: "#fff", Focus: "orange" }  //滚动条主体
								, Tb: { tb: false, topHeight: 4, bHeight: 4, TPos: { Out: "#000", Hover: "#000", Focus: "orange" }, BPos: { Out: "#000", Hover: "#000", Focus: "orange" } } //滚动条上中下三部分
						}
						, Btn: {
						    btn: true
								, uBg: { Out: "#ccc", Hover: "#fff", Focus: "orange" }
								, dBg: { Out: "#ccc", Hover: "#fff", Focus: "orange" }
						}
						, Fn: function () { }
            }
            j.W = j.W || jun.W;
            j.bodyElement = j.bodyElement || jun.bodyElement;
            j.BgUrl = j.BgUrl || jun.BgUrl;
            j.Bg = j.Bg || jun.Bg;
            j.Bar.Pos = j.Bar.Pos || jun.Bar.Pos;
            j.Bar.Bd.Out = j.Bar.Bd.Out || jun.Bar.Bd.Out;
            j.Bar.Bd.Hover = j.Bar.Bd.Hover || jun.Bar.Bd.Hover;
            j.Bar.Bg.Out = j.Bar.Bg.Out || jun.Bar.Bg.Out;
            j.Bar.Bg.Hover = j.Bar.Bg.Hover || jun.Bar.Bg.Hover;
            j.Bar.Bg.Focus = j.Bar.Bg.Focus || jun.Bar.Bg.Focus;
            j.Bar.Tb.tb = j.Bar.Tb.tb || jun.Bar.Tb.tb;
            j.Bar.Tb.topHeight = j.Bar.Tb.topHeight || jun.Bar.Tb.topHeight;
            j.Bar.Tb.bHeight = j.Bar.Tb.bHeight || jun.Bar.Tb.bHeight;
            j.Bar.Tb.TPos.Out = j.Bar.Tb.TPos.Out || jun.Bar.Tb.TPos.Out
            j.Bar.Tb.TPos.Hover = j.Bar.Tb.TPos.Hover || jun.Bar.Tb.TPos.Hover
            j.Bar.Tb.TPos.Focus = j.Bar.Tb.TPos.Focus || jun.Bar.Tb.TPos.Focus
            j.Bar.Tb.BPos.Out = j.Bar.Tb.BPos.Out || jun.Bar.Tb.BPos.Out
            j.Bar.Tb.BPos.Hover = j.Bar.Tb.BPos.Hover || jun.Bar.Tb.BPos.Hover
            j.Bar.Tb.BPos.Focus = j.Bar.Tb.BPos.Focus || jun.Bar.Tb.BPos.Focus

            j.Btn.btn = j.Btn.btn != undefined ? j.Btn.btn : jun.Btn.btn;
            j.Btn.uBg.Out = j.Btn.uBg.Out || jun.Btn.uBg.Out;
            j.Btn.uBg.Hover = j.Btn.uBg.Hover || jun.Btn.uBg.Hover;
            j.Btn.uBg.Focus = j.Btn.uBg.Focus || jun.Btn.uBg.Focus;
            j.Btn.dBg.Out = j.Btn.dBg.Out || jun.Btn.dBg.Out;
            j.Btn.dBg.Hover = j.Btn.dBg.Hover || jun.Btn.dBg.Hover;
            j.Btn.dBg.Focus = j.Btn.dBg.Focus || jun.Btn.dBg.Focus;
            j.Fn = j.Fn || jun.Fn;
            var _self = this;
            var bodyElement = $(_self).find(j.bodyElement)//内部内容盒子元素
            var Stime, Sp = 0, Isup = 0;
            $(_self).css({ overflow: "hidden", position: "relative" });
            var curT = 0, allowS = false;
            var dw = $(_self).width();  //滚动窗口宽度
            var dh = $(_self).outerHeight() - 1; //滚动窗口高度
            var padding_top_h = parseInt($(_self).css('padding-top'));
            padding_top_h = isNaN(padding_top_h) ? 0 : padding_top_h;
            
            var sw = j.W ? parseInt(j.W) : 21; //滚动条的宽度
            var sl = dw - sw  //可视区宽度
            var sch = dh; //滚动条的高度
            var sh = 24; //滚轮的高度
            var wh = 4; //滚动时跳动的幅度
            var IsMousewheel = false;//是否注册了鼠标滚轮事件
            var stopGetbottom = false;//是否置底
            var bw = j.Btn.btn == true ? sw : 0;
            //console.log(bodyElement.length, bodyElement.height, dh，padding_top_h, (bodyElement.length > 0 && !(bodyElement.height() < dh - padding_top_h)));
            if ($(_self).children(".jscroll-c").height() == null) {//存在性检测
                $(_self).wrapInner("<div class='jscroll-c' style='top:0px;z-index:99;zoom:1;position:relative'></div>");
                $(_self).children(".jscroll-c").prepend("<div style='height:0px;overflow:hidden'></div>");
                var tempHtml = "<div class='jscroll-e' unselectable='on' style=' height:100%;top:0px;right:0;-moz-user-select:none;position:absolute;overflow:hidden;z-index:10000;'><div class='jscroll-u' style='position:absolute;top:0px;width:100%;left:0;background:blue;overflow:hidden'></div><div class='jscroll-h'  unselectable='on' style='position:absolute;left:0;-moz-user-select:none;";
                if (j.Bar.Bd.bd)
                    tempHtml += "border:1px solid";
                tempHtml += "'>";
                tempHtml += "<div class='jscroll-h-t' style='width:100%;'></div>";//滚动条头部
                tempHtml += "<div class='jscroll-h-m' style='width:100%;'></div>";//滚动条中间
                tempHtml += "<div class='jscroll-h-b' style='width:100%;'></div>";//滚动条底部
                tempHtml += "</div><div class='jscroll-d' style='position:absolute;bottom:0px;width:100%;left:0;background:blue;overflow:hidden'></div></div>";
                $(_self).append(tempHtml);
            }
            var jscrollc = $(_self).children(".jscroll-c");
            var jscrolle = $(_self).children(".jscroll-e");
            var jscrollh = jscrolle.children(".jscroll-h");
            var jscrollht = jscrollh.find(".jscroll-h-t");
            var jscrollhm = jscrollh.find(".jscroll-h-m");
            var jscrollhb = jscrollh.find(".jscroll-h-b");
            var jscrollu = jscrolle.children(".jscroll-u");
            var jscrolld = jscrolle.children(".jscroll-d");
            if ($.browser.msie) { document.execCommand("BackgroundImageCache", false, true); }
            jscrollc.css({ "padding-right": sw });
            jscrolle.css({ width: sw, background: j.Bg, "background-image": j.BgUrl });

            if (j.Bar.Bd.bd)
                jscrollh.css({ "border-color": j.Bar.Bd.Out });

            if (j.Bar.Tb.tb) {  //滚动条分上中下三部分
                jscrollht.css({ background: j.Bar.Tb.TPos.Out, "background-image": j.BgUrl, width: sw - 2 });
                jscrollhm.css({ background: j.Bar.Bg.Out, "background-image": j.BgUrl, width: sw - 2 });
                jscrollhb.css({ background: j.Bar.Tb.BPos.Out, "background-image": j.BgUrl, width: sw - 2 });
            } else {//主体滚动条，只有一根滚动条
                jscrollh.css({ top: bw, background: j.Bar.Bg.Out, "background-image": j.BgUrl, width: sw - 2 });
            }
            jscrollu.css({ height: bw, background: j.Btn.uBg.Out, "background-image": j.BgUrl });
            jscrolld.css({ height: bw, background: j.Btn.dBg.Out, "background-image": j.BgUrl });

            //滚动条悬停
            jscrollh.hover(function () {
                if (Isup == 0) {
                    if (j.Bar.Tb.tb)  //当有滚动条有上中下三部分的时候
                    {
                        jscrollht.css({ background: j.Bar.Tb.TPos.Hover, "background-image": j.BgUrl });
                        jscrollhm.css({ background: j.Bar.Bg.Hover, "background-image": j.BgUrl });
                        jscrollhb.css({ background: j.Bar.Tb.BPos.Hover, "background-image": j.BgUrl });
                    }
                    else {  //当有滚动条只有一部分的时候
                        $(this).css({ background: j.Bar.Bg.Hover, "background-image": j.BgUrl })
                    }
                    if (j.Bar.Bd.bd)
                        $(this).css({ "border-color": j.Bar.Bd.Hover });
                }
            }, function () {
                if (Isup == 0) {
                    if (j.Bar.Tb.tb)  //当有滚动条有上中下三部分的时候
                    {
                        jscrollht.css({ background: j.Bar.Tb.TPos.Out, "background-image": j.BgUrl });
                        jscrollhm.css({ background: j.Bar.Bg.Out, "background-image": j.BgUrl });
                        jscrollhb.css({ background: j.Bar.Tb.BPos.Out, "background-image": j.BgUrl });
                    }
                    else {  //当有滚动条只有一部分的时候
                        $(this).css({ background: j.Bar.Bg.Out, "background-image": j.BgUrl })
                    }
                    if (j.Bar.Bd.bd)
                        $(this).css({ "border-color": j.Bar.Bd.Out });
                }
            });

            jscrollu.hover(function () { if (Isup == 0) $(this).css({ background: j.Btn.uBg.Hover, "background-image": j.BgUrl }) }, function () { if (Isup == 0) $(this).css({ background: j.Btn.uBg.Out, "background-image": j.BgUrl }) })
            jscrolld.hover(function () { if (Isup == 0) $(this).css({ background: j.Btn.dBg.Hover, "background-image": j.BgUrl }) }, function () { if (Isup == 0) $(this).css({ background: j.Btn.dBg.Out, "background-image": j.BgUrl }) })

            AdjustSize();//调节滚动条的高度尺寸



            jscrollh.bind("mousedown", clickScroll);
            function clickScroll(e) {
                j['Fn'] && j['Fn'].call(_self);
                Isup = 1;
                if (j.Bar.Tb.tb)  //当有滚动条有上中下三部分的时候
                {
                    jscrollht.css({ background: j.Bar.Tb.TPos.Focus, "background-image": j.BgUrl });
                    jscrollhm.css({ background: j.Bar.Bg.Focus, "background-image": j.BgUrl });
                    jscrollhb.css({ background: j.Bar.Tb.BPos.Focus, "background-image": j.BgUrl });
                }
                else {  //当有滚动条只有一部分的时候
                    jscrollh.css({ background: j.Bar.Bg.Focus, "background-image": j.BgUrl })
                }
                var pageY = e.pageY, t = parseInt($(this).css("top"));
                $(document).mousemove(function (e2) {
                    if (Isup == 1) {
                        curT = t + e2.pageY - pageY;//pageY浏览器可视区域鼠标位置，screenY屏幕可视区域鼠标位置
                        //console.log(curT)
                        setT();
                    }
                });
                $(document).mouseup(function () {
                    Isup = 0;
                    if (j.Bar.Tb.tb)  //当有滚动条有上中下三部分的时候
                    {
                        jscrollht.css({ background: j.Bar.Tb.TPos.Out, "background-image": j.BgUrl });
                        jscrollhm.css({ background: j.Bar.Bg.Out, "background-image": j.BgUrl });
                        jscrollhb.css({ background: j.Bar.Tb.BPos.Out, "background-image": j.BgUrl });
                    }
                    else {  //当有滚动条只有一部分的时候
                        jscrollh.css({ background: j.Bar.Bg.Out, "background-image": j.BgUrl })
                    }

                    if (j.Bar.Bd.bd)
                        jscrollh.css({ "border-color": j.Bar.Bd.Out })
                    //$(document).unbind();
                });
                return false;
            }

            jscrollu.bind("mousedown", function (e) {
                j['Fn'] && j['Fn'].call(_self);
                Isup = 1;
                jscrollu.css({ background: j.Btn.uBg.Focus, "background-image": j.BgUrl })
                _self.timeSetT("u");
                $(document).mouseup(function () {
                    Isup = 0;
                    jscrollu.css({ background: j.Btn.uBg.Out, "background-image": j.BgUrl })
                    $(document).unbind();
                    clearTimeout(Stime);
                    Sp = 0;
                });
                return false;
            });
            jscrolld.bind("mousedown", function (e) {
                j['Fn'] && j['Fn'].call(_self);
                Isup = 1;
                jscrolld.css({ background: j.Btn.dBg.Focus, "background-image": j.BgUrl })
                _self.timeSetT("d");
                $(document).mouseup(function () {
                    Isup = 0;
                    jscrolld.css({ background: j.Btn.dBg.Out, "background-image": j.BgUrl })
                    $(document).unbind();
                    clearTimeout(Stime);
                    Sp = 0;
                });
                return false;
            });
            _self.timeSetT = function (d) {
                var self = this;
                if (d == "u") { curT -= wh; } else { curT += wh; }
                setT();
                Sp += 2;
                var t = 500 - Sp * 50;
                if (t <= 0) { t = 0 };
                Stime = setTimeout(function () { self.timeSetT(d); }, t);
            }
            jscrolle.bind("mousedown", function (e) {
                j['Fn'] && j['Fn'].call(_self);
                curT = curT + e.pageY - jscrollh.offset().top - sh / 2;
                asetT();
                return false;
            });
            function AdjustSize() {
                //调节滚动条尺寸
                sch = jscrollc.height();   //滚动内容的总高度
                //var sh = Math.pow(dh,2) / sch ;//Math.pow(x,y)x的y次方
                sh = (dh - 2 * bw) * dh / sch - padding_top_h  //滚轮的高度, dh表示滚动可见区域的高度
                if (sh < 10) { sh = 10 }
                wh = sh / 6  //滚动时候跳动幅度
                //	sh = parseInt(sh);
                //console.log(sh, dh, sch, bw);

                jscrollh.height(sh);
                if (j.Bar.Tb.tb) //如果滚动条存在上中下三部分，则对上中下的高度做判定
                {
                    jscrollht.height(j.Bar.Tb.topHeight);//上
                    jscrollhm.height(sh - j.Bar.Tb.topHeight - j.Bar.Tb.bHeight);//中
                    jscrollhb.height(j.Bar.Tb.bHeight);//下
                }

                if (sch <= dh) {
                    jscrollc.css({ padding: 0 });
                    jscrolle.css({ display: "none" });
                    
                } else {
                    allowS = true;
                }
                if (j.Bar.Pos == "bottom" && !stopGetbottom) {
                    curT = dh - sh - bw;  //当前滚动条的位置-置底
                    //curT = 0; //当前滚动条的位置-置顶
                }
                if (j.Bar.Pos == "upAndBottom" && !(bodyElement.length > 0 && bodyElement.height() < dh - padding_top_h && !stopGetbottom)) {
                    curT = dh - sh - bw;
                }
                setT();
            }

            function asetT() {
                if (curT < bw) { curT = bw; }
                if (curT > dh - sh - bw) { curT = dh - sh - bw; }
                jscrollh.stop().animate({ top: curT }, 100);
                var scT = -((curT - bw) * sch / (dh - 2 * bw));
                jscrollc.stop().animate({ top: scT }, 1000);
            };
            function setT() {
                if (bodyElement.length > 0 && !(bodyElement.height() < dh - padding_top_h)) { //当内容高度大于滚动容器的高度时，则滚动条置底
                    jscrolle.show();
                    //注册鼠标滚轮事件只注册一次
                    if (!IsMousewheel) {
                        IsMousewheel = true;
                        $(_self).mousewheel(function () {
                            if (allowS != true) return;
                            j['Fn'] && j['Fn'].call(_self);
                            if (this.D > 0) { curT -= wh; } else { curT += wh; };
                            setT();
                        });
                    }
                }
                if (curT == 0) {
                    jscrollh.css({ top: curT });  //滚动条的位置
                    jscrollc.css({ top: scT });
                } else {
                    if (curT < bw) { curT = bw; }
                    if (curT > dh - sh - bw) { curT = dh - sh - bw; }
                    jscrollh.css({ top: curT });  //滚动条的位置
                    var scT = -((curT - bw) * sch / (dh - 2 * bw)) - padding_top_h;  //滚动区域的位置
                    jscrollc.css({ top: scT });
                }
                //console.log(curT)
                if ((curT+sh) > (dh - 5))
                    stopGetbottom = false;
                else
                    stopGetbottom = true;
                //console.log(curT, sh, stopGetbottom);
            };
            
            if (bodyElement.length > 0)
                bodyElement.resize(function () { AdjustSize() });
        });
    }
});
