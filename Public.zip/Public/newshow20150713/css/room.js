﻿//房间的一些处理



//登录信息加载
function LoginUserInfo() {
    var useridx = parseInt(getCookie('cno', 1));
    $("#NoShowUserInfo_windows").hide();
    $("#showUserInfo_windows").show();
    if (!isNaN(useridx) && useridx > 0) {
        $.ajax({
            cache: false,
            url: '/ajax/memberinfo.aspx',
            dataType: 'json',
            async: false,
            success: function (json) {
                var _level = [5000, 10000, 20000, 40000, 100000, 150000, 300000, 500000, 800000, 1200000, 2000000, 3000000, 4000000,
                        6000000, 8000000, 10000000, 15000000, 20000000, 30000000, 50000000, 80000000, 100000000, 150000000, 200000000,
                        250000000, 300000000, 500000000, 800000000];
                var exp_fwd = json.UserGrade - 1 < 0 ? 0 : _level[json.UserGrade - 1];
                var upgrade = _level[json.UserGrade] - json.expenseMoney;
                var progress = ((json.expenseMoney - exp_fwd) / (_level[json.UserGrade] - exp_fwd)).toFixed(3) * 100;
                //console.log(json)
                $("#UserInfo_HeadImg").attr("src", json.picurl); //会员头像
                $("#UserInfo_Name").html(json.nickname + "(" + json.cno + ")"); //会员名
                $("#UserInfo_ExpImg").attr("src", 'http://sr.9513.com/live/v2.0/images/face/v' + json.UserGrade + '.gif'); //会员等级图标
                $("#UserInfo_EXP").css("width", progress + "%");//会员经验条
                $("#UserInfo_EXP_Bg").attr("title", "升至下一级还需要消费" + upgrade + "星币");//经验条背景

                //修改昵称绑定
                $("#UserInfo_upName").click(function () {
                    var nickname = getCookie('nickname', 1);//获取当前昵称
                    var NewName = $.trim($('#UserInfo_upNameTxt').val()); //获取新昵称
                    var d = NewName.bytelength();//文本长度
                    var Tips = '';//信息文本
                    if (NewName.length == 0) {
                        Tips = '昵称不能为空！'
                    } else if (d < 4 || d > 10) {
                        Tips = '昵称长度需在4—10个字符之间（1个汉字折合成两个字符）';
                    }
                    if (nickname === NewName) {
                        Tips = '昵称与原来的相同！';
                    }
                    if (Tips) {
                        if ($.fn.dialog) {
                            $.alert(Tips);
                        } else {
                            requireDialog(function () {
                                $.alert(Tips);
                            })
                        }
                        return false
                    }

                    //AJAX修改昵称
                    $.ajax({
                        cache: false,
                        url: '/ashx/member/updatescreename.ashx?screename=' + escape(NewName),
                        success: function (a) {
                            var b = function () {
                                if (a == "1") {
                                    $.alert('昵称修改成功！');
                                    $('#UserInfo_Name').html(NewName + '(' + getCookie('cno', 1) + ')')
                                } else if (a == "-1") {
                                    $.alert("主播在本平台不能修改昵称，请到微博修改！")
                                } else if (a == "0") {
                                    $.alert("昵称‘" + NewName + "’已被抢注！")
                                } else if (a == "2") {
                                    $.alert("昵称修改失败，您在24小时之内已经修改过昵称！")
                                } else if (a == "3") {
                                    $.alert("昵称长度不能小于4大于20个字符！(一个汉字折合两个字符)")
                                } else if (a == "4") {
                                    $.alert("昵称只允许中英文、数字、'_'和减号！")
                                } else if (a == "5") {
                                    $.alert("昵称‘" + NewName + "’不符合规则！")
                                } else {
                                    $.alert('昵称修改失败！')
                                }
                            };
                            if ($.fn.dialog) {
                                b()
                            } else {
                                requireDialog(function () {
                                    b()
                                })
                            }
                        },
                        error: function () {
                            if ($.fn.dialog) {
                                $.alert('昵称修改失败！');
                            } else {
                                requireDialog(function () {
                                    $.alert('昵称修改失败！');
                                })
                            }
                        }
                    });
                    return false;
                });
                //昵称修改文本框回车事件绑定
                $('#UserInfo_upNameTxt').keydown(function (e) {
                    if (e.keyCode === 13) {
                        $("#UserInfo_upName").click();
                    }
                })

            }
        });
    } else { //未登录
        $("#NoShowUserInfo_windows").show();
        $("#showUserInfo_windows").hide();
    }
}






$(function () {
    LoginUserInfo();


    $(".listcon li").hover(function (e) {
        var xx = e.originalEvent.x || e.originalEvent.layerX || 0;
        var yy = e.originalEvent.y || e.originalEvent.layerY || 0;
        var left = $(this).offset().left + 260;
        var top = $(this).offset().top;
        $("#dialog-contextmenu").css({ "left": xx, "top": yy }).show();
    }, function (e) {
        $("#dialog-contextmenu").hide();
    });
    $("#dialog-contextmenu").hover(function () {
        $("#dialog-contextmenu").show();
    }, function () {
        $("#dialog-contextmenu").hide();
    })

    //初始化物品的定位样式
    $("#gift_tabs .items").each(function () {
        //初始化物品的定位样式
        $(this).find(".giftItem:gt(8)").hide();
        $(this).find(".giftItem").each(function (i) {
            var me = $(this);
            me.attr("class", "giftItem");
            $(this).addClass("posit" + (parseInt(i) % 9 + 1));
        });
    });
    //物品左箭头被点击
    $("#gift_tabs .arrow_left").bind("click", function () {
        var me = $("#gift_tabs .items:visible");//获取可见的物品条
        var index = me.find(".giftItem:not(.disabled):visible:first").index();//获取可视物品的第一个物品的index
        var startIndex = index - 9 - 1;
        if (startIndex < -1)
            return false;
        me.find(".giftItem").hide();//隐藏所有物品
        if (startIndex < 0)
            me.find(".giftItem:not(.disabled):lt(9)").show();
        else
            me.find(".giftItem:not(.disabled):gt(" + startIndex + "):lt(9)").show();
    });

    //物品右箭头被点击
    $("#gift_tabs .arrow_right").bind("click", function () {
        var me = $("#gift_tabs .items:visible");//获取可见的物品条
        var index = me.find(".giftItem:not(.disabled):visible:first").index();//获取可视物品的第一个物品的index

        var total = me.find(".giftItem:not(.disabled)").length;
        var startIndex = index + 8;
        if (startIndex >= total)
            return false;
        me.find(".giftItem").hide();//隐藏所有物品
        me.find(".giftItem:not(.disabled):gt(" + startIndex + "):lt(9)").show();
    });

    //选择礼物分类
    $("#gift_tab li").click(function () {
        var me = $(this); var type = me.attr("data-type");
        $("#gift_tab li").removeClass("gift_btn_on");
        showItems(type);
        me.addClass("gift_btn_on");
    });

    showItems(0);

    var scrollConfig = {
        W: "15px"
        , bodyElement: ".c_scroll_con"
        , BgUrl: "url(http://sr.9513.com/live/" + version + "/images/s_bg2.png)"
        , Bg: "right 0 repeat-y"
        , Bar: {
            Pos: "up"  //up：置顶,bottom：置底,upAndBottom : 初始置顶，内容超出时置底
            , Bd: { bd: false, Out: "#a3c3d5", Hover: "#b7d5e6" }
            , Bg: { Out: "-45px 0 repeat-y", Hover: "-45px 0 repeat-y", Focus: "-45px 0 repeat-y" }
            , Tb: { tb: true, topHeight: 4, bHeight: 4, TPos: { Out: "-58px 0 no-repeat", Hover: "-58px 0 no-repeat", Focus: "-58px 0 no-repeat" }, BPos: { Out: "-58px -26px no-repeat", Hover: "-58px -26px no-repeat", Focus: "-58px -26px no-repeat" } }
        }
        , Btn: { btn: false }
        , Fn: function () { }
    };

    $(".ZBJ_jscroll").jscroll(scrollConfig);
    var newScrollConfig = jQuery.extend(true, {}, scrollConfig); //深复制
    newScrollConfig.Bar.Pos = "upAndBottom";
    $(".ZBJ_jscrollUpAndBottom").jscroll(newScrollConfig);


    //会员信息弹窗
    $("#showUserInfo_windows,#userInfo_Windows").hover(function () {
        $("#userInfo_Windows").show();
    }, function () {
        $("#userInfo_Windows").hide();
    });


    //解决IE下链接  javascript:void(0),javascript:; 会触发 onbeforeunload的问题
    if (document.all) {
        $("a[href = 'javascript:void(0);'],a[href = 'javascript:void(0)']").live("click", function (e) {
            e.preventDefault();
        });
    }


    //关于左侧与右侧的黑条在1366宽度的浏览器中的问题
    if ($("body").width() <= 1366)
    {
        //左侧
        var zbj_left = $("#ZBJ_leftNav");
        zbj_left.css("left", "-20px");
        zbj_left.hover(function () {
            zbj_left.animate({ "left": "0px" }, 250);
        }, function () {
            zbj_left.animate({ "left": "-20px" }, 250);
        });

        var zbj_right = $("#rightGame");
        zbj_right.css("right", "-25px");
        zbj_right.hover(function () {
            zbj_right.animate({ "right": "0px" }, 250);
        }, function () {
            zbj_right.animate({ "right": "-25px" }, 250);
        });
    }

    //守护头像悬停
    $("#GuardList").on("mouseover", "li", function (e) {
        var me = $(this);
        var cno = me.attr("dataIdx");
        var Name = me.attr("dataName");
        $("#guard_Name").html(Name + "<br/>(" + cno + ")");
        $("#guard_Img").attr("src", "http://sr.9513.com/Images/guard/" + me.attr("data-Type") + ".png");
        $("#dialog-guard").css({ left: me.offset().left + me.width(), top: me.offset().top })
        $("#dialog-guard").show();
    });

    $("#GuardList").on("mouseout", "li", function () {
        $("#dialog-guard").hide();
    });
    


    /*测试按钮*/
    $("#ceshi").click(function () {
        jw.Message.chat.Addlb.Airing('16:30&nbsp;&nbsp;头发乱了，：数量巨大浪费精神了大家分厘卡三季稻了科技时代浪费精力<a href="javascript:void(0)">（小逗比）</a>');
    });

});




function showItems(n) {
    $("#gift_tabs .items").hide();
    $("#gift_tabs .items:eq(" + n + ")").show();
}







//直播间原始JS配置








